@echo off
REM Double-click launcher for the CREST GUI (Phase S).
REM
REM We deliberately leave the host PowerShell console visible so any
REM script-level error stays on screen rather than flashing and
REM disappearing. Once the WinForms window opens you can minimize the
REM console; closing it will close the GUI too. Re-add -WindowStyle
REM Hidden once the GUI has been validated as stable on this box.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Crest-GUI.ps1"
