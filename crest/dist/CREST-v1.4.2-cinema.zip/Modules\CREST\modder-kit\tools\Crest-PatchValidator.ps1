<#
.SYNOPSIS
  Validates every Harmony patch target in the CREST source against a target
  Bannerlord reference-assembly set. Reports missing types/methods BEFORE
  you launch the game, saving the build/launch/bisect loop on a version bump.

.DESCRIPTION
  Walks all .cs files in Crest.Harmony / Crest.MCM.UI / etc. Finds:
    * [HarmonyPatch(typeof(X.Y.Z), "Method")]  attribute declarations
    * AccessTools2.TypeByName("X.Y.Z")          runtime resolutions
    * AccessTools2.Method(t, "MethodName")      runtime method lookups
  Resolves each against the BUTR reference-assembly DLLs at the configured
  GameVersion pin (read from build/common.props). Anything missing is a
  patch that won't bind on the new game version.

.PARAMETER RefAsmRoot
  Override path to the BUTR ref-asm directory. Defaults to autodetect from
  ~/.nuget/packages/bannerlord.referenceassemblies.*/<version>/lib/net472/.

.PARAMETER ExitOnMiss
  Exit with non-zero code if any miss is found. Use in CI / pre-build target.

.EXAMPLE
  .\Crest-PatchValidator.ps1
  .\Crest-PatchValidator.ps1 -ExitOnMiss
#>
[CmdletBinding()]
param(
    [string]$RefAsmRoot,
    [switch]$ExitOnMiss
)

$ErrorActionPreference = 'Stop'
$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..\..') | Select-Object -ExpandProperty Path

# Locate Mono.Cecil from CREST's deployed bin
$cecilCandidates = @(
    'C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules\CREST\bin\Win64_Shipping_Client\Mono.Cecil.dll',
    "$env:USERPROFILE\.nuget\packages\mono.cecil\*\lib\net40\Mono.Cecil.dll"
)
$cecilDll = $null
foreach ($cand in $cecilCandidates) {
    $hits = Get-ChildItem -Path $cand -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($hits) { $cecilDll = $hits.FullName; break }
}
if (-not $cecilDll) { throw 'Mono.Cecil.dll not found' }
Add-Type -Path $cecilDll

# Determine target ref-asm path
if (-not $RefAsmRoot) {
    # Read GameVersion from build/common.props
    $propsPath = Join-Path $repoRoot 'Bannerlord.Harmony\build\common.props'
    $propsContent = Get-Content $propsPath -Raw
    if ($propsContent -match '<GameVersion>(\d+\.\d+\.\d+)</GameVersion>') {
        $gameVersion = $matches[1]
    } else {
        throw 'cannot extract <GameVersion> from common.props'
    }
    Write-Host ('GameVersion pin: {0}' -f $gameVersion)

    # Find a matching BUTR ref-asm package
    $pkgRoot = Join-Path $env:USERPROFILE '.nuget\packages\bannerlord.referenceassemblies.core'
    if (-not (Test-Path $pkgRoot)) { throw 'BUTR ref-asm package cache not found' }
    $matched = Get-ChildItem -Path $pkgRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like ($gameVersion + '*') } |
        Sort-Object Name -Descending | Select-Object -First 1
    if (-not $matched) { throw ('No BUTR ref-asm matching {0} found in {1}' -f $gameVersion, $pkgRoot) }
    $RefAsmRoot = Join-Path $matched.FullName 'lib\net472'
}
Write-Host ('Ref-asm root: {0}' -f $RefAsmRoot)
if (-not (Test-Path $RefAsmRoot)) { throw ('ref-asm root does not exist: ' + $RefAsmRoot) }

# Load every TaleWorlds.* assembly into a cache keyed by full type name
Write-Host '-- loading ref-assemblies --' -ForegroundColor Yellow
$typeCache = @{}    # full name -> Cecil TypeDefinition
$asms = @()
foreach ($f in Get-ChildItem -Path $RefAsmRoot -Filter 'TaleWorlds.*.dll') {
    try {
        $a = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($f.FullName)
        $asms += $a
        foreach ($t in $a.MainModule.GetTypes()) {
            $typeCache[$t.FullName] = $t
        }
    } catch { Write-Host ('   skipped ' + $f.Name + ': ' + $_.Exception.Message) -ForegroundColor DarkGray }
}
Write-Host ('   loaded {0} assemblies, {1} types' -f $asms.Count, $typeCache.Count) -ForegroundColor Green

# --- Scan source files ---
Write-Host ''
Write-Host '-- scanning source --' -ForegroundColor Yellow
$srcDirs = @(
    (Join-Path $repoRoot 'Bannerlord.Harmony\src\Crest.Harmony'),
    (Join-Path $repoRoot 'Bannerlord.MBOptionScreen\src-ui\Crest.MCM.UI')
)
$claims = New-Object System.Collections.Generic.List[object]
foreach ($d in $srcDirs) {
    if (-not (Test-Path $d)) { continue }
    foreach ($cs in Get-ChildItem -Path $d -Filter '*.cs' -Recurse) {
        $content = Get-Content $cs.FullName -Raw

        # [HarmonyPatch(typeof(X.Y.Z), "Method")] -- extract type FQN + method name
        foreach ($m in [regex]::Matches($content, '\[HarmonyPatch\(typeof\(([\w\.]+)\)\s*,\s*"(\w+)"')) {
            $claims.Add([pscustomobject]@{ Source = $cs.Name; Kind = '[HarmonyPatch attr]'; Type = $m.Groups[1].Value; Method = $m.Groups[2].Value }) | Out-Null
        }
        # AccessTools2.TypeByName("X.Y.Z")
        foreach ($m in [regex]::Matches($content, 'AccessTools2\.TypeByName\("([\w\.]+)"\)')) {
            $claims.Add([pscustomobject]@{ Source = $cs.Name; Kind = 'TypeByName'; Type = $m.Groups[1].Value; Method = '' }) | Out-Null
        }
        # BindPatch(... "X.Y.Z", "Method", ...)  -- our own helper signature
        foreach ($m in [regex]::Matches($content, 'BindPa(?:tch|ostfix)\([^,]+,\s*"([\w\.]+)"\s*,\s*"(\w+)"')) {
            $claims.Add([pscustomobject]@{ Source = $cs.Name; Kind = 'BindPatch helper'; Type = $m.Groups[1].Value; Method = $m.Groups[2].Value }) | Out-Null
        }
    }
}
Write-Host ('   {0} patch claim(s) found' -f $claims.Count) -ForegroundColor Green

# --- Resolve each ---
Write-Host ''
Write-Host '-- resolving against ref-asm --' -ForegroundColor Yellow
$misses = New-Object System.Collections.Generic.List[object]
$hits   = 0
foreach ($c in $claims) {
    $t = $typeCache[$c.Type]
    if (-not $t) {
        $misses.Add([pscustomobject]@{ Source = $c.Source; Kind = $c.Kind; Reason = 'TYPE NOT FOUND'; Type = $c.Type; Method = $c.Method }) | Out-Null
        continue
    }
    if ($c.Method -ne '') {
        $found = $t.Methods | Where-Object { $_.Name -eq $c.Method } | Select-Object -First 1
        if (-not $found) {
            # Also check property getter/setter (get_X / set_X)
            $found = $t.Methods | Where-Object { $_.Name -eq ('get_' + $c.Method) -or $_.Name -eq ('set_' + $c.Method) -or $_.Name -eq $c.Method } | Select-Object -First 1
        }
        if (-not $found) {
            $misses.Add([pscustomobject]@{ Source = $c.Source; Kind = $c.Kind; Reason = 'METHOD NOT FOUND'; Type = $c.Type; Method = $c.Method }) | Out-Null
            continue
        }
    }
    $hits++
}

Write-Host ''
if ($misses.Count -eq 0) {
    Write-Host ('ALL {0} patch targets resolve cleanly against the ref-asm.' -f $hits) -ForegroundColor Green
    Write-Host 'Safe to build / launch.'
} else {
    Write-Host ('{0} hits, {1} MISSES against ref-asm:' -f $hits, $misses.Count) -ForegroundColor Yellow
    foreach ($m in $misses) {
        Write-Host ('   {0,-22}  {1,-50}  {2,-30}  {3}' -f $m.Reason, $m.Type, $m.Method, $m.Source) -ForegroundColor Red
    }
    Write-Host ''
    Write-Host 'Each miss is a Harmony patch that will fail to bind on this game version.'
    Write-Host 'Either fix the patch source (rename the type/method to match the new ref-asm),'
    Write-Host 'or guard with a runtime null-check and log instead of bind.'
    if ($ExitOnMiss) { exit 1 }
}

# Cleanup
foreach ($a in $asms) { try { $a.Dispose() } catch {} }
