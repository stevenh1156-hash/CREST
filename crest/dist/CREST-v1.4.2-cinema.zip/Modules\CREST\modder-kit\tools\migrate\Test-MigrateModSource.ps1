# Test-MigrateModSource.ps1 -- smoke test for Migrate-ModSourceToCrest.ps1
#
# Builds a synthetic mod tree under $env:TEMP, runs the source migrator over
# it, and verifies the rewrites landed correctly. Exits non-zero on any
# mismatch so CI / a developer can run this from a checkout to validate
# changes to the rewriter.

[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$thisDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$migrator = Join-Path $thisDir 'Migrate-ModSourceToCrest.ps1'
if (-not (Test-Path $migrator)) {
    Write-Error "Migrator not found at $migrator"
    exit 2
}

$fixture = Join-Path $env:TEMP "crest-migrate-fixture-$(Get-Random)"
New-Item -ItemType Directory -Path $fixture -Force | Out-Null
Write-Host "Fixture: $fixture" -ForegroundColor DarkGray

try {
    # --- Build a representative source tree ---
    $csprojPath = Join-Path $fixture 'BloodMod1313.csproj'
    @'
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net472</TargetFramework>
    <LangVersion>latest</LangVersion>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Bannerlord.Harmony" Version="2.4.2" />
    <PackageReference Include="Bannerlord.UIExtenderEx" Version="2.13.2" />
    <Reference Include="Bannerlord.ButterLib, Version=2.10.4.0, Culture=neutral, PublicKeyToken=null">
      <HintPath>..\lib\Bannerlord.ButterLib.dll</HintPath>
    </Reference>
    <Reference Include="MCMv5">
      <HintPath>..\lib\MCMv5.dll</HintPath>
    </Reference>
  </ItemGroup>
</Project>
'@ | Set-Content -Path $csprojPath -NoNewline

    $xmlPath = Join-Path $fixture 'SubModule.xml'
    @'
<Module>
  <Name value="BloodMod1313" />
  <Id value="BloodMod1313" />
  <Version value="v1.0.0" />
  <DependedModules>
    <DependedModule Id="Native" />
    <DependedModule Id="Bannerlord.Harmony" Optional="false" />
    <DependedModule Id="Bannerlord.ButterLib" />
    <DependedModule Id="Bannerlord.UIExtenderEx" />
    <DependedModule Id="MCMv5" />
  </DependedModules>
</Module>
'@ | Set-Content -Path $xmlPath -NoNewline

    $csPath = Join-Path $fixture 'SubModule.cs'
    @'
using Bannerlord.Harmony;
using Bannerlord.UIExtenderEx;

namespace BloodMod1313;

public class SubModule
{
    public void Foo()
    {
        var t = System.Type.GetType("Bannerlord.Harmony.SubModule, Bannerlord.Harmony");
        var asm = System.Reflection.Assembly.Load("Bannerlord.UIExtenderEx");
    }
}
'@ | Set-Content -Path $csPath -NoNewline

    # --- Run the migrator ---
    Write-Host ""
    Write-Host "==> Running migrator" -ForegroundColor Cyan
    & $migrator -Path $fixture -Force -NoBackup -IncludeSubModuleXml | Out-Null

    # --- Verify ---
    $errors = @()

    $csprojText = Get-Content $csprojPath -Raw
    if ($csprojText -match 'Bannerlord\.Harmony') { $errors += "csproj still mentions Bannerlord.Harmony" }
    if ($csprojText -match 'Bannerlord\.ButterLib') { $errors += "csproj still mentions Bannerlord.ButterLib" }
    if ($csprojText -match 'Bannerlord\.UIExtenderEx') { $errors += "csproj still mentions Bannerlord.UIExtenderEx" }
    if ($csprojText -match 'MCMv5') { $errors += "csproj still mentions MCMv5" }
    if ($csprojText -notmatch 'Crest\.Harmony') { $errors += "csproj is missing Crest.Harmony" }
    if ($csprojText -notmatch 'Crest\.ButterLib') { $errors += "csproj is missing Crest.ButterLib" }
    if ($csprojText -notmatch 'Crest\.UIExtenderEx') { $errors += "csproj is missing Crest.UIExtenderEx" }
    if ($csprojText -notmatch 'Crest\.MCM') { $errors += "csproj is missing Crest.MCM" }
    # HintPath should be rewritten too
    if ($csprojText -match 'Bannerlord\.ButterLib\.dll') { $errors += "csproj HintPath still has Bannerlord.ButterLib.dll" }
    if ($csprojText -notmatch 'Crest\.ButterLib\.dll') { $errors += "csproj HintPath missing Crest.ButterLib.dll" }

    $xmlText = Get-Content $xmlPath -Raw
    if ($xmlText -match 'Id="Bannerlord\.Harmony"') { $errors += "SubModule.xml still has DependedModule Bannerlord.Harmony" }
    if ($xmlText -match 'Id="Bannerlord\.ButterLib"') { $errors += "SubModule.xml still has DependedModule Bannerlord.ButterLib" }
    if ($xmlText -match 'Id="Bannerlord\.UIExtenderEx"') { $errors += "SubModule.xml still has DependedModule Bannerlord.UIExtenderEx" }
    if ($xmlText -match 'Id="MCMv5"') { $errors += "SubModule.xml still has DependedModule MCMv5" }
    if ($xmlText -notmatch 'Id="CREST"') { $errors += "SubModule.xml missing DependedModule CREST" }
    if ($xmlText -notmatch 'Id="Native"') { $errors += "SubModule.xml lost the Native DependedModule (regression)" }

    # .cs file should be UNCHANGED (string contents only reported, not rewritten).
    # Anchor on each upstream-name reference we put into the fixture; if any of
    # them got rewritten, that's a regression in the migrator's "report only"
    # contract for source files.
    $csText = Get-Content $csPath -Raw
    if ($csText -notmatch 'using Bannerlord\.Harmony;')                          { $errors += ".cs lost 'using Bannerlord.Harmony;'" }
    if ($csText -notmatch 'using Bannerlord\.UIExtenderEx;')                     { $errors += ".cs lost 'using Bannerlord.UIExtenderEx;'" }
    if ($csText -notmatch '"Bannerlord\.Harmony\.SubModule, Bannerlord\.Harmony"') { $errors += ".cs assembly-qualified type string was modified (should be report-only)" }
    if ($csText -notmatch 'Assembly\.Load\("Bannerlord\.UIExtenderEx"\)')        { $errors += '.cs Assembly.Load("Bannerlord.UIExtenderEx") was modified (should be report-only)' }

    if ($errors.Count -gt 0) {
        Write-Host ""
        Write-Host "==> FAIL" -ForegroundColor Red
        $errors | ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
        Write-Host ""
        Write-Host "Final csproj:" -ForegroundColor DarkGray
        Write-Host $csprojText
        Write-Host ""
        Write-Host "Final SubModule.xml:" -ForegroundColor DarkGray
        Write-Host $xmlText
        exit 1
    }

    Write-Host ""
    Write-Host "==> PASS" -ForegroundColor Green
    Write-Host "  csproj rewrites OK (4 references migrated, HintPaths updated)" -ForegroundColor Green
    Write-Host "  SubModule.xml rewrites OK (Bannerlord.Harmony -> CREST; ButterLib/UIExtenderEx/MCMv5 removed; Native preserved)" -ForegroundColor Green
    Write-Host "  .cs file unchanged (string contents reported only, as designed)" -ForegroundColor Green
    exit 0
}
finally {
    if (Test-Path $fixture) { Remove-Item -Recurse -Force $fixture }
}
