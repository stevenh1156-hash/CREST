# Crest-Compat.ps1 -- compatibility-risk auto-fix tool
#
# Pairs with Crest-Doctor's "Compatibility risks" section. The doctor flags
# concerns; this tool attempts to fix them where it's safe to do so.
#
# Two classes of fix:
#
#   1. Bundled-Harmony / Cecil / MonoMod collisions (SAFE, reversible)
#      Some community mods bundle their own copy of 0Harmony.dll (and
#      Cecil/MonoMod). CREST always ships these, and the CLR loads only one
#      copy per AppDomain regardless. The mod's own copy is at best dead
#      weight (~2-4 MB per mod) and at worst causes subtle patch-conflict
#      bugs if its version differs.
#      Fix: rename the duplicate to <name>.crest-disabled. Reversible by
#      hand (or via -Restore).
#
#   2. TaleWorlds DLL overrides (RISKY by default, only fix when hash-match)
#      A module that ships TaleWorlds.*.dll in its bin\ is overriding the
#      engine. Some mods (RBM) do this deliberately to rewrite combat; the
#      DLLs contain the mod's actual code. Removing them breaks the mod.
#      Other mods do it accidentally, redistributing the game's pristine
#      DLL with no changes. Hash-comparing the override against the game's
#      own copy in bin\Win64_Shipping_Client\ tells us which case we're in.
#      Fix: only when hash matches (= identical-content redistribution),
#      rename the redundant copy. Differing hashes are reported but not
#      touched.
#
# Usage:
#   .\Crest-Compat.ps1                     Dry-run: scan + report what would
#                                          be fixed; write nothing.
#   .\Crest-Compat.ps1 -Fix                Apply fixes (rename duplicates).
#   .\Crest-Compat.ps1 -Fix -Mod RBM       Fix only the named module.
#   .\Crest-Compat.ps1 -Restore            Revert all *.crest-disabled
#                                          files in Modules\X\bin\ back to
#                                          their original names.

[CmdletBinding()]
param(
    [string]$GameRoot = 'C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord',
    [string]$Mod,
    [switch]$Fix,
    [switch]$Restore
)

$ErrorActionPreference = 'Continue'

if (-not (Test-Path $GameRoot)) {
    Write-Error "Game root not found: $GameRoot"
    exit 1
}

$modulesDir = Join-Path $GameRoot 'Modules'
$gameTwBin = Join-Path $GameRoot 'bin\Win64_Shipping_Client'
if (-not (Test-Path $modulesDir)) {
    Write-Error "Modules\ not found at $modulesDir"
    exit 1
}

$disabledSuffix = '.crest-disabled'

# Names that are always safe to disable in a non-CREST module's bin (they
# duplicate what CREST ships at the canonical location):
$alwaysSafeNames = @(
    '0Harmony.dll', '0Harmony.pdb', '0Harmony.xml',
    'Mono.Cecil.dll', 'Mono.Cecil.Mdb.dll', 'Mono.Cecil.Pdb.dll', 'Mono.Cecil.Rocks.dll',
    'MonoMod.Core.dll', 'MonoMod.Utils.dll', 'MonoMod.Backports.dll',
    'MonoMod.Iced.dll', 'MonoMod.ILHelpers.dll', 'MonoMod.RuntimeDetour.dll'
)

# First-party Bannerlord modules. Their TaleWorlds.*.dll content IS the
# canonical engine code (Bannerlord ships its own gameplay split across
# these), so we never flag those as "overrides" -- they're not.
$firstPartyModules = @(
    'Native', 'SandBox', 'SandBoxCore', 'StoryMode',
    'CustomBattle', 'Multiplayer', 'BirthAndDeath', 'NavalDLC', 'FastMode'
)

# ============================================================
# Restore mode
# ============================================================
if ($Restore) {
    Write-Host "==> Restoring *$disabledSuffix files" -ForegroundColor Cyan
    $restored = 0
    $modulesToScan = if ($Mod) { @($Mod) } else { (Get-ChildItem $modulesDir -Directory).Name }
    foreach ($modName in $modulesToScan) {
        $bin = Join-Path $modulesDir ($modName + '\bin\Win64_Shipping_Client')
        if (-not (Test-Path $bin)) { continue }
        $disabled = Get-ChildItem $bin -Filter ('*' + $disabledSuffix) -File -ErrorAction SilentlyContinue
        foreach ($d in $disabled) {
            $original = $d.FullName.Substring(0, $d.FullName.Length - $disabledSuffix.Length)
            if (Test-Path $original) {
                Write-Host ("  skip   " + $modName + "\..\" + $d.Name + " (original already exists)") -ForegroundColor Yellow
                continue
            }
            Move-Item -Path $d.FullName -Destination $original
            Write-Host ("  restore " + $modName + "\..\" + (Split-Path $original -Leaf)) -ForegroundColor Green
            $restored++
        }
    }
    Write-Host ""
    Write-Host ("==> Restored $restored file(s)") -ForegroundColor Green
    exit 0
}

# ============================================================
# Scan / fix mode
# ============================================================
$plan = @()  # one entry per fix action

$modulesToScan = if ($Mod) {
    @((Get-Item (Join-Path $modulesDir $Mod) -ErrorAction SilentlyContinue))
} else {
    Get-ChildItem $modulesDir -Directory | Where-Object { $_.Name -ne 'CREST' }
}

foreach ($d in $modulesToScan) {
    if ($d -eq $null) { continue }
    $bin = Join-Path $d.FullName 'bin\Win64_Shipping_Client'
    if (-not (Test-Path $bin)) { continue }

    # ---- Always-safe: duplicate Harmony / Cecil / MonoMod ----
    foreach ($name in $alwaysSafeNames) {
        $p = Join-Path $bin $name
        if (-not (Test-Path $p)) { continue }
        $f = Get-Item $p
        $plan += [pscustomobject]@{
            Module = $d.Name
            Path = $p
            Name = $name
            Action = 'rename-disable'
            Reason = "duplicate of CREST-shipped DLL ($([math]::Round($f.Length / 1KB)) KB)"
            Safety = 'safe'
        }
    }

    # ---- TaleWorlds.*.dll overrides ----
    # Skip Bannerlord's own first-party modules -- their TaleWorlds.*.dll is
    # the canonical engine code, not an override.
    if ($firstPartyModules -contains $d.Name) { continue }
    $twDlls = Get-ChildItem $bin -Filter 'TaleWorlds.*.dll' -File -ErrorAction SilentlyContinue
    foreach ($f in $twDlls) {
        # The canonical copy of a TaleWorlds.X.dll might live in:
        #   - Game's bin\Win64_Shipping_Client\ (most TaleWorlds.* assemblies)
        #   - A first-party module's bin\Win64_Shipping_Client\ (e.g.,
        #     TaleWorlds.MountAndBlade.CustomBattle.dll lives in
        #     Modules\CustomBattle\bin\, not the game's bin)
        # Different first-party modules can ship DIFFERENT-content copies of
        # the same filename (e.g., Multiplayer.dll differs between CustomBattle
        # and Multiplayer bins) -- so we hash against EVERY existing canonical
        # and mark SAFE if ANY of them matches. Otherwise the script would
        # produce false RISKY hits whenever priority-order picks the wrong one.
        $candidatePaths = @()
        $candidate = Join-Path $gameTwBin $f.Name
        if (Test-Path $candidate) { $candidatePaths += $candidate }
        foreach ($fp in $firstPartyModules) {
            $candidate = Join-Path $modulesDir ($fp + '\bin\Win64_Shipping_Client\' + $f.Name)
            if (Test-Path $candidate) { $candidatePaths += $candidate }
        }

        $action = ''
        $reason = ''
        $safety = 'risky'
        if ($candidatePaths.Count -gt 0) {
            try {
                $modHash = (Get-FileHash $f.FullName -Algorithm SHA256).Hash
                $matched = $null
                foreach ($cp in $candidatePaths) {
                    $cHash = (Get-FileHash $cp -Algorithm SHA256).Hash
                    if ($cHash -eq $modHash) { $matched = $cp; break }
                }
                if ($matched) {
                    # Resolve "<owner>" = the module name 3 levels up from the DLL
                    # (path layout: <module>\bin\Win64_Shipping_Client\<dll>).
                    if ($matched -eq (Join-Path $gameTwBin $f.Name)) {
                        $owner = 'game bin'
                    } else {
                        $owner = Split-Path (Split-Path (Split-Path $matched -Parent) -Parent) -Parent | Split-Path -Leaf
                        if (-not $owner) { $owner = 'unknown' }
                    }
                    $action = 'rename-disable'
                    $reason = "identical-content override (SHA256 matches $owner's $($f.Name))"
                    $safety = 'safe'
                } else {
                    $locations = ($candidatePaths | ForEach-Object {
                        if ($_ -eq (Join-Path $gameTwBin $f.Name)) {
                            'game bin'
                        } else {
                            $modName = Split-Path (Split-Path (Split-Path $_ -Parent) -Parent) -Parent | Split-Path -Leaf
                            if ($modName) { $modName } else { 'unknown' }
                        }
                    }) -join ', '
                    $action = 'report-only'
                    $reason = "differs from all canonical copies ($locations) -- mod likely depends on this override"
                    $safety = 'risky'
                }
            } catch {
                $action = 'report-only'
                $reason = "could not hash-compare: $($_.Exception.Message)"
                $safety = 'risky'
            }
        } else {
            $action = 'report-only'
            $reason = "no canonical $($f.Name) found in game bin or first-party modules -- unusual"
            $safety = 'risky'
        }
        $plan += [pscustomobject]@{
            Module = $d.Name
            Path = $f.FullName
            Name = $f.Name
            Action = $action
            Reason = $reason
            Safety = $safety
        }
    }
}

if ($plan.Count -eq 0) {
    Write-Host "==> No compatibility issues found." -ForegroundColor Green
    exit 0
}

Write-Host ""
Write-Host "==> Compatibility issues found" -ForegroundColor Cyan

$grouped = $plan | Group-Object Module
foreach ($g in $grouped) {
    Write-Host ""
    Write-Host ("---- " + $g.Name + " ----") -ForegroundColor White
    foreach ($p in $g.Group) {
        $tag = if ($p.Safety -eq 'safe') { '[SAFE]   ' } else { '[RISKY]  ' }
        $color = if ($p.Safety -eq 'safe') { 'Green' } else { 'Yellow' }
        Write-Host ("  " + $tag + $p.Name + "  --  " + $p.Reason) -ForegroundColor $color
    }
}

$safeCount = ($plan | Where-Object { $_.Safety -eq 'safe' }).Count
$riskyCount = ($plan | Where-Object { $_.Safety -eq 'risky' }).Count
Write-Host ""
Write-Host ("Summary: " + $safeCount + " safe to fix, " + $riskyCount + " require manual review") -ForegroundColor Cyan

if (-not $Fix) {
    Write-Host ""
    Write-Host "==> Dry-run only. Re-run with -Fix to apply safe fixes (rename to *$disabledSuffix)." -ForegroundColor Yellow
    Write-Host "    To revert later: Crest-Compat.ps1 -Restore" -ForegroundColor DarkGray
    exit 0
}

# Apply
Write-Host ""
Write-Host "==> Applying safe fixes" -ForegroundColor Cyan
$applied = 0
foreach ($p in $plan) {
    if ($p.Safety -ne 'safe') { continue }
    if ($p.Action -ne 'rename-disable') { continue }
    $newPath = $p.Path + $disabledSuffix
    if (Test-Path $newPath) {
        Write-Host ("  skip   " + $p.Module + "\..\" + $p.Name + " (already disabled)") -ForegroundColor DarkGray
        continue
    }
    Move-Item -Path $p.Path -Destination $newPath
    Write-Host ("  disabled " + $p.Module + "\..\" + $p.Name) -ForegroundColor Green
    $applied++
}

Write-Host ""
Write-Host ("==> Disabled $applied file(s).") -ForegroundColor Green
if ($riskyCount -gt 0) {
    Write-Host ("    $riskyCount risky item(s) reported but not touched. Review manually.") -ForegroundColor Yellow
}
Write-Host "    To revert: Crest-Compat.ps1 -Restore" -ForegroundColor DarkGray
