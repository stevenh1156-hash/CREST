<#
.SYNOPSIS
    Scaffold a new Bannerlord mod that builds against CREST.

.DESCRIPTION
    Phase Y.9: generates a complete, buildable mod skeleton in one call.

    Drops a directory tree at the chosen path containing:
      <Name>.sln                         Solution wrapper for VS / Rider.
      src\<Name>\<Name>.csproj           Multi-targets net472 + net6 with refs to Crest.Harmony / Crest.ButterLib / Crest.MCM.
      src\<Name>\SubModule.cs            MBSubModuleBase boilerplate that calls CrestDiag.Log + applies Harmony patches via CrestSafeBind.
      src\<Name>\Patches\ExamplePatch.cs Example postfix patch to demonstrate CrestSafeBind usage.
      ModuleData\                        Empty folder (where XML game data goes if you need it).
      SubModule.xml                      DependedModules: CREST, ModuleCategory: Singleplayer.
      Build-And-Deploy.ps1               One-button build + copy-to-game script.
      README.md                          Quickstart pointing at MODDING.md.
      .gitignore                         Standard .NET ignores + bin/ obj/ + game-side deploy log.

    Then prints the dev-loop instructions: cd, edit, run Build-And-Deploy.ps1, launch.

.PARAMETER Name
    The mod's display name and namespace. Whitespace and punctuation are stripped
    when used for filenames / namespace / module ID; original kept for the Display Name.

.PARAMETER Path
    Where to place the new mod. Defaults to C:\dev\bannerlord\<Name>.

.PARAMETER GameVersion
    Bannerlord game version this mod targets. Defaults to 1.4.2 (current).
    Used in the SubModule.xml's <DependedModuleMetadatas> ApplicationVersion field.

.EXAMPLE
    .\Crest-NewMod.ps1 -Name "MySpeedTweak"
    Scaffolds C:\dev\bannerlord\MySpeedTweak\, ready to build with CREST as a dependency.

.EXAMPLE
    .\Crest-NewMod.ps1 -Name "Better Caravans" -Path C:\projects\BetterCaravans
    Custom path; spaces in name are removed for the C# identifier ("BetterCaravans") but kept for display.

.NOTES
    Requires a working CREST install at C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules\CREST\
    (or wherever Steam dropped the game; auto-detected via the Modules\CREST\bin\Win64_Shipping_Client\Crest.Harmony.dll path).
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Name,

    [string]$Path,

    [string]$GameVersion = '1.4.2'
)

$ErrorActionPreference = 'Stop'

# === Sanitize names ===
$Display = $Name.Trim()
# Strip spaces / non-identifier chars to get a C# namespace-safe id
$Id = ($Display -replace '[^A-Za-z0-9]', '')
if ($Id.Length -eq 0) { throw "Name '$Name' has no identifier-safe characters." }
if ($Id -match '^\d') { $Id = '_' + $Id }

if (-not $Path) { $Path = Join-Path 'C:\dev\bannerlord' $Id }

# === Locate CREST install ===
$crestRoot = 'C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules\CREST'
$crestBin  = Join-Path $crestRoot 'bin\Win64_Shipping_Client'
if (-not (Test-Path (Join-Path $crestBin 'Crest.Harmony.dll'))) {
    Write-Warning "CREST not found at $crestBin -- generated csproj HintPaths will still point there but won't resolve until CREST is installed."
}

# === Plan output ===
if (Test-Path $Path) {
    $children = Get-ChildItem $Path -ErrorAction SilentlyContinue
    if ($children -and $children.Count -gt 0) {
        throw "Target path '$Path' already exists and is non-empty. Pick a different path or delete the existing directory."
    }
} else {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
}

$src   = Join-Path $Path "src\$Id"
New-Item -ItemType Directory -Path $src -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $src 'Patches') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Path 'ModuleData') -Force | Out-Null

# === Generate files ===

# csproj
@"
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <TargetFrameworks>net472;net6</TargetFrameworks>
    <LangVersion>latest</LangVersion>
    <Nullable>enable</Nullable>
    <Platforms>x64</Platforms>
    <AssemblyName>$Id</AssemblyName>
    <RootNamespace>$Id</RootNamespace>
    <Configurations>Debug;Release</Configurations>
  </PropertyGroup>

  <!--
    CREST and TaleWorlds DLL references. HintPaths assume the default Steam
    install. Override via msbuild property: -p:CrestBin=...\bin\Win64_Shipping_Client
                                          -p:GameBin=...\bin\Win64_Shipping_Client
  -->
  <PropertyGroup>
    <CrestBin Condition="'`$(CrestBin)' == ''">C:\Program Files (x86)\Steam\steamapps\common\Mount &amp; Blade II Bannerlord\Modules\CREST\bin\Win64_Shipping_Client</CrestBin>
    <GameBin  Condition="'`$(GameBin)'  == ''">C:\Program Files (x86)\Steam\steamapps\common\Mount &amp; Blade II Bannerlord\bin\Win64_Shipping_Client</GameBin>
  </PropertyGroup>

  <ItemGroup>
    <!-- CREST forks -->
    <Reference Include="Crest.Harmony">      <HintPath>`$(CrestBin)\Crest.Harmony.dll</HintPath>      <Private>false</Private> </Reference>
    <Reference Include="Crest.ButterLib">    <HintPath>`$(CrestBin)\Crest.ButterLib.dll</HintPath>    <Private>false</Private> </Reference>
    <Reference Include="Crest.MCM">          <HintPath>`$(CrestBin)\Crest.MCM.dll</HintPath>          <Private>false</Private> </Reference>
    <Reference Include="Crest.UIExtenderEx"> <HintPath>`$(CrestBin)\Crest.UIExtenderEx.dll</HintPath> <Private>false</Private> </Reference>

    <!-- Harmony, the underlying patching library -->
    <Reference Include="0Harmony"> <HintPath>`$(CrestBin)\0Harmony.dll</HintPath> <Private>false</Private> </Reference>

    <!-- TaleWorlds (game) -->
    <Reference Include="TaleWorlds.Library">         <HintPath>`$(GameBin)\TaleWorlds.Library.dll</HintPath>         <Private>false</Private> </Reference>
    <Reference Include="TaleWorlds.Core">            <HintPath>`$(GameBin)\TaleWorlds.Core.dll</HintPath>            <Private>false</Private> </Reference>
    <Reference Include="TaleWorlds.Localization">    <HintPath>`$(GameBin)\TaleWorlds.Localization.dll</HintPath>    <Private>false</Private> </Reference>
    <Reference Include="TaleWorlds.MountAndBlade">   <HintPath>`$(GameBin)\TaleWorlds.MountAndBlade.dll</HintPath>   <Private>false</Private> </Reference>
    <Reference Include="TaleWorlds.CampaignSystem">  <HintPath>`$(GameBin)\TaleWorlds.CampaignSystem.dll</HintPath>  <Private>false</Private> </Reference>
  </ItemGroup>

</Project>
"@ | Set-Content -Path (Join-Path $src "$Id.csproj") -Encoding UTF8

# SubModule.cs
@"
using Bannerlord.Harmony;
using HarmonyLib;
using TaleWorlds.MountAndBlade;

namespace $Id
{
    /// <summary>
    /// $Display SubModule entry point. CREST loads first via the SubModule.xml
    /// DependedModules list, so by the time this runs, CrestDiag and CrestSafeBind
    /// are available.
    /// </summary>
    public class SubModule : MBSubModuleBase
    {
        private const string Source = nameof(SubModule);
        private static readonly Harmony _harmony = new("$Id");

        protected override void OnSubModuleLoad()
        {
            base.OnSubModuleLoad();
            CrestDiag.Log(Source, "loading $Display");
            ApplyPatches();
        }

        private void ApplyPatches()
        {
            // Example: bind a postfix on MobileParty.CalculateSpeed via CrestSafeBind.
            // Tolerant of missing types/methods; logs to Modules\CREST\runtime.log.
            CrestSafeBind.Patch(_harmony,
                type:    "TaleWorlds.CampaignSystem.Party.MobileParty",
                method:  "CalculateSpeed",
                postfix: nameof(Patches.ExamplePatch.SpeedPostfix),
                owner:   typeof(Patches.ExamplePatch),
                label:   "$Id.SpeedExample");
        }
    }
}
"@ | Set-Content -Path (Join-Path $src 'SubModule.cs') -Encoding UTF8

# Example patch
@"
using Bannerlord.Harmony;

namespace $Id.Patches
{
    /// <summary>
    /// Example postfix patch: read a config flag from crest.json and apply
    /// a small speed bonus when it's enabled. Demonstrates CrestConfig usage,
    /// fail-safe defaults, and the standard CREST diagnostic pattern.
    ///
    /// To enable in-game, add to Modules\CREST\crest.json:
    ///   "$Id_SpeedBonus": true
    /// then restart Bannerlord.
    /// </summary>
    public static class ExamplePatch
    {
        public static void SpeedPostfix(ref float __result)
        {
            // Default false -- the bonus stays off unless the user opts in.
            if (!CrestConfig.IsEnabled("$Id" + "_SpeedBonus", defaultValue: false)) return;
            __result += 0.5f;  // small bonus to all party speed
        }
    }
}
"@ | Set-Content -Path (Join-Path $src 'Patches\ExamplePatch.cs') -Encoding UTF8

# SubModule.xml
@"
<?xml version="1.0" encoding="UTF-8"?>
<Module>
  <Id value="$Id" />
  <Name value="$Display" />
  <Version value="v1.0.0" />
  <DefaultModule value="false" />
  <ModuleCategory value="Singleplayer" />
  <ModuleType value="Community" />
  <DependedModules>
    <DependedModule Id="CREST" />
    <DependedModule Id="Native" />
    <DependedModule Id="SandBoxCore" />
    <DependedModule Id="Sandbox" />
  </DependedModules>
  <DependedModuleMetadatas>
    <DependedModuleMetadata id="CREST" order="LoadBeforeThis" version="*" />
    <DependedModuleMetadata id="Native" order="LoadBeforeThis" version="$GameVersion.*" />
  </DependedModuleMetadatas>
  <SubModules>
    <SubModule>
      <Name value="$Display" />
      <DLLName value="$Id.dll" />
      <SubModuleClassType value="$Id.SubModule" />
      <Tags />
    </SubModule>
  </SubModules>
</Module>
"@ | Set-Content -Path (Join-Path $Path 'SubModule.xml') -Encoding UTF8

# Build-And-Deploy.ps1
@"
<#
.SYNOPSIS
    Build $Display and copy the DLL into the Bannerlord Modules folder.

.DESCRIPTION
    Builds both target frameworks (net472 for Steam, net6 for Game Pass) and
    deploys per-runtime to the matching bin\<runtime> folder. Uses explicit
    per-TFM copies so the LastWriteTime-tie-break bug that bit CREST early on
    cannot recur.
#>
param(
    [string]`$ModuleName = '$Id',
    [string]`$GameRoot   = 'C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord'
)
`$ErrorActionPreference = 'Stop'

`$proj = Join-Path `$PSScriptRoot ('src\' + `$ModuleName + '\' + `$ModuleName + '.csproj')
& dotnet build `$proj -c Release -v minimal
if (`$LASTEXITCODE -ne 0) { throw 'build failed' }

# Make sure the target Modules\<ModuleName>\ folder + bin tree exists
`$modRoot = Join-Path `$GameRoot ('Modules\' + `$ModuleName)
foreach (`$rt in @('Win64_Shipping_Client','Gaming.Desktop.x64_Shipping_Client')) {
    New-Item -ItemType Directory -Path (Join-Path `$modRoot ('bin\' + `$rt)) -Force | Out-Null
}

# Copy SubModule.xml
Copy-Item (Join-Path `$PSScriptRoot 'SubModule.xml') (Join-Path `$modRoot 'SubModule.xml') -Force

# Copy DLL per runtime (net472 -> Win64, net6 -> Gaming.Desktop)
`$src472 = Join-Path `$PSScriptRoot ('src\' + `$ModuleName + '\bin\Release\net472\' + `$ModuleName + '.dll')
`$src6   = Join-Path `$PSScriptRoot ('src\' + `$ModuleName + '\bin\Release\net6\'   + `$ModuleName + '.dll')
if (Test-Path `$src472) { Copy-Item `$src472 (Join-Path `$modRoot ('bin\Win64_Shipping_Client\' + `$ModuleName + '.dll')) -Force }
if (Test-Path `$src6)   { Copy-Item `$src6   (Join-Path `$modRoot ('bin\Gaming.Desktop.x64_Shipping_Client\' + `$ModuleName + '.dll')) -Force }

# Optional ModuleData copy
`$mdSrc = Join-Path `$PSScriptRoot 'ModuleData'
if (Test-Path `$mdSrc) {
    Copy-Item `$mdSrc -Destination `$modRoot -Recurse -Force
}

Write-Host ('Deployed ' + `$ModuleName + ' to ' + `$modRoot) -ForegroundColor Green
Write-Host 'Now launch Bannerlord, enable the mod in the launcher, and start a campaign.'
"@ | Set-Content -Path (Join-Path $Path 'Build-And-Deploy.ps1') -Encoding UTF8

# README.md
@"
# $Display

A Bannerlord mod built on top of [CREST](https://github.com/your/CREST).

## Quickstart

```powershell
# Build and deploy in one step:
.\Build-And-Deploy.ps1
```

Then launch Bannerlord, enable **$Display** in the mod launcher (it'll show up
under the Community section), and start a campaign.

## What's in here

- ``src/$Id/SubModule.cs`` — the mod's entry point. Inherits ``MBSubModuleBase``.
- ``src/$Id/Patches/ExamplePatch.cs`` — example Harmony postfix that adds a
  small party-speed bonus when the ``$Id`` + ``_SpeedBonus`` flag is true in
  ``Modules/CREST/crest.json``. Delete or rename this file once you've got
  your real patches in.
- ``SubModule.xml`` — declares this mod's metadata and lists CREST as a
  dependency. The launcher renders this.
- ``Build-And-Deploy.ps1`` — build + copy to ``Modules\$Id\``.

## CREST APIs available to you

- ``CrestDiag.Log(source, message)`` — append a line to ``Modules/CREST/runtime.log``.
- ``CrestConfig.IsEnabled(key, defaultValue)`` — read a bool flag from ``crest.json``.
- ``CrestConfig.GetFloat(key, defaultValue)`` / ``GetInt`` / ``GetString`` — typed reads.
- ``CrestSafeBind.Patch(harmony, type, method, prefix/postfix, owner, label)`` —
  bind a Harmony patch with crash-tolerant type/method resolution and
  Crest-Doctor registration. **Use this instead of raw ``harmony.Patch``** so
  your mod gracefully handles game-version updates that rename targets.

For the full guide see ``MODDING.md`` in the CREST repo.
"@ | Set-Content -Path (Join-Path $Path 'README.md') -Encoding UTF8

# .gitignore
@"
# Build outputs
bin/
obj/
*.user
.vs/

# Game-side deploy artifacts (these go into the actual Modules folder, not committed here)
deploy.log

# Editor metadata
*.suo
.idea/

# OS junk
Thumbs.db
.DS_Store
"@ | Set-Content -Path (Join-Path $Path '.gitignore') -Encoding UTF8

# Solution file -- minimal but enough for VS / Rider to open
$slnGuid = [guid]::NewGuid().ToString().ToUpper()
$projGuid = [guid]::NewGuid().ToString().ToUpper()
@"
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.0.31903.59
MinimumVisualStudioVersion = 10.0.40219.1
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "$Id", "src\$Id\$Id.csproj", "{$projGuid}"
EndProject
Global
    GlobalSection(SolutionConfigurationPlatforms) = preSolution
        Debug|x64 = Debug|x64
        Release|x64 = Release|x64
    EndGlobalSection
    GlobalSection(ProjectConfigurationPlatforms) = postSolution
        {$projGuid}.Debug|x64.ActiveCfg = Debug|x64
        {$projGuid}.Debug|x64.Build.0 = Debug|x64
        {$projGuid}.Release|x64.ActiveCfg = Release|x64
        {$projGuid}.Release|x64.Build.0 = Release|x64
    EndGlobalSection
EndGlobal
"@ | Set-Content -Path (Join-Path $Path "$Id.sln") -Encoding UTF8

# === Print summary ===
Write-Host ''
Write-Host ('Scaffolded ' + $Display + ' at ' + $Path) -ForegroundColor Green
Write-Host ''
Write-Host 'Next steps:' -ForegroundColor Cyan
Write-Host ('  cd ' + $Path)
Write-Host '  # edit src\' $Id '\Patches\ExamplePatch.cs to your liking'
Write-Host '  .\Build-And-Deploy.ps1'
Write-Host '  # then launch Bannerlord and enable the mod'
Write-Host ''
Write-Host 'Modder API reference: see MODDING.md in the CREST repo.' -ForegroundColor DarkGray
