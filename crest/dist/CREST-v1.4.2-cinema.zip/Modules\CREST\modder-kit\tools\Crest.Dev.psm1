# =============================================================================
# Crest.Dev.psm1
# Helper module for working on the CREST Bannerlord modding stack.
#
# Import via: Import-Module C:\dev\bannerlord\crest\tools\Crest.Dev.psm1 -Force
#
# Functions:
#   Get-CrestStatus           - branch/SHA/dirty state for all four repos
#   Get-CrestRepo             - look up a repo descriptor by name
#   Build-CrestRepo           - dotnet build one repo (with right configs)
#   Build-AllCrestRepos       - build all four in dependency order
#   Test-CrestNamespaces     - cross-fork sanity grep
#   Commit-CrestRepo          - git commit on the crest branch with a message
#   Get-CrestArtifacts        - list built DLLs across all repos
# =============================================================================

# Phase P.1 (M1): paths are env-overridable so the module isn't pinned to one
# dev's machine layout. Defaults preserve the original hardcoded values for
# the current dev box; setting either variable in the shell or via .env.ps1
# overrides without editing this file.
$script:CrestRoot           = if ($env:CREST_ROOT) { $env:CREST_ROOT } else { 'C:\dev\bannerlord' }
$script:GameFolder          = if ($env:CREST_GAME_FOLDER) { $env:CREST_GAME_FOLDER } else { 'C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord' }
$script:GameVersion         = if ($env:CREST_GAME_VERSION) { $env:CREST_GAME_VERSION } else { 'v1.4.1' }
$script:GameVersionConstant = if ($env:CREST_GAME_VERSION_CONSTANT) { $env:CREST_GAME_VERSION_CONSTANT } else { 'v141' }
# NOTE: Bumped to v1.4.2 briefly during Phase U.1b but reverted because BUTR
# hadn't yet published Bannerlord.ReferenceAssemblies.Core 1.4.2.* on NuGet
# at the time of the rebuild attempt -- ButterLib.Implementation's restore
# step timed out. Set $env:CREST_GAME_VERSION='v1.4.2' / CREST_GAME_VERSION_CONSTANT='v142'
# manually once those packages ship to test the rebuild without editing this file.

# Build dependency order. Each repo has 1+ projects. ExtraArgs uses tokens
# expanded at build time:
#   NeedsGameVersion -> -p:OverrideGameVersion=...,-p:GameVersionConstant=...
$script:CrestRepos = @(
    [pscustomobject]@{
        Name = 'Harmony'
        Path = "$script:CrestRoot\Bannerlord.Harmony"
        Projects = @(
            [pscustomobject]@{ Label='Main'; Csproj='src/Crest.Harmony/Crest.Harmony.csproj'; Config='Release'; ExtraArgs=@() }
        )
    },
    [pscustomobject]@{
        Name = 'ButterLib'
        Path = "$script:CrestRoot\Bannerlord.ButterLib"
        Projects = @(
            [pscustomobject]@{ Label='Main';           Csproj='src/Crest.ButterLib/Crest.ButterLib.csproj';                       Config='Release';        ExtraArgs=@('NeedsGameVersion') },
            [pscustomobject]@{ Label='Implementation'; Csproj='src/Crest.ButterLib.Implementation/Crest.ButterLib.Implementation.csproj'; Config='Stable_Release'; ExtraArgs=@('NeedsGameVersion') }
        )
    },
    [pscustomobject]@{
        Name = 'UIExtenderEx'
        Path = "$script:CrestRoot\Bannerlord.UIExtenderEx"
        Projects = @(
            [pscustomobject]@{ Label='Main'; Csproj='src/Crest.UIExtenderEx/Crest.UIExtenderEx.csproj'; Config='Release'; ExtraArgs=@() }
        )
    },
    [pscustomobject]@{
        Name = 'MCM'
        Path = "$script:CrestRoot\Bannerlord.MBOptionScreen"
        Projects = @(
            [pscustomobject]@{ Label='Main'; Csproj='src/Crest.MCM/Crest.MCM.csproj';        Config='Release';        ExtraArgs=@('NeedsGameVersion') },
            [pscustomobject]@{ Label='UI';   Csproj='src-ui/Crest.MCM.UI/Crest.MCM.UI.csproj'; Config='Stable_Release'; ExtraArgs=@('NeedsGameVersion','-p:ExtendedBuild=false') }
        )
    }
)

function Get-CrestRepo {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('Harmony','ButterLib','UIExtenderEx','MCM')]
        [string]$Name
    )
    $script:CrestRepos | Where-Object { $_.Name -eq $Name }
}

function Get-CrestStatus {
    [CmdletBinding()]
    param()
    Write-Host ("{0,-15} {1,-8} {2,-8} {3,-7} {4}" -f 'Repo','Branch','SHA','Dirty','Last commit') -ForegroundColor White
    Write-Host ('-' * 96)
    foreach ($r in $script:CrestRepos) {
        if (-not (Test-Path $r.Path)) {
            Write-Host ("{0,-15} (path not found: {1})" -f $r.Name, $r.Path) -ForegroundColor Red
            continue
        }
        Push-Location $r.Path
        try {
            $branch = (git rev-parse --abbrev-ref HEAD 2>$null).Trim()
            $sha = (git rev-parse --short HEAD 2>$null).Trim()
            $dirty = (git status --short 2>$null)
            $dirtyCount = if ($dirty) { @($dirty | Where-Object { $_ }).Count } else { 0 }
            $msg = (git log -1 --pretty=%s 2>$null).Trim()
            $msgShort = if ($msg.Length -gt 50) { $msg.Substring(0,50) + '...' } else { $msg }
            $color = 'White'
            if ($branch -eq 'crest' -and $dirtyCount -eq 0) { $color = 'Green' }
            elseif ($dirtyCount -gt 0)                      { $color = 'Yellow' }
            Write-Host ("{0,-15} {1,-8} {2,-8} {3,-7} {4}" -f $r.Name, $branch, $sha, $dirtyCount, $msgShort) -ForegroundColor $color
        }
        finally { Pop-Location }
    }
}

function Build-CrestRepo {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('Harmony','ButterLib','UIExtenderEx','MCM')]
        [string]$Name,
        [switch]$Clean,
        [switch]$Loud
    )
    $repo = Get-CrestRepo -Name $Name
    if (-not $repo) { throw "Unknown repo: $Name" }

    Push-Location $repo.Path
    try {
        if ($Clean) {
            Write-Host "  cleaning bin/obj..." -ForegroundColor DarkGray
            $dirs = @()
            foreach ($root in @('src','src-ui','tests')) {
                if (Test-Path $root) {
                    $dirs += Get-ChildItem -Recurse -Directory -Path $root -ErrorAction SilentlyContinue |
                        Where-Object { $_.Name -in 'bin','obj' }
                }
            }
            $dirs | ForEach-Object { Remove-Item -Recurse -Force $_.FullName -ErrorAction SilentlyContinue }
        }

        $allOk = $true
        foreach ($proj in $repo.Projects) {
            $extra = @()
            foreach ($e in $proj.ExtraArgs) {
                if ($e -eq 'NeedsGameVersion') {
                    $extra += "-p:OverrideGameVersion=$script:GameVersion"
                    $extra += "-p:GameVersionConstant=$script:GameVersionConstant"
                } else {
                    $extra += $e
                }
            }
            $verbosity = if ($Loud) { 'normal' } else { 'quiet' }
            $args = @(
                'build', $proj.Csproj,
                '--configuration', $proj.Config,
                "-p:GameFolder=$script:GameFolder",
                '-p:GenerateDocumentationFile=false',
                '-nowarn:CS1591',
                '--nologo',
                '-v', $verbosity
            ) + $extra

            Write-Host ("  [{0,-14}] dotnet build {1} -c {2}" -f $proj.Label, $proj.Csproj, $proj.Config) -ForegroundColor Cyan
            $output = & dotnet @args 2>&1
            $exit = $LASTEXITCODE
            if ($exit -eq 0) {
                $output | Where-Object { $_ -match 'Build succeeded' } | Select-Object -First 1 | ForEach-Object { Write-Host "                   $_" -ForegroundColor Green }
            } else {
                Write-Host "                   FAILED (exit $exit)" -ForegroundColor Red
                $output | Where-Object { $_ -match 'error |Build FAILED' } | Select-Object -First 8 | ForEach-Object { Write-Host "                   $_" -ForegroundColor Red }
                $allOk = $false
            }
        }
        return $allOk
    }
    finally { Pop-Location }
}

function Build-AllCrestRepos {
    [CmdletBinding()]
    param([switch]$Clean, [switch]$Loud)
    $results = [ordered]@{}
    foreach ($r in $script:CrestRepos) {
        Write-Host ""
        Write-Host "==== $($r.Name) ====" -ForegroundColor Cyan
        $ok = Build-CrestRepo -Name $r.Name -Clean:$Clean -Loud:$Loud
        $results[$r.Name] = $ok
    }
    Write-Host ""
    Write-Host "==== Build summary ====" -ForegroundColor Cyan
    $allOk = $true
    foreach ($k in $results.Keys) {
        $color = if ($results[$k]) { 'Green' } else { 'Red' }
        $status = if ($results[$k]) { 'OK'   } else { 'FAIL' }
        Write-Host ("  {0,-15} {1}" -f $k, $status) -ForegroundColor $color
        if (-not $results[$k]) { $allOk = $false }
    }
    return $allOk
}

function Test-CrestNamespaces {
    [CmdletBinding()]
    param()
    $clean = $true

    Write-Host "==> Cross-fork BUTR usings (target: 0 hits everywhere)" -ForegroundColor Cyan
    foreach ($r in $script:CrestRepos) {
        $paths = @()
        if (Test-Path "$($r.Path)\src")    { $paths += "$($r.Path)\src" }
        if (Test-Path "$($r.Path)\src-ui") { $paths += "$($r.Path)\src-ui" }
        $hits = Get-ChildItem -Recurse -File -Path $paths -Include *.cs -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -notlike '*\bin\*' -and $_.FullName -notlike '*\obj\*' } |
            ForEach-Object { Select-String -Path $_.FullName -Pattern 'using Bannerlord\.(Harmony|ButterLib|UIExtenderEx|MCM|MBOptionScreen)' -ErrorAction SilentlyContinue }
        $count = ($hits | Measure-Object).Count
        $color = if ($count -eq 0) { 'Green' } else { 'Red'; $clean = $false }
        Write-Host ("  {0,-15} {1}" -f $r.Name, $count) -ForegroundColor $color
        $hits | Select-Object -First 3 | ForEach-Object {
            Write-Host ("      {0}:{1}  {2}" -f ($_.Path | Split-Path -Leaf), $_.LineNumber, $_.Line.Trim())
        }
    }

    Write-Host ""
    Write-Host "==> Bare BUTR module-ID string literals (should resolve to 'CREST')" -ForegroundColor Cyan
    foreach ($r in $script:CrestRepos) {
        $paths = @()
        if (Test-Path "$($r.Path)\src")    { $paths += "$($r.Path)\src" }
        if (Test-Path "$($r.Path)\src-ui") { $paths += "$($r.Path)\src-ui" }
        $hits = Get-ChildItem -Recurse -File -Path $paths -Include *.cs -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -notlike '*\bin\*' -and $_.FullName -notlike '*\obj\*' } |
            ForEach-Object { Select-String -Path $_.FullName -Pattern '"Bannerlord\.(Harmony|ButterLib|UIExtenderEx|MCM|MBOptionScreen)"' -ErrorAction SilentlyContinue }
        $count = ($hits | Measure-Object).Count
        $color = if ($count -eq 0) { 'Green' } else { 'Red'; $clean = $false }
        Write-Host ("  {0,-15} {1}" -f $r.Name, $count) -ForegroundColor $color
        $hits | Select-Object -First 3 | ForEach-Object {
            Write-Host ("      {0}:{1}  {2}" -f ($_.Path | Split-Path -Leaf), $_.LineNumber, $_.Line.Trim())
        }
    }

    Write-Host ""
    Write-Host ("==> Audit result: " + $(if ($clean) {'CLEAN'} else {'HITS FOUND'})) -ForegroundColor $(if ($clean) {'Green'} else {'Red'})
    return $clean
}

function Commit-CrestRepo {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('Harmony','ButterLib','UIExtenderEx','MCM')]
        [string]$Name,
        [Parameter(Mandatory)] [string]$Message
    )
    $repo = Get-CrestRepo -Name $Name
    Push-Location $repo.Path
    try {
        $branch = (git rev-parse --abbrev-ref HEAD 2>$null).Trim()
        if ($branch -ne 'crest') {
            Write-Warning "$Name not on crest branch (currently '$branch'). Aborting commit."
            return $false
        }
        $dirty = git status --short
        if (-not $dirty) {
            Write-Host ("  {0}: nothing to commit (working tree clean)" -f $Name)
            return $true
        }
        git add -A
        git commit -m $Message
        if ($LASTEXITCODE -eq 0) {
            git log --oneline -1
            return $true
        }
        return $false
    }
    finally { Pop-Location }
}

function Get-CrestArtifacts {
    [CmdletBinding()]
    param()
    Write-Host "==> Built CREST artifacts (looking for shippable DLLs)" -ForegroundColor Cyan
    foreach ($r in $script:CrestRepos) {
        Write-Host ""
        Write-Host "  $($r.Name):" -ForegroundColor White
        $patterns = @('Crest.*.dll','CREST.*.dll','Bannerlord.ModuleLoader.CREST.dll')
        $dlls = @()
        foreach ($p in $patterns) {
            $found = Get-ChildItem -Recurse -File -Path $r.Path -Filter $p -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -notlike '*\obj\*' }
            $dlls += $found
        }
        $dlls = $dlls | Sort-Object FullName -Unique
        if (-not $dlls) {
            Write-Host ("    (no DLLs built - run Build-CrestRepo {0})" -f $r.Name) -ForegroundColor DarkGray
            continue
        }
        $repoPathPrefix = $r.Path + '\'
        foreach ($dll in $dlls) {
            $rel = $dll.FullName.Replace($repoPathPrefix, '').Replace('\', '/')
            $age = ((Get-Date) - $dll.LastWriteTime).TotalMinutes
            Write-Host ("    {0,8:N1}KB  {1,5:N0}m  {2}" -f ($dll.Length / 1KB), $age, $rel)
        }
    }
}

function Build-CrestBundle {
    <#
    .SYNOPSIS
    Assembles the unified CREST module folder ready to drop into Modules\.
    .DESCRIPTION
    Runs Build-AllCrestRepos, then gathers the right DLLs from each fork's
    bin folder into a staging tree shaped like Modules\CREST\bin\Win64_Shipping_Client\.
    Drops the master SubModule.xml at the staging root.
    .PARAMETER StagingDir
    Where to write the bundle. Default: C:\dev\bannerlord\crest\dist\CREST.
    .PARAMETER Version
    Version string to substitute into SubModule.xml. Default: 1.0.0.
    .PARAMETER SkipBuild
    Skip the Build-AllCrestRepos step (use when DLLs are already fresh).
    #>
    [CmdletBinding()]
    param(
        [string]$StagingDir = (Join-Path $script:CrestRoot 'crest\dist\CREST'),
        [string]$Version    = '1.0.0',
        [switch]$SkipBuild,
        [switch]$Clean
    )

    if (-not $SkipBuild) {
        Write-Host "==> Building all repos..." -ForegroundColor Cyan
        $built = Build-AllCrestRepos -Clean:$Clean
        if (-not $built) {
            Write-Error "Build failed; refusing to assemble bundle."
            return $false
        }
    } else {
        # Phase P.1 (H5): stale-binary detection. Compare newest source-file
        # mtime in each repo against the newest build-output mtime. If source
        # is newer, bundle would ship stale binaries -- warn loudly and refuse
        # to continue unless caller opts in via the env var.
        Write-Host "==> SkipBuild requested -- checking for stale binaries" -ForegroundColor Cyan
        $stale = @()
        $repoSourceDirs = @{
            'Harmony'      = "$script:CrestRoot\Bannerlord.Harmony\src"
            'ButterLib'    = "$script:CrestRoot\Bannerlord.ButterLib\src"
            'UIExtenderEx' = "$script:CrestRoot\Bannerlord.UIExtenderEx\src"
            'MCM'          = "$script:CrestRoot\Bannerlord.MBOptionScreen\src"
            'MCM-UI'       = "$script:CrestRoot\Bannerlord.MBOptionScreen\src-ui"
        }
        foreach ($repoName in $repoSourceDirs.Keys) {
            $srcDir = $repoSourceDirs[$repoName]
            if (-not (Test-Path $srcDir)) { continue }
            # Newest .cs (source) timestamp under src/
            $newestSrc = Get-ChildItem $srcDir -Recurse -File -Filter '*.cs' -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -notmatch '\\obj\\' } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 1
            # Newest DLL under any bin/Release*/ subtree
            $newestDll = Get-ChildItem $srcDir -Recurse -File -Filter '*.dll' -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -match '\\bin\\(Release|Stable_Release)' -and $_.FullName -notmatch '\\obj\\' } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 1
            if ($newestSrc -and $newestDll -and $newestSrc.LastWriteTime -gt $newestDll.LastWriteTime) {
                $stale += [pscustomobject]@{
                    Repo = $repoName
                    SourceFile = $newestSrc.FullName.Substring($srcDir.Length).TrimStart('\')
                    SourceTs = $newestSrc.LastWriteTime
                    DllTs = $newestDll.LastWriteTime
                }
            }
        }
        if ($stale.Count -gt 0) {
            Write-Host ("    STALE: {0} repo(s) have source newer than build output:" -f $stale.Count) -ForegroundColor Yellow
            foreach ($s in $stale) {
                Write-Host ("      [{0}] {1}  (src {2} > dll {3})" -f $s.Repo, $s.SourceFile, $s.SourceTs.ToString('HH:mm:ss'), $s.DllTs.ToString('HH:mm:ss')) -ForegroundColor Yellow
            }
            if ($env:CREST_BUNDLE_ALLOW_STALE -eq '1') {
                Write-Host "    CREST_BUNDLE_ALLOW_STALE=1 set -- continuing despite stale binaries" -ForegroundColor Yellow
            } else {
                Write-Error "Refusing to bundle stale binaries. Either drop -SkipBuild, rebuild manually, or set CREST_BUNDLE_ALLOW_STALE=1 to override."
                return $false
            }
        } else {
            Write-Host "    OK: build outputs are up-to-date with source" -ForegroundColor Green
        }
    }

    if (Test-Path $StagingDir) {
        Write-Host "==> Wiping previous staging at $StagingDir" -ForegroundColor DarkGray
        Remove-Item -Recurse -Force $StagingDir
    }

    $binDir = Join-Path $StagingDir 'bin\Win64_Shipping_Client'
    New-Item -ItemType Directory -Path $binDir -Force | Out-Null
    Write-Host ("==> Staging at {0}" -f $StagingDir) -ForegroundColor Cyan

    # Allowlist: only DLLs matching these prefixes get copied.
    # Anything else (e.g. stale Bannerlord.Harmony.dll from a pre-rename build) is filtered out.
    # Note: `Bannerlord.ModuleLoader.CREST.dll` is intentionally NOT allow-listed - we bypass
    # the BUTR loader stub by pointing SubModule.xml directly at CREST.v1.4.1.dll. Verified
    # via static reference scan that no other bundled DLL references it.
    # `BetterExceptionWindow` and `DotNetZip` are bundled from the user's existing BEW install.
    # `Microsoft.Extensions.*`, `Serilog.*`, `BUTR.CrashReport.*` etc. are third-party deps
    # copied from upstream ButterLib's install (handled in Layer 5b, not by this filter).
    $allowed = '^(Crest\.|CREST\.|0Harmony|Mono\.Cecil|MonoMod\.|Newtonsoft\.Json|System\.|Microsoft\.|Serilog\.|BUTR\.CrashReport|BetterExceptionWindow|DotNetZip|cimgui|glfw3).*\.dll$'

    # Layer 1: Harmony's net472 output (Crest.Harmony.dll plus 0Harmony, Mono.Cecil.*, MonoMod.*)
    # Phase P audit: missing critical layers used to emit Write-Warning + continue, which
    # silently shipped incomplete bundles. Now hard-error so a missing build folder fails
    # the bundle outright instead of producing a broken zip.
    $harmonyOut = "$script:CrestRoot\Bannerlord.Harmony\src\Crest.Harmony\bin\Release\net472"
    if (-not (Test-Path $harmonyOut)) {
        Write-Error "Harmony net472 build folder not found: $harmonyOut"
        return $false
    }
    $harmonyDlls = Get-ChildItem $harmonyOut -Filter '*.dll' | Where-Object { $_.Name -match $allowed }
    $harmonyDlls | Copy-Item -Destination $binDir -Force
    Write-Host ("    [Harmony]      copied {0} DLLs (filtered)" -f ($harmonyDlls | Measure-Object).Count)

    # Phase P.1 (M4): surface DLLs that the allowlist filtered out, so new
    # transitive dependencies become visible rather than silently dropped.
    # Some DLLs are filtered intentionally (build artifacts that don't ship);
    # this list is informational so an audit can confirm the allowlist still
    # matches reality after a NuGet upgrade or a new ButterLib subsystem.
    $skippedDlls = Get-ChildItem $harmonyOut -Filter '*.dll' | Where-Object { $_.Name -notmatch $allowed }
    if ($skippedDlls.Count -gt 0) {
        Write-Host ("    [Harmony]      allowlist filtered out {0} DLL(s):" -f $skippedDlls.Count) -ForegroundColor DarkGray
        foreach ($d in $skippedDlls) { Write-Host ("                     - " + $d.Name) -ForegroundColor DarkGray }
        Write-Host ("                   Review: if any of these are runtime dependencies, add their prefix to the allowlist regex above.") -ForegroundColor DarkGray
    }

    # Layer 2: ButterLib net472 output (main + Implementation)
    $blMainOut = "$script:CrestRoot\Bannerlord.ButterLib\src\Crest.ButterLib\bin\Release\net472"
    if (-not (Test-Path $blMainOut)) {
        Write-Error "ButterLib net472 build folder not found: $blMainOut"
        return $false
    }
    Get-ChildItem $blMainOut -Filter 'Crest.ButterLib*.dll' | Copy-Item -Destination $binDir -Force
    Get-ChildItem $blMainOut -Filter 'Newtonsoft.Json.dll' -ErrorAction SilentlyContinue | Copy-Item -Destination $binDir -Force

    $blImplOut = "$script:CrestRoot\Bannerlord.ButterLib\src\Crest.ButterLib.Implementation\bin\Stable_Release\net472"
    if (-not (Test-Path $blImplOut)) {
        Write-Error "ButterLib Implementation build folder not found: $blImplOut"
        return $false
    }
    Get-ChildItem $blImplOut -Filter 'Crest.ButterLib.Implementation*.dll' | Copy-Item -Destination $binDir -Force
    Write-Host "    [ButterLib]    copied main + Implementation"

    # Layer 3: UIExtenderEx (netstandard2.0 only)
    $uixOut = "$script:CrestRoot\Bannerlord.UIExtenderEx\src\Crest.UIExtenderEx\bin\Release\netstandard2.0"
    if (-not (Test-Path $uixOut)) {
        Write-Error "UIExtenderEx build folder not found: $uixOut"
        return $false
    }
    Get-ChildItem $uixOut -Filter 'Crest.UIExtenderEx.dll' | Copy-Item -Destination $binDir -Force
    Write-Host "    [UIExtenderEx] copied"

    # Layer 4: MCM main
    $mcmOut = "$script:CrestRoot\Bannerlord.MBOptionScreen\src\Crest.MCM\bin\Release\netstandard2.0"
    if (-not (Test-Path $mcmOut)) {
        Write-Error "MCM main build folder not found: $mcmOut"
        return $false
    }
    Get-ChildItem $mcmOut -Filter 'Crest.MCM.dll' | Copy-Item -Destination $binDir -Force

    # Layer 5: MCM.UI (loader + versioned code DLL + adapter + any other deps)
    $mcmUiOut = "$script:CrestRoot\Bannerlord.MBOptionScreen\src-ui\Crest.MCM.UI\bin\Stable_Release\netstandard2.0"
    if (-not (Test-Path $mcmUiOut)) {
        Write-Error "MCM.UI build folder not found: $mcmUiOut"
        return $false
    }
    # Apply allowlist; also skip Crest.MCM.dll (already copied from canonical Layer 4 source)
    # and Crest.UIExtenderEx/Crest.ButterLib (canonical sources used).
    $skip = @('Crest.MCM.dll', 'Crest.UIExtenderEx.dll', 'Crest.ButterLib.dll', 'Crest.ButterLib.Implementation.dll')
    $mcmUiDlls = Get-ChildItem $mcmUiOut -Filter '*.dll' |
        Where-Object { $_.Name -match $allowed -and $_.Name -notin $skip }
    $mcmUiDlls | Copy-Item -Destination $binDir -Force
    Write-Host ("    [MCM]          copied {0} DLLs (loader + UI + adapter)" -f ($mcmUiDlls | Measure-Object).Count)

    # Layer 5b: Third-party dependencies, sourced from our vendored copy.
    # crest\vendor\Win64_Shipping_Client\ holds every DLL ButterLib + ButterLib.Implementation
    # + the BUTR.CrashReport stack require at runtime that doesn't come from our forks'
    # own build outputs. We vendor instead of pulling from upstream BUTR install or NuGet
    # cache so the bundle is self-contained on any dev machine and doesn't depend on the
    # user keeping the upstream BUTR mods on disk.
    $vendorBin = "$script:CrestRoot\crest\vendor\Win64_Shipping_Client"
    if (Test-Path $vendorBin) {
        $vendorDlls = Get-ChildItem $vendorBin -Filter '*.dll' -ErrorAction SilentlyContinue
        # Skip names that our build outputs (Layers 1-5) already produced - we don't
        # want to overwrite a freshly-built fork DLL with a stale vendored copy.
        $skip = @(
            'Crest.Harmony.dll','Crest.ButterLib.dll','Crest.ButterLib.Implementation.dll',
            'Crest.UIExtenderEx.dll','Crest.MCM.dll','Crest.MCM.UI.Adapter.MCMv5.dll',
            'CREST.v1.4.1.dll'
        )
        $copied = 0
        foreach ($f in $vendorDlls) {
            if ($skip -contains $f.Name) { continue }
            # Don't overwrite an already-staged DLL produced by our forks
            $dest = Join-Path $binDir $f.Name
            if (Test-Path $dest) { continue }
            Copy-Item $f.FullName -Destination $binDir -Force
            $copied++
        }
        Write-Host "    [Vendor]       copied $copied DLLs from crest\vendor\"
    } else {
        Write-Warning "Vendor folder not found at $vendorBin; bundle will be incomplete. Run phaseb8-01-vendor-deps.ps1 to populate it."
    }

    # Layer 5c: Phase H compatibility shims. Tiny TypeForwardedTo-only DLLs that
    # let mods compiled against upstream BUTR (Bannerlord.X.dll, MCMv5.dll)
    # resolve their type references to our Crest.X.dll. Generated by
    # crest\shims\generate-shims.ps1 (Cecil-based, no C# compile).
    $shimRoot = "$script:CrestRoot\crest\shims"
    $shimDlls = @(
        @{ Path="$shimRoot\Bannerlord.Harmony.Shim\Bannerlord.Harmony.dll";       Name='Bannerlord.Harmony.dll' },
        @{ Path="$shimRoot\Bannerlord.ButterLib.Shim\Bannerlord.ButterLib.dll";   Name='Bannerlord.ButterLib.dll' },
        @{ Path="$shimRoot\Bannerlord.UIExtenderEx.Shim\Bannerlord.UIExtenderEx.dll"; Name='Bannerlord.UIExtenderEx.dll' },
        @{ Path="$shimRoot\MCMv5.Shim\MCMv5.dll";                                  Name='MCMv5.dll' }
    )
    # Phase P audit: shims are not optional — SubModule.xml lists them as <Assembly>
    # entries that get preloaded, and consumer mods' MCMv5 / Bannerlord.Harmony /
    # ButterLib / UIExtenderEx references can't resolve without them. Hard-error
    # on any missing shim instead of warning + shipping a broken bundle.
    $shimCount = 0
    foreach ($shim in $shimDlls) {
        if (-not (Test-Path $shim.Path)) {
            Write-Error ("Shim missing: $($shim.Name) at $($shim.Path). Run crest\shims\generate-shims.ps1 first.")
            return $false
        }
        Copy-Item $shim.Path -Destination $binDir -Force
        $shimCount++
    }
    Write-Host ("    [Shims]        copied $shimCount of $($shimDlls.Count) compatibility shim DLLs")

    # Layer 6: BetterExceptionWindow (bundled from user's existing install).
    # We don't fork/build BEW; we redistribute its compiled DLLs and assets so
    # BEW's crash-reporter functionality is available inside CREST without
    # needing the legacy Bannerlord.Harmony module enabled.
    $bewSrc = "$script:GameFolder\Modules\BetterExceptionWindow"
    if (Test-Path $bewSrc) {
        $bewBin = Join-Path $bewSrc 'bin\Win64_Shipping_Client'
        if (Test-Path $bewBin) {
            # DLLs (filtered by allowlist; .pdb/.xml/test stubs skipped)
            $bewDllNames = @('BetterExceptionWindow.dll','BetterExceptionWindowConfigUI.dll','DotNetZip.dll')
            foreach ($name in $bewDllNames) {
                $src = Join-Path $bewBin $name
                if (Test-Path $src) { Copy-Item $src -Destination $binDir -Force }
            }
            Write-Host "    [BEW]          copied DLLs"
        }
        # Assets at the module root (errorui.htm, config.json, solutions.json) and ModuleData\
        foreach ($asset in 'errorui.htm','config.json','solutions.json') {
            $src = Join-Path $bewSrc $asset
            if (Test-Path $src) { Copy-Item $src -Destination $StagingDir -Force }
        }
        $bewModData = Join-Path $bewSrc 'ModuleData'
        if (Test-Path $bewModData) {
            $destModData = Join-Path $StagingDir 'ModuleData'
            New-Item -ItemType Directory -Path $destModData -Force | Out-Null
            Copy-Item -Recurse -Path (Join-Path $bewModData '*') -Destination $destModData -Force
            Write-Host "    [BEW]          copied assets and ModuleData"
        }
    } else {
        Write-Warning "BetterExceptionWindow folder not found at $bewSrc; CREST will ship without crash-reporter."
    }

    # Master SubModule.xml: substitute $version$ token
    $tmpl = Get-Content "$script:CrestRoot\crest\Modules\CREST\SubModule.xml.template" -Raw
    $tmpl = $tmpl -replace '\$version\$', $Version
    Set-Content -Path (Join-Path $StagingDir 'SubModule.xml') -Value $tmpl -Encoding UTF8

    # Phase P.1 (M6): verify <Assembly> entries in SubModule.xml cover every
    # third-party DLL we just staged. The template's <Assembly value="..."/>
    # entries are static; if a new ButterLib subsystem ships a new
    # Microsoft.Extensions.Foo.dll, we'd quietly stage it without preloading
    # it, and consumer mods would get FileNotFoundException at runtime.
    # This check surfaces the gap so the dev knows to update the template.
    # Bundle-managed (Crest.*, CREST.*) and game-pre-loaded DLLs (Mono.Cecil,
    # MonoMod) don't need to be listed.
    $stagedDlls = Get-ChildItem $binDir -File -Filter '*.dll' -ErrorAction SilentlyContinue
    $expectedThirdParty = $stagedDlls | Where-Object {
        $_.Name -notmatch '^(Crest\.|CREST\.|Bannerlord\.|0Harmony|Mono\.Cecil|MonoMod\.|MCMv5\.dll)' -and
        $_.Name -notmatch '\.pdb$'
    }
    $tmplListed = [regex]::Matches($tmpl, '<Assembly\s+value\s*=\s*"([^"]+)"') | ForEach-Object { $_.Groups[1].Value }
    $missingFromTmpl = @()
    foreach ($d in $expectedThirdParty) {
        if ($tmplListed -notcontains $d.Name) { $missingFromTmpl += $d.Name }
    }
    if ($missingFromTmpl.Count -gt 0) {
        Write-Host ("    [Template]     {0} third-party DLL(s) staged but not <Assembly>-listed in SubModule.xml.template:" -f $missingFromTmpl.Count) -ForegroundColor Yellow
        foreach ($n in $missingFromTmpl) { Write-Host ("                     - " + $n) -ForegroundColor Yellow }
        Write-Host ("                   Add corresponding <Assembly value=`"...`" /> entries to crest\Modules\CREST\SubModule.xml.template (under the relevant <SubModule>'s <Assemblies>) so consumer mods can resolve these at load time.") -ForegroundColor Yellow
    }

    # Unblock-CrestInstall.ps1: ships at the module root so end users who
    # download CREST as a zip can run it once after extract to strip
    # Mark-of-the-Web from every CREST + BLSE binary. Without this step,
    # the .NET CLR refuses to load the assemblies and the mod silently
    # fails to start.
    $unblockScript = "$script:CrestRoot\crest\Modules\CREST\Unblock-CrestInstall.ps1"
    if (Test-Path $unblockScript) {
        Copy-Item $unblockScript -Destination $StagingDir -Force
    }

    # Summary
    Write-Host ""
    Write-Host "==> Bundle ready at $StagingDir" -ForegroundColor Green
    Write-Host "    SubModule.xml: $(Get-Item (Join-Path $StagingDir 'SubModule.xml') | Select-Object -ExpandProperty Length) bytes"
    Write-Host "    bin\Win64_Shipping_Client contents:"
    Get-ChildItem $binDir | Sort-Object Name | ForEach-Object {
        Write-Host ("        {0,9:N1}KB  {1}" -f ($_.Length/1KB), $_.Name)
    }

    return $true
}

function New-CrestZip {
    <#
    .SYNOPSIS
    Zips a built CREST staging folder into a distributable archive.
    .PARAMETER StagingDir
    The folder produced by Build-CrestBundle. Default matches its default.
    .PARAMETER Version
    Used in the archive filename. Default: 1.0.0.
    .PARAMETER OutDir
    Where to drop the zip. Default: C:\dev\bannerlord\crest\dist.
    #>
    [CmdletBinding()]
    param(
        [string]$StagingDir = 'C:\dev\bannerlord\crest\dist\CREST',
        [string]$Version    = '1.0.0',
        [string]$OutDir     = 'C:\dev\bannerlord\crest\dist'
    )
    if (-not (Test-Path $StagingDir)) {
        Write-Error "Staging dir not found: $StagingDir. Run Build-CrestBundle first."
        return $null
    }
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
    $zipPath = Join-Path $OutDir ("CREST-v{0}.zip" -f $Version)
    if (Test-Path $zipPath) { Remove-Item -Force $zipPath }

    # Z.8: use BCL ZipFile.CreateFromDirectory instead of Compress-Archive.
    # Compress-Archive leaves zips with no End-Of-Central-Directory when the
    # parent process is interrupted mid-write. The BCL API is atomic on
    # Dispose() -- a killed run produces no file rather than a corrupt one.
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
    [System.IO.Compression.ZipFile]::CreateFromDirectory(
        $StagingDir, $zipPath,
        [System.IO.Compression.CompressionLevel]::Optimal,
        $true   # includeBaseDirectory = true -- archive top-level is CREST\, matches old behavior
    )

    # Z.8: post-write integrity check. Truncated zips throw here.
    $reader = $null
    try {
        $reader = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
        $entryCount = $reader.Entries.Count
    } catch {
        if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
        throw "POST-WRITE INTEGRITY CHECK FAILED for ${zipPath}: $($_.Exception.Message)"
    } finally {
        if ($reader) { $reader.Dispose() }
    }

    $zipInfo = Get-Item $zipPath
    Write-Host ("==> Wrote {0} ({1:N1} KB, {2} entries, integrity PASS)" -f $zipPath, ($zipInfo.Length/1KB), $entryCount) -ForegroundColor Green
    return $zipPath
}

function Deploy-CrestToBannerlord {
    <#
    .SYNOPSIS
    Copies a built CREST bundle into Modules\CREST\ inside the Bannerlord install.
    .DESCRIPTION
    Wipes the existing Modules\CREST\ and replaces it with the contents of the
    staging folder. Use right before launching the game for smoke testing.
    .PARAMETER StagingDir
    Source folder to deploy from.
    .PARAMETER ModulesDir
    Bannerlord Modules folder. Defaults based on the GameFolder constant.
    #>
    [CmdletBinding()]
    param(
        [string]$StagingDir = 'C:\dev\bannerlord\crest\dist\CREST',
        [string]$ModulesDir = (Join-Path $script:GameFolder 'Modules')
    )
    if (-not (Test-Path $StagingDir)) {
        Write-Error "Staging dir not found: $StagingDir. Run Build-CrestBundle first."
        return $false
    }
    $target = Join-Path $ModulesDir 'CREST'
    if (Test-Path $target) {
        Write-Host "==> Wiping existing $target" -ForegroundColor DarkGray
        Remove-Item -Recurse -Force $target
    }
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    Copy-Item -Recurse -Path (Join-Path $StagingDir '*') -Destination $target -Force
    $count = (Get-ChildItem -Recurse -File $target | Measure-Object).Count
    Write-Host ("==> Deployed $count files to $target") -ForegroundColor Green
    return $true
}

function Build-CrestBlse {
    <#
    .SYNOPSIS
    Builds the upstream Bannerlord.BLSE solution and stages its launcher binaries.
    .DESCRIPTION
    BLSE is treated as an upstream dependency we redistribute (Phase E decision):
    we don't fork the namespace, we just `dotnet build` the four loader projects
    and copy their outputs into a flat `bin\Win64_Shipping_Client\` shaped staging
    folder so the same files can drop into the user's game install.
    Outputs go to $StagingBlseBin.
    .PARAMETER StagingBlseBin
    Where to write the staged BLSE files. Default: dist\full\bin\Win64_Shipping_Client.
    .PARAMETER SkipBuild
    Skip the dotnet build step (use when you know binaries are fresh).
    #>
    [CmdletBinding()]
    param(
        [string]$StagingBlseBin = 'C:\dev\bannerlord\crest\dist\full\bin\Win64_Shipping_Client',
        [switch]$SkipBuild
    )

    $blseRoot = "$script:CrestRoot\Bannerlord.BLSE"
    if (-not (Test-Path $blseRoot)) {
        Write-Error "BLSE source not found at $blseRoot"
        return $false
    }

    if (-not $SkipBuild) {
        # Pass GameFolder via env var to avoid PS5 native-arg-quoting issues
        # with spaces and ampersand in the path.
        $env:GameFolder = $script:GameFolder

        $projects = @(
            'src\Bannerlord.BLSE.Shared\Bannerlord.BLSE.Shared.csproj',
            'src\Bannerlord.BLSE\Bannerlord.BLSE.csproj',
            'src\Bannerlord.LauncherEx\Bannerlord.LauncherEx.csproj',
            'src\Bannerlord.BLSE.Loaders.Launcher\Bannerlord.BLSE.Loaders.Launcher.csproj',
            'src\Bannerlord.BLSE.Loaders.LauncherEx\Bannerlord.BLSE.Loaders.LauncherEx.csproj',
            'src\Bannerlord.BLSE.Loaders.Standalone\Bannerlord.BLSE.Loaders.Standalone.csproj',
            'src\Bannerlord.BLSE.Loaders.AppDomainManager\Bannerlord.BLSE.Loaders.AppDomainManager.csproj'
        )
        Push-Location $blseRoot
        try {
            foreach ($p in $projects) {
                $name = (Split-Path $p -Leaf) -replace '\.csproj$', ''
                Write-Host ('  building BLSE: ' + $name) -ForegroundColor Cyan
                $output = & dotnet build $p --configuration Release '-p:GenerateDocumentationFile=false' '-nowarn:CS1591' --nologo -v quiet 2>&1
                if ($LASTEXITCODE -ne 0) {
                    Write-Host ('    FAIL ' + $name) -ForegroundColor Red
                    $output | Where-Object { $_ -match '(error |Build FAILED)' } | Select-Object -First 5 | ForEach-Object { Write-Host ('      ' + $_) -ForegroundColor Red }
                    return $false
                }
            }
        } finally { Pop-Location }
    }

    # Stage outputs. We pull from each project's bin\Release\netNNN\publish\ where
    # available (post-build target) so we get the runtime-needed files together.
    if (-not (Test-Path $StagingBlseBin)) {
        New-Item -ItemType Directory -Path $StagingBlseBin -Force | Out-Null
    }

    # Files that go into game's bin\Win64_Shipping_Client\.
    # The exes are tiny launcher shims that load the .Shared.dll alongside.
    $files = @(
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Loaders.Launcher\bin\Release\net472\Bannerlord.BLSE.Launcher.exe";       Required=$true },
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Loaders.LauncherEx\bin\Release\net472\Bannerlord.BLSE.LauncherEx.exe";   Required=$true },
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Loaders.Standalone\bin\Release\net472\Bannerlord.BLSE.Standalone.exe";   Required=$true },
        @{ Src="$blseRoot\src\Bannerlord.BLSE\bin\Release\netstandard2.0\Bannerlord.BLSE.dll";                          Required=$true },
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Shared\bin\Release\netstandard2.0\Bannerlord.BLSE.Shared.dll";            Required=$true },
        @{ Src="$blseRoot\src\Bannerlord.LauncherEx\bin\Release\netstandard2.0\Bannerlord.LauncherEx.dll";              Required=$true },
        @{ Src="$blseRoot\src\Bannerlord.LauncherEx\bin\Release\netstandard2.0\System.Drawing.Common.dll";              Required=$false },
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Loaders.AppDomainManager\bin\Release\net472\Bannerlord.BLSE.AppDomainManager.dll"; Required=$true },
        # AppDomainManager support DLLs (System.* deps used by .NET Framework launchers)
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Loaders.Launcher\bin\Release\net472\System.Buffers.dll";                   Required=$false },
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Loaders.Launcher\bin\Release\net472\System.Memory.dll";                    Required=$false },
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Loaders.Launcher\bin\Release\net472\System.Numerics.Vectors.dll";          Required=$false },
        @{ Src="$blseRoot\src\Bannerlord.BLSE.Loaders.Launcher\bin\Release\net472\System.Runtime.CompilerServices.Unsafe.dll"; Required=$false }
    )

    $copied = 0
    foreach ($f in $files) {
        if (-not (Test-Path $f.Src)) {
            if ($f.Required) {
                Write-Error ("BLSE: required file missing: " + $f.Src)
                return $false
            } else {
                continue
            }
        }
        Copy-Item -Path $f.Src -Destination $StagingBlseBin -Force
        $copied++
    }

    # Also copy the four .exe.config files from each loader project's _Root
    # tree. These are required for the launcher exes to enable
    # legacyCorruptedStateExceptionsPolicy, plus the AppDomainManager-redirect
    # config that injects BLSE into the vanilla TaleWorlds launcher path.
    $rootCfgs = @(
        "$blseRoot\src\Bannerlord.BLSE.Loaders.AppDomainManager\_Root\bin\Win64_Shipping_Client\TaleWorlds.MountAndBlade.Launcher.exe.config",
        "$blseRoot\src\Bannerlord.BLSE.Loaders.Launcher\_Root\bin\Win64_Shipping_Client\Bannerlord.BLSE.Launcher.exe.config",
        "$blseRoot\src\Bannerlord.BLSE.Loaders.LauncherEx\_Root\bin\Win64_Shipping_Client\Bannerlord.BLSE.LauncherEx.exe.config",
        "$blseRoot\src\Bannerlord.BLSE.Loaders.Standalone\_Root\bin\Win64_Shipping_Client\Bannerlord.BLSE.Standalone.exe.config"
    )
    foreach ($cfg in $rootCfgs) {
        if (Test-Path $cfg) {
            Copy-Item -Path $cfg -Destination $StagingBlseBin -Force
            $copied++
        }
    }

    # Phase E follow-up: emit a Bannerlord.exe.config alongside Bannerlord.exe
    # so BLSE injects regardless of how the game is launched (Steam-direct,
    # explorer double-click, etc.). Same AppDomainManager redirect as
    # TaleWorlds.MountAndBlade.Launcher.exe.config. Without this, launching
    # the game without going through a BLSE-aware launcher leaves BLSE
    # uninjected and dev console commands like blse.version are unavailable.
    $bannerlordCfgPath = Join-Path $StagingBlseBin 'Bannerlord.exe.config'
    $bannerlordCfgContent = @"
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <runtime>
    <appDomainManagerAssembly value="Bannerlord.BLSE.AppDomainManager, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null" />
    <appDomainManagerType value="Bannerlord.BLSE.Loaders.AppDomainManager.BLSEAppDomainManager" />
  </runtime>
</configuration>
"@
    Set-Content -Path $bannerlordCfgPath -Value $bannerlordCfgContent -Encoding UTF8 -NoNewline
    $copied++

    Write-Host ("    [BLSE]         copied $copied files into $StagingBlseBin (incl .exe.config files)")
    return $true
}

function Build-CrestFullBundle {
    <#
    .SYNOPSIS
    Builds + stages a CREST distribution that drops both the Modules\CREST\ tree
    and BLSE's bin\Win64_Shipping_Client\ files in one zip.
    .DESCRIPTION
    Layered on top of Build-CrestBundle (which produces the modules portion at
    dist\CREST\). This wrapper:
      1. Calls Build-CrestBundle (or skips if fresh).
      2. Calls Build-CrestBlse to produce BLSE binaries.
      3. Combines both into dist\full\ with the layout
            dist\full\Modules\CREST\
            dist\full\bin\Win64_Shipping_Client\
         so the resulting zip extracts cleanly to the game folder root.
    .PARAMETER Version
    Version string for the SubModule.xml + zip filename.
    .PARAMETER SkipBuild
    Skip both the CREST forks build and the BLSE build.
    .PARAMETER Clean
    Pass -Clean through to Build-AllCrestRepos.
    #>
    [CmdletBinding()]
    param(
        [string]$Version = '1.3.0',
        [switch]$SkipBuild,
        [switch]$Clean
    )

    $fullDir   = 'C:\dev\bannerlord\crest\dist\full'
    $modulesIn = 'C:\dev\bannerlord\crest\dist\CREST'
    $blseBin   = Join-Path $fullDir 'bin\Win64_Shipping_Client'
    $modOut    = Join-Path $fullDir 'Modules\CREST'

    Write-Host '==> Stage 1: build + stage CREST modules portion' -ForegroundColor Cyan
    $ok = Build-CrestBundle -Version $Version -SkipBuild:$SkipBuild -Clean:$Clean
    if (-not $ok) { return $false }

    Write-Host ''
    Write-Host '==> Stage 2: build + stage BLSE launcher binaries' -ForegroundColor Cyan
    $ok = Build-CrestBlse -StagingBlseBin $blseBin -SkipBuild:$SkipBuild
    if (-not $ok) { return $false }

    Write-Host ''
    Write-Host '==> Stage 3: combine into dist\full\ with Modules\+bin\ layout' -ForegroundColor Cyan
    if (Test-Path $modOut) { Remove-Item -Recurse -Force $modOut }
    New-Item -ItemType Directory -Path $modOut -Force | Out-Null
    Copy-Item -Recurse -Path (Join-Path $modulesIn '*') -Destination $modOut -Force

    Write-Host ''
    Write-Host '==> Stage 4: stage Bannerlord.X stub modules into dist\full\Modules\' -ForegroundColor Cyan
    # Each stub is now SubModule.xml only — no bin folder, no DLL duplication.
    # The Harmony stub used to ship a bin\ tree because BLSE's HarmonyFinder
    # hardcoded the Modules\Bannerlord.Harmony\bin\Win64_Shipping_Client\ path.
    # The CREST patch to HarmonyFinder.cs adds a fallback probe of
    # Modules\CREST\bin\Win64_Shipping_Client\, so the stub no longer needs
    # its own copy of 0Harmony / Mono.Cecil / MonoMod / etc.
    # The four 1 KB SubModule.xml files exist solely to satisfy the engine's
    # <DependedModule Id="Bannerlord.X" /> validator for community mods.
    # See Phase N for the path to eliminate them entirely.
    $stubsRoot = "$script:CrestRoot\crest\stubs"
    $modulesFullRoot = Join-Path $fullDir 'Modules'
    foreach ($stubName in @('Bannerlord.Harmony','Bannerlord.ButterLib','Bannerlord.UIExtenderEx','Bannerlord.MBOptionScreen')) {
        $src = Join-Path $stubsRoot $stubName
        if (-not (Test-Path $src)) { continue }
        $dst = Join-Path $modulesFullRoot $stubName
        if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
        New-Item -ItemType Directory -Path $dst -Force | Out-Null
        # Copy ONLY SubModule.xml. We deliberately do not include any bin\ tree.
        Copy-Item -Path (Join-Path $src 'SubModule.xml') -Destination $dst -Force
        $size = (Get-Item (Join-Path $dst 'SubModule.xml')).Length
        Write-Host ("    [stub] $stubName : SubModule.xml only ($size bytes)")
    }

    $modCount  = (Get-ChildItem -Recurse -File $modOut  | Measure-Object).Count
    $blseCount = (Get-ChildItem -Recurse -File $blseBin | Measure-Object).Count
    $stubCount = (Get-ChildItem -Recurse -File $modulesFullRoot -Exclude 'CREST' | Measure-Object).Count
    Write-Host ''
    Write-Host ("    Modules\CREST                : $modCount files")
    Write-Host ("    Modules\Bannerlord.X (stubs) : $stubCount files")
    Write-Host ("    bin\Win64_Shipping_Client    : $blseCount files")
    Write-Host ("==> Full bundle ready at $fullDir") -ForegroundColor Green
    return $true
}

function Deploy-CrestFullToBannerlord {
    <#
    .SYNOPSIS
    Copies the full bundle (Modules\CREST + bin\Win64_Shipping_Client) into the
    Bannerlord game folder.
    .DESCRIPTION
    Modules\CREST\ is wipe-and-replace (so removed files go away). Game's
    bin\Win64_Shipping_Client\ is overlay (we never wipe game-shipped files).
    Pre-existing BLSE files at the same name get replaced.
    #>
    [CmdletBinding()]
    param(
        [string]$FullDir   = 'C:\dev\bannerlord\crest\dist\full',
        [string]$GameRoot  = $script:GameFolder
    )
    if (-not (Test-Path $FullDir)) {
        Write-Error "Full bundle not found at $FullDir. Run Build-CrestFullBundle first."
        return $false
    }

    $modulesSrc = Join-Path $FullDir 'Modules'
    $modulesDst = Join-Path $GameRoot 'Modules'
    $blseSrc    = Join-Path $FullDir 'bin\Win64_Shipping_Client'
    $blseDst    = Join-Path $GameRoot 'bin\Win64_Shipping_Client'

    # Wipe-and-replace each Modules\X that we ship (CREST + the four stubs).
    foreach ($modName in @('CREST','Bannerlord.Harmony','Bannerlord.ButterLib','Bannerlord.UIExtenderEx','Bannerlord.MBOptionScreen')) {
        $src = Join-Path $modulesSrc $modName
        if (-not (Test-Path $src)) { continue }
        $dst = Join-Path $modulesDst $modName
        if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
        New-Item -ItemType Directory -Path $dst -Force | Out-Null
        Copy-Item -Recurse -Path (Join-Path $src '*') -Destination $dst -Force
        $n = (Get-ChildItem -Recurse -File $dst | Measure-Object).Count
        Write-Host ("==> Deployed $n files to Modules\$modName") -ForegroundColor Green
    }

    Write-Host '==> Overlaying BLSE binaries onto bin\Win64_Shipping_Client (existing game files untouched)' -ForegroundColor DarkGray
    Get-ChildItem $blseSrc -File | ForEach-Object {
        Copy-Item -Path $_.FullName -Destination $blseDst -Force
    }
    Write-Host '==> BLSE files overlaid' -ForegroundColor Green
    return $true
}

function New-CrestFullZip {
    <#
    .SYNOPSIS
    Zips dist\full\ so the archive contains top-level Modules\ and bin\ folders,
    intended to be extracted to the Bannerlord game root in one shot.
    #>
    [CmdletBinding()]
    param(
        [string]$FullDir = 'C:\dev\bannerlord\crest\dist\full',
        [string]$Version = '1.3.0',
        [string]$OutDir  = 'C:\dev\bannerlord\crest\dist'
    )
    if (-not (Test-Path $FullDir)) {
        Write-Error "Full bundle not found at $FullDir"
        return $null
    }
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
    $zipPath = Join-Path $OutDir ("CREST-v{0}.zip" -f $Version)
    if (Test-Path $zipPath) { Remove-Item -Force $zipPath }

    # Z.8: use BCL ZipFile.CreateFromDirectory instead of Compress-Archive.
    # Zip the *contents* of dist\full\ (includeBaseDirectory=$false) so the
    # archive's top level is Mod