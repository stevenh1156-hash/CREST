# Crest-GUI.ps1 -- Phase S
#
# Single-window WinForms wrapper for the three CREST modder-facing tools so
# users (especially mod authors who don't live in PowerShell) can run them
# with a click instead of typing -ExecutionPolicy Bypass -File ... incantations.
#
# Wraps:
#   * Crest-Doctor.ps1                        (tools/doctor/)
#   * Crest-Compat.ps1                        (tools/compat/)
#   * Migrate-ModToCrest.ps1       (DLL)      (tools/migrate/)
#   * Migrate-ModSourceToCrest.ps1 (source)   (tools/migrate/)
#
# Architecture:
#   - WinForms TopLevel form, four tabs (Doctor | Compat | Migrate DLLs | Migrate Source).
#   - Each tab posts its inputs to the underlying .ps1 via Start-Process powershell -File.
#   - Stdout/stderr stream into a shared multi-line textbox at the bottom.
#   - A Cancel button kills the running child if the user wants to bail.
#
# No external dependencies; ships in tools/ alongside the underlying scripts.
# Launch via tools\Crest-GUI.bat (double-clickable) or:
#   powershell -ExecutionPolicy Bypass -File tools\Crest-GUI.ps1

[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

# Top-level error handler. The .bat launches us with -WindowStyle Hidden so
# any uncaught script error otherwise produces zero feedback (process flashes
# and exits). Wrap the entire body so failures end with a visible MessageBox
# AND a log file at %TEMP%\crest-gui-error.log that the user can paste back
# to us. The trap is the FIRST thing we set up; everything below sits inside
# its scope.
trap {
    $err = $_
    $log = Join-Path $env:TEMP 'crest-gui-error.log'
    try {
        $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        $text  = "[$stamp] CREST GUI startup failure`r`n"
        $text += "Exception type: " + $err.Exception.GetType().FullName + "`r`n"
        $text += "Message:        " + $err.Exception.Message + "`r`n"
        $text += "At:             " + $err.InvocationInfo.PositionMessage + "`r`n"
        $text += "Stack:`r`n" + $err.ScriptStackTrace + "`r`n"
        Set-Content -Path $log -Value $text -Encoding UTF8
    } catch { }
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        [System.Windows.Forms.MessageBox]::Show(
            ("CREST GUI failed to start." + [Environment]::NewLine + [Environment]::NewLine +
             "Error: " + $err.Exception.Message + [Environment]::NewLine + [Environment]::NewLine +
             "Full details saved to:" + [Environment]::NewLine + $log),
            "CREST GUI", 0, 16) | Out-Null
    } catch { }
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Resolve our tool paths relative to this script -------------------------
$here       = Split-Path -Parent $MyInvocation.MyCommand.Path
$doctorPath  = Join-Path $here 'doctor\Crest-Doctor.ps1'
$compatPath  = Join-Path $here 'compat\Crest-Compat.ps1'
$migrateDll  = Join-Path $here 'migrate\Migrate-ModToCrest.ps1'
$migrateSrc  = Join-Path $here 'migrate\Migrate-ModSourceToCrest.ps1'

foreach ($p in @($doctorPath, $compatPath, $migrateDll, $migrateSrc)) {
    if (-not (Test-Path $p)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Required tool not found: $p`r`n`r`nMake sure Crest-GUI.ps1 lives in the crest/tools/ directory alongside doctor/, compat/, and migrate/.",
            "CREST GUI", [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        exit 1
    }
}

# --- Shared state -----------------------------------------------------------
$script:CurrentProcess = $null

# Output coalescer (Phase U.2 fix): the original "one BeginInvoke per stdout
# line" pattern dropped lines under high volume — a doctor run with -Logs
# (300+ lines in a few seconds) would visibly stall the RichTextBox past the
# crest.json section even though the child process kept emitting. Symptoms:
# the GUI looked frozen, the file output was complete.
#
# Fix: stdout/stderr handlers from Register-ObjectEvent enqueue strings into
# a synchronized List (no UI thread crossing). A WinForms Timer ticking on
# the UI thread drains the queue every 50ms and joins the batched lines into
# ONE AppendText call. That collapses N round-trips into 1, and gives the
# RichTextBox time to repaint between batches.
$script:OutputQueue     = New-Object System.Collections.Generic.List[string]
$script:OutputQueueLock = New-Object Object
$script:PendingStatus   = $null

# --- Helpers ---------------------------------------------------------------
function Append-Output {
    param([string]$Text, [string]$Prefix = '')
    if ([string]::IsNullOrEmpty($Text)) { $line = '' }
    else { $line = if ($Prefix) { "[$Prefix] $Text" } else { $Text } }

    # Lock-protected enqueue so producer threads (Register-ObjectEvent worker
    # thread for stdout/stderr) don't trip over each other, and the UI Timer
    # gets a consistent snapshot when it drains.
    [System.Threading.Monitor]::Enter($script:OutputQueueLock)
    try { [void]$script:OutputQueue.Add($line) }
    finally { [System.Threading.Monitor]::Exit($script:OutputQueueLock) }
}

# Drains the producer queue and writes the joined batch to the RichTextBox in
# a single AppendText call. Runs on the UI thread (called from Timer.Tick).
function Drain-OutputQueue {
    if ($script:OutputBox -eq $null -or -not $script:OutputBox.IsHandleCreated) { return }

    [System.Threading.Monitor]::Enter($script:OutputQueueLock)
    try {
        if ($script:OutputQueue.Count -eq 0) { return }
        $batch = [string]::Join([Environment]::NewLine, $script:OutputQueue) + [Environment]::NewLine
        $script:OutputQueue.Clear()
    } finally { [System.Threading.Monitor]::Exit($script:OutputQueueLock) }

    $script:OutputBox.AppendText($batch)
    # Cap the textbox length to a sane number of characters (~256 KB) so a
    # very long-running session doesn't slow the UI to a crawl. RichTextBox
    # gets sluggish past ~1 MB in our experience; 256 KB keeps several
    # thousand lines in view comfortably.
    if ($script:OutputBox.TextLength -gt 262144) {
        $script:OutputBox.Select(0, $script:OutputBox.TextLength - 200000)
        $script:OutputBox.SelectedText = ''
    }
    # Auto-scroll to end so output stays in view.
    $script:OutputBox.SelectionStart = $script:OutputBox.TextLength
    $script:OutputBox.ScrollToCaret()
}

function Set-Status {
    param([string]$Text)
    if ($script:StatusLabel -eq $null -or -not $script:StatusLabel.IsHandleCreated) {
        $script:PendingStatus = $Text
        return
    }
    if ($script:StatusLabel.InvokeRequired) {
        $script:StatusLabel.BeginInvoke([Action]{ $script:StatusLabel.Text = $Text }) | Out-Null
    } else {
        $script:StatusLabel.Text = $Text
    }
}

# Wired to the form's Shown event. By this point the OutputBox handle is
# guaranteed created. Drain anything Append-Output / Set-Status queued
# before the form was visible, then start the periodic drain timer.
function Drain-PendingOutput {
    Drain-OutputQueue
    if ($script:PendingStatus -ne $null) {
        $script:StatusLabel.Text = $script:PendingStatus
        $script:PendingStatus = $null
    }
}

function Run-Tool {
    param(
        [string]$Label,
        [string]$ScriptPath,
        [string[]]$ToolArgs
    )
    if ($script:CurrentProcess -and -not $script:CurrentProcess.HasExited) {
        [System.Windows.Forms.MessageBox]::Show(
            "Another tool is already running. Click Cancel to stop it first.",
            "CREST GUI", "OK", "Warning") | Out-Null
        return
    }

    $script:OutputBox.Clear()
    Append-Output "==> $Label" 'gui'
    Append-Output ("    " + $ScriptPath + ' ' + ($ToolArgs -join ' ')) 'gui'
    Append-Output ''
    Set-Status "Running $Label..."

    # Build argument string manually -- ProcessStartInfo.ArgumentList is
    # .NET Core 2.1+, not available in Windows PowerShell 5.1's .NET
    # Framework 4.x runtime. Quote any arg that contains whitespace or
    # special characters; escape embedded double-quotes as \".
    function QuoteArg([string]$a) {
        if ($a -match '[\s"]') {
            return '"' + ($a -replace '"', '\"') + '"'
        }
        return $a
    }
    $allArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $ScriptPath) + $ToolArgs
    $argString = ($allArgs | ForEach-Object { QuoteArg $_ }) -join ' '

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'powershell.exe'
    $psi.Arguments = $argString
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    $proc.EnableRaisingEvents = $true

    # Stream both pipes back into the shared output box. Register-ObjectEvent
    # so the GUI thread doesn't block waiting for the child to finish.
    $stdoutHandler = Register-ObjectEvent -InputObject $proc -EventName OutputDataReceived -Action {
        if ($Event.SourceEventArgs.Data) { Append-Output $Event.SourceEventArgs.Data }
    }
    $stderrHandler = Register-ObjectEvent -InputObject $proc -EventName ErrorDataReceived -Action {
        if ($Event.SourceEventArgs.Data) { Append-Output $Event.SourceEventArgs.Data 'stderr' }
    }
    $exitHandler = Register-ObjectEvent -InputObject $proc -EventName Exited -Action {
        $code = $Event.Sender.ExitCode
        Append-Output ''
        Append-Output "==> exit code: $code" 'gui'
        $msg = if ($code -eq 0) { "Done." } else { "Failed (exit $code)." }
        Set-Status $msg
        Unregister-Event -SourceIdentifier $Event.SourceIdentifier -ErrorAction SilentlyContinue
    }

    [void]$proc.Start()
    $proc.BeginOutputReadLine()
    $proc.BeginErrorReadLine()
    $script:CurrentProcess = $proc
}

function Cancel-Current {
    if ($script:CurrentProcess -and -not $script:CurrentProcess.HasExited) {
        try { $script:CurrentProcess.Kill() } catch { }
        Append-Output '==> cancelled by user' 'gui'
        Set-Status "Cancelled."
    }
}

function Pick-Folder {
    param([string]$Description = 'Select a folder')
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $Description
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dlg.SelectedPath
    }
    return $null
}

# --- Build the form --------------------------------------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Crest GUI'
$form.Size = New-Object System.Drawing.Size(900, 720)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = [System.Windows.Forms.DockStyle]::Top
$tabs.Height = 270

# ----- Doctor tab -----
$doctorTab = New-Object System.Windows.Forms.TabPage
$doctorTab.Text = 'Doctor'

$doctorLabel = New-Object System.Windows.Forms.Label
$doctorLabel.Text = "Run health/load-order/compat/logs checks on the CREST install. Pair with Patch Snapshot for bug reports."
$doctorLabel.Location = New-Object System.Drawing.Point(15, 12)
$doctorLabel.Size = New-Object System.Drawing.Size(840, 18)
$doctorTab.Controls.Add($doctorLabel)

$cbHealth = New-Object System.Windows.Forms.CheckBox
$cbHealth.Text = 'Health'; $cbHealth.Checked = $true
$cbHealth.Location = New-Object System.Drawing.Point(15, 40); $cbHealth.AutoSize = $true
$doctorTab.Controls.Add($cbHealth)

$cbLoadOrder = New-Object System.Windows.Forms.CheckBox
$cbLoadOrder.Text = 'LoadOrder'; $cbLoadOrder.Checked = $true
$cbLoadOrder.Location = New-Object System.Drawing.Point(120, 40); $cbLoadOrder.AutoSize = $true
$doctorTab.Controls.Add($cbLoadOrder)

$cbLogs = New-Object System.Windows.Forms.CheckBox
$cbLogs.Text = 'Logs'; $cbLogs.Checked = $true
$cbLogs.Location = New-Object System.Drawing.Point(245, 40); $cbLogs.AutoSize = $true
$doctorTab.Controls.Add($cbLogs)

$cbCompat = New-Object System.Windows.Forms.CheckBox
$cbCompat.Text = 'Compat'; $cbCompat.Checked = $true
$cbCompat.Location = New-Object System.Drawing.Point(330, 40); $cbCompat.AutoSize = $true
$doctorTab.Controls.Add($cbCompat)

$cbSnapshot = New-Object System.Windows.Forms.CheckBox
$cbSnapshot.Text = 'Include patch snapshot (bundles latest in-game capture)'
$cbSnapshot.Location = New-Object System.Drawing.Point(15, 75); $cbSnapshot.AutoSize = $true
$doctorTab.Controls.Add($cbSnapshot)

$lblMod = New-Object System.Windows.Forms.Label
$lblMod.Text = 'Optional: -Mod (analyze a single module)'
$lblMod.Location = New-Object System.Drawing.Point(15, 110); $lblMod.AutoSize = $true
$doctorTab.Controls.Add($lblMod)
$tbMod = New-Object System.Windows.Forms.TextBox
$tbMod.Location = New-Object System.Drawing.Point(15, 130); $tbMod.Size = New-Object System.Drawing.Size(280, 24)
$doctorTab.Controls.Add($tbMod)

$lblReport = New-Object System.Windows.Forms.Label
$lblReport.Text = 'Optional: -ReportPath (.md)'
$lblReport.Location = New-Object System.Drawing.Point(320, 110); $lblReport.AutoSize = $true
$doctorTab.Controls.Add($lblReport)
$tbReport = New-Object System.Windows.Forms.TextBox
$tbReport.Location = New-Object System.Drawing.Point(320, 130); $tbReport.Size = New-Object System.Drawing.Size(420, 24)
$doctorTab.Controls.Add($tbReport)
$btnPickReport = New-Object System.Windows.Forms.Button
$btnPickReport.Text = 'Pick...'
$btnPickReport.Location = New-Object System.Drawing.Point(745, 128); $btnPickReport.Size = New-Object System.Drawing.Size(75, 28)
$btnPickReport.Add_Click({
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = 'Markdown report (*.md)|*.md|All files (*.*)|*.*'
    $dlg.FileName = 'crest-doctor.md'
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $tbReport.Text = $dlg.FileName }
})
$doctorTab.Controls.Add($btnPickReport)

$btnRunDoctor = New-Object System.Windows.Forms.Button
$btnRunDoctor.Text = 'Run Doctor'
$btnRunDoctor.Location = New-Object System.Drawing.Point(15, 180); $btnRunDoctor.Size = New-Object System.Drawing.Size(140, 32)
$btnRunDoctor.Add_Click({
    $cmd = @()
    if ($cbHealth.Checked)    { $cmd += '-Health' }
    if ($cbLoadOrder.Checked) { $cmd += '-LoadOrder' }
    if ($cbLogs.Checked)      { $cmd += '-Logs' }
    if ($cbCompat.Checked)    { $cmd += '-Compat' }
    if ($cbSnapshot.Checked)  { $cmd += '-IncludePatchSnapshot' }
    if ($tbMod.Text.Trim())   { $cmd += @('-Mod', $tbMod.Text.Trim()) }
    if ($tbReport.Text.Trim()){ $cmd += @('-ReportPath', $tbReport.Text.Trim()) }
    Run-Tool 'Crest-Doctor' $doctorPath $cmd
})
$doctorTab.Controls.Add($btnRunDoctor)

$tabs.TabPages.Add($doctorTab)

# ----- Compat tab -----
$compatTab = New-Object System.Windows.Forms.TabPage
$compatTab.Text = 'Compat'

$compatLabel = New-Object System.Windows.Forms.Label
$compatLabel.Text = "Auto-fix compatibility issues: rename bundled 0Harmony / Cecil / MonoMod copies, neutralize redundant TaleWorlds DLLs that hash-match the engine's."
$compatLabel.Location = New-Object System.Drawing.Point(15, 12); $compatLabel.Size = New-Object System.Drawing.Size(840, 36)
$compatTab.Controls.Add($compatLabel)

$rbDryRun = New-Object System.Windows.Forms.RadioButton
$rbDryRun.Text = 'Dry-run (scan + report, no changes)'
$rbDryRun.Location = New-Object System.Drawing.Point(15, 60); $rbDryRun.AutoSize = $true; $rbDryRun.Checked = $true
$compatTab.Controls.Add($rbDryRun)

$rbFix = New-Object System.Windows.Forms.RadioButton
$rbFix.Text = 'Apply fixes (rename duplicates)'
$rbFix.Location = New-Object System.Drawing.Point(15, 85); $rbFix.AutoSize = $true
$compatTab.Controls.Add($rbFix)

$rbRestore = New-Object System.Windows.Forms.RadioButton
$rbRestore.Text = 'Restore (undo previous fixes)'
$rbRestore.Location = New-Object System.Drawing.Point(15, 110); $rbRestore.AutoSize = $true
$compatTab.Controls.Add($rbRestore)

$lblCompatMod = New-Object System.Windows.Forms.Label
$lblCompatMod.Text = 'Optional: -Mod (limit fix to one module)'
$lblCompatMod.Location = New-Object System.Drawing.Point(15, 145); $lblCompatMod.AutoSize = $true
$compatTab.Controls.Add($lblCompatMod)
$tbCompatMod = New-Object System.Windows.Forms.TextBox
$tbCompatMod.Location = New-Object System.Drawing.Point(15, 165); $tbCompatMod.Size = New-Object System.Drawing.Size(280, 24)
$compatTab.Controls.Add($tbCompatMod)

$btnRunCompat = New-Object System.Windows.Forms.Button
$btnRunCompat.Text = 'Run Compat'
$btnRunCompat.Location = New-Object System.Drawing.Point(15, 200); $btnRunCompat.Size = New-Object System.Drawing.Size(140, 32)
$btnRunCompat.Add_Click({
    $cmd = @()
    if ($rbFix.Checked)     { $cmd += '-Fix' }
    if ($rbRestore.Checked) { $cmd += '-Restore' }
    if ($tbCompatMod.Text.Trim()) { $cmd += @('-Mod', $tbCompatMod.Text.Trim()) }
    Run-Tool 'Crest-Compat' $compatPath $cmd
})
$compatTab.Controls.Add($btnRunCompat)

$tabs.TabPages.Add($compatTab)

# ----- Migrate DLLs tab -----
$dllTab = New-Object System.Windows.Forms.TabPage
$dllTab.Text = 'Migrate DLLs'

$dllLabel = New-Object System.Windows.Forms.Label
$dllLabel.Text = 'Rewrite a community mod''s already-built DLLs from upstream-BUTR AssemblyRefs to CREST.* equivalents. Reversible (creates *.dll.bak).'
$dllLabel.Location = New-Object System.Drawing.Point(15, 12); $dllLabel.Size = New-Object System.Drawing.Size(840, 36)
$dllTab.Controls.Add($dllLabel)

$lblDllPath = New-Object System.Windows.Forms.Label
$lblDllPath.Text = 'Path (folder of mod or single .dll)'
$lblDllPath.Location = New-Object System.Drawing.Point(15, 65); $lblDllPath.AutoSize = $true
$dllTab.Controls.Add($lblDllPath)
$tbDllPath = New-Object System.Windows.Forms.TextBox
$tbDllPath.Location = New-Object System.Drawing.Point(15, 85); $tbDllPath.Size = New-Object System.Drawing.Size(720, 24)
$dllTab.Controls.Add($tbDllPath)
$btnPickDll = New-Object System.Windows.Forms.Button
$btnPickDll.Text = 'Pick...'
$btnPickDll.Location = New-Object System.Drawing.Point(745, 83); $btnPickDll.Size = New-Object System.Drawing.Size(75, 28)
$btnPickDll.Add_Click({ $f = Pick-Folder 'Select the mod folder containing DLLs to migrate'; if ($f) { $tbDllPath.Text = $f } })
$dllTab.Controls.Add($btnPickDll)

$cbDllDryRun = New-Object System.Windows.Forms.CheckBox
$cbDllDryRun.Text = 'Dry-run (show plan, write nothing)'
$cbDllDryRun.Location = New-Object System.Drawing.Point(15, 125); $cbDllDryRun.AutoSize = $true; $cbDllDryRun.Checked = $true
$dllTab.Controls.Add($cbDllDryRun)
$cbDllNoBackup = New-Object System.Windows.Forms.CheckBox
$cbDllNoBackup.Text = 'No backup (skip *.dll.bak)'
$cbDllNoBackup.Location = New-Object System.Drawing.Point(15, 150); $cbDllNoBackup.AutoSize = $true
$dllTab.Controls.Add($cbDllNoBackup)

$btnRunDll = New-Object System.Windows.Forms.Button
$btnRunDll.Text = 'Migrate DLLs'
$btnRunDll.Location = New-Object System.Drawing.Point(15, 195); $btnRunDll.Size = New-Object System.Drawing.Size(140, 32)
$btnRunDll.Add_Click({
    $p = $tbDllPath.Text.Trim()
    if (-not $p) { [System.Windows.Forms.MessageBox]::Show("Pick a path first.", "CREST GUI", "OK", "Information") | Out-Null; return }
    $cmd = @('-Path', $p, '-Force')
    if ($cbDllDryRun.Checked)   { $cmd += '-DryRun' }
    if ($cbDllNoBackup.Checked) { $cmd += '-NoBackup' }
    Run-Tool 'Migrate-ModToCrest (DLL)' $migrateDll $cmd
})
$dllTab.Controls.Add($btnRunDll)

$tabs.TabPages.Add($dllTab)

# ----- Migrate Source tab -----
$srcTab = New-Object System.Windows.Forms.TabPage
$srcTab.Text = 'Migrate Source'

$srcLabel = New-Object System.Windows.Forms.Label
$srcLabel.Text = "Rewrite a mod's source tree (csproj PackageReference / Reference / HintPath, optional SubModule.xml DependedModule entries) so it compiles against CREST."
$srcLabel.Location = New-Object System.Drawing.Point(15, 12); $srcLabel.Size = New-Object System.Drawing.Size(840, 36)
$srcTab.Controls.Add($srcLabel)

$lblSrcPath = New-Object System.Windows.Forms.Label
$lblSrcPath.Text = "Path (mod's source repo / src folder)"
$lblSrcPath.Location = New-Object System.Drawing.Point(15, 65); $lblSrcPath.AutoSize = $true
$srcTab.Controls.Add($lblSrcPath)
$tbSrcPath = New-Object System.Windows.Forms.TextBox
$tbSrcPath.Location = New-Object System.Drawing.Point(15, 85); $tbSrcPath.Size = New-Object System.Drawing.Size(720, 24)
$srcTab.Controls.Add($tbSrcPath)
$btnPickSrc = New-Object System.Windows.Forms.Button
$btnPickSrc.Text = 'Pick...'
$btnPickSrc.Location = New-Object System.Drawing.Point(745, 83); $btnPickSrc.Size = New-Object System.Drawing.Size(75, 28)
$btnPickSrc.Add_Click({ $f = Pick-Folder "Select the mod source repo to migrate"; if ($f) { $tbSrcPath.Text = $f } })
$srcTab.Controls.Add($btnPickSrc)

$cbSrcDryRun = New-Object System.Windows.Forms.CheckBox
$cbSrcDryRun.Text = 'Dry-run (show plan, write nothing)'
$cbSrcDryRun.Location = New-Object System.Drawing.Point(15, 125); $cbSrcDryRun.AutoSize = $true; $cbSrcDryRun.Checked = $true
$srcTab.Controls.Add($cbSrcDryRun)
$cbSrcXml = New-Object System.Windows.Forms.CheckBox
$cbSrcXml.Text = "Include SubModule.xml (rewrite DependedModule entries)"
$cbSrcXml.Location = New-Object System.Drawing.Point(15, 150); $cbSrcXml.AutoSize = $true
$srcTab.Controls.Add($cbSrcXml)
$cbSrcNoBackup = New-Object System.Windows.Forms.CheckBox
$cbSrcNoBackup.Text = 'No backup (skip *.bak)'
$cbSrcNoBackup.Location = New-Object System.Drawing.Point(15, 175); $cbSrcNoBackup.AutoSize = $true
$srcTab.Controls.Add($cbSrcNoBackup)

$btnRunSrc = New-Object System.Windows.Forms.Button
$btnRunSrc.Text = 'Migrate Source'
$btnRunSrc.Location = New-Object System.Drawing.Point(15, 215); $btnRunSrc.Size = New-Object System.Drawing.Size(140, 32)
$btnRunSrc.Add_Click({
    $p = $tbSrcPath.Text.Trim()
    if (-not $p) { [System.Windows.Forms.MessageBox]::Show("Pick a path first.", "CREST GUI", "OK", "Information") | Out-Null; return }
    $cmd = @('-Path', $p, '-Force')
    if ($cbSrcDryRun.Checked)   { $cmd += '-DryRun' }
    if ($cbSrcXml.Checked)      { $cmd += '-IncludeSubModuleXml' }
    if ($cbSrcNoBackup.Checked) { $cmd += '-NoBackup' }
    Run-Tool 'Migrate-ModSourceToCrest' $migrateSrc $cmd
})
$srcTab.Controls.Add($btnRunSrc)

$tabs.TabPages.Add($srcTab)

$form.Controls.Add($tabs)

# --- Output pane -----------------------------------------------------------
$bottomPanel = New-Object System.Windows.Forms.Panel
$bottomPanel.Dock = [System.Windows.Forms.DockStyle]::Fill

$btnClear = New-Object System.Windows.Forms.Button
$btnClear.Text = 'Clear output'; $btnClear.Location = New-Object System.Drawing.Point(15, 10); $btnClear.Size = New-Object System.Drawing.Size(110, 28)
$btnClear.Add_Click({ $script:OutputBox.Clear() })
$bottomPanel.Controls.Add($btnClear)

$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Text = 'Cancel running'; $btnCancel.Location = New-Object System.Drawing.Point(135, 10); $btnCancel.Size = New-Object System.Drawing.Size(110, 28)
$btnCancel.Add_Click({ Cancel-Current })
$bottomPanel.Controls.Add($btnCancel)

$script:StatusLabel = New-Object System.Windows.Forms.Label
$script:StatusLabel.Text = 'Idle.'; $script:StatusLabel.Location = New-Object System.Drawing.Point(260, 16); $script:StatusLabel.AutoSize = $true
$bottomPanel.Controls.Add($script:StatusLabel)

# RichTextBox rather than TextBox: TextBox.ScrollBars=Both doesn't always
# wire up mouse-wheel handling unless the control has focus, and our users
# expect to run a tool then scroll its output without first clicking into
# the box. RichTextBox handles wheel-on-hover natively and shares the same
# AppendText / Clear / IsHandleCreated API surface we rely on.
$script:OutputBox = New-Object System.Windows.Forms.RichTextBox
$script:OutputBox.Multiline = $true
$script:OutputBox.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Both
$script:OutputBox.WordWrap = $false
$script:OutputBox.ReadOnly = $true
$script:OutputBox.DetectUrls = $false
$script:OutputBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$script:OutputBox.Location = New-Object System.Drawing.Point(0, 50)
$script:OutputBox.Size = New-Object System.Drawing.Size(880, 360)
$script:OutputBox.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor `
                          [System.Windows.Forms.AnchorStyles]::Bottom -bor `
                          [System.Windows.Forms.AnchorStyles]::Left -bor `
                          [System.Windows.Forms.AnchorStyles]::Right
$bottomPanel.Controls.Add($script:OutputBox)

$form.Controls.Add($bottomPanel)
# Re-add tabs at top so the panel above doesn't cover them. Dock order in
# WinForms applies in REVERSE z-order: child added first sits "behind".
$form.Controls.SetChildIndex($tabs, 0)

# --- Run the form ---------------------------------------------------------
Append-Output ('CREST GUI -- ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) 'gui'
Append-Output "Tools located at: $here" 'gui'
Append-Output ''
# Phase U.2: drive Drain-OutputQueue from a WinForms Timer so child-process
# stdout/stderr (handled on worker threads via Register-ObjectEvent) gets
# coalesced and flushed to the RichTextBox in batches. Runs on the UI
# thread so no Invoke marshalling needed inside Drain-OutputQueue.
$script:DrainTimer = New-Object System.Windows.Forms.Timer
$script:DrainTimer.Interval = 50  # ms — fast enough to feel responsive, slow enough to coalesce
$script:DrainTimer.Add_Tick({ Drain-OutputQueue })
$form.Add_Shown({
    Drain-PendingOutput
    $script:DrainTimer.Start()
})
$form.Add_FormClosing({
    $script:DrainTimer.Stop()
    Drain-OutputQueue  # one final pass so anything mid-flight isn't lost
})
[void]$form.ShowDialog()
