# CREST Changelog

## v1.4.2 — Cinema Release (initial public release)

The first public Nexus release of CREST. Targets Bannerlord v1.4.2.

### Added — Player‑facing
- **Battle Convergence** — nearby AI lord parties rally to the player's battle. Staggered arrivals, asymmetric ally radius (3× ally reach), tactics‑by‑skill behavior tiering, post‑battle dialogue with lords who joined as reinforcements.
- **Cinema Preset** — one‑click MCM preset for recording / content creation. Convergence on with 5 s initial / 3 s cadence / 100 base radius / 20 joiner cap, player invincibility on, achievements still armed.
- **Player Invincibility** (toggle) — `Mission.MainAgent.Health` pegs at HealthLimit each tick. Hits and animations still play. Mission‑mode and lifecycle gated to avoid corrupting half‑disposed agents.
- **Achievement Protection** — keeps `EnableAchievementsWithMods = true` armed across preset switches. Default and Cinema presets ship achievement‑safe.
- **MCM presets** — Default / Cinema / Vanilla, switchable mid‑session, with per‑field overrides that persist until you re‑pick a preset.
- **Companion Hotswap** — bound to the Z key by default. Configurable in MCM.

### Added — Modder‑facing
- **`CrestDiag` public API** — `Log`, `LogCaught`, `LogTypeNotFound`, `Flush`. Append‑only diagnostic logger anchored at `Modules\CREST\runtime.log`. Works before ButterLib initializes.
- **`CrestConfig` public API** — `IsEnabled`, `GetInt`, `GetFloat`, `GetString`. mtime‑throttled hot‑refresh on `crest.json`.
- **MCM `MemorySettingsPreset`** — register your own presets; inherit Cinema/Default/Vanilla compatibility for free.
- **`Crest-ReleaseBuild.ps1`** — production release packager. Builds, stages, validates required DLLs, strips forbidden artifacts, emits a clean shippable zip.
- **`Crest-FreshInstallTest.ps1`** — fresh‑install validation harness. Snapshots, wipes, extracts, and verifies a clean boot.

### Bundled (drop‑in shim layer)
- Harmony (Bannerlord build), version‑pinned.
- ButterLib, version‑pinned.
- Mod Configuration Menu v5 (MCMv5), version‑pinned.
- UIExtenderEx, version‑pinned.

Remove standalone copies of these four mods after installing CREST.

### Performance
- **Buffered diagnostic logging** — `CrestDiag` queues lines and flushes once per second via a background timer. ~30–60 fewer syscalls per battle. AppDomain unload sweeps the buffer so the last few lines aren't lost on clean shutdown. Eliminates the trailing‑null‑bytes signature that used to appear when the engine crashed mid‑write.
- **Cached config reads on hot paths** — `CrestPlayerInvincible` caches its master toggle with a 500 ms refresh window matching `CrestConfig`'s mtime throttle. Saves ~3 000 dictionary lookups per second.
- **Mission‑mode early‑out** — `CrestBattleConvergence` skips its tick handler outside `MissionMode.Battle`. Deployment, transitions, and post‑battle results are no‑op.
- **Debug‑gated verbose logs** — convergence per‑agent and per‑spawn‑position lines now only emit when `debugmode=true`. Useful summaries (`tick‑status`, `queued`, `registered`, `capGuard`, Stage 1) preserved.

The result: **smooth at 64× campaign speed on the v1.4.2 base game.** This is the headline metric. Regressions on this axis are treated as bugs.

### Stability fixes during the Y.12 series
- **Y.12d‑fix31 (root cause)** — collapsed 3‑bucket per‑lord formation split (Inf/Ranged/Cav) back to 1 formation per lord. The 3‑bucket split overflowed the engine's formation tables at ~24+ active formations and produced the 596‑pending‑agent hard crash with the trailing‑null‑bytes log signature.
- **Y.12d‑fix30** — Player Invincibility now skips on `Mission.Mode != MissionMode.Battle`, `IsMissionEnding`, `!IsHuman`. Avoids mutating health on half‑disposed agents during transitions.
- **Y.12d‑fix29** — asymmetric ally/enemy radius. Allies use `radius * 3` because they "rally to" the player from kingdom territory; enemies use the base radius. Fixes deep‑in‑enemy‑territory battles where only enemies were within the symmetric radius.
- **Y.12d‑fix27** — joiner cap 100 → 20 to prevent reserved‑queue overflow crash.
- **Y.12d‑fix22** — replaced `MissionTimer.Check()` (which never returned true) with explicit `Mission.Current.CurrentTime` arithmetic.
- **Y.12d‑fix22b** — neutral 1.0× delay multiplier (was a stale 3 000 ms producing 3× delays).
- **Y.12d‑fix22c** — companion hotkey default 55 (NumpadMultiply, conflicted) → 44 (Z).

### Known limitations
- v1.4.2 only. Earlier game versions are not supported.
- Native CREST primitives are not yet shipped — the current release wraps and redistributes the four shims. Phase Y.14+ introduces native equivalents alongside the shims; Phase Z.10 is the shim removal milestone.

### Roadmap (next planned phases)
- **Y.4** — Absorb RTSCamera + CommandSystem.
- **Y.6** — Troop equipment / class changer in‑mission.
- **Y.8** — In‑game troop spawner.
- **Y.13** — Absorb BetterTroopHUD.
- **Y.24 / Y.25 / Y.26** — Live Battles / Live Arena / Live Tavern (multiplayer hot‑swap).
- **Stretch** — Hot‑reload of consumer mod DLLs.

---

For the full feature description, FAQ, and modder API, see `NEXUS_DESCRIPTION.md` or the Nexus mod page.
