# Building a Bannerlord mod on CREST

CREST is a unified Bannerlord modding stack that bundles forks of Harmony,
ButterLib, UIExtenderEx, and MCM under a single SubModule. If your mod
depends on any of those four, depending on CREST is the simplest way to
ship: one user-side install, no version conflicts between the four
foundation libraries, and a stable runtime API for diagnostics, configuration,
and crash-tolerant patching.

This guide walks you through the modder workflow end-to-end.

## Quickstart

```powershell
# 1. Make sure CREST is installed (game's Modules/CREST/ exists).
ls "C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules\CREST\bin\Win64_Shipping_Client\Crest.Harmony.dll"

# 2. Scaffold a new mod.
cd C:\dev\bannerlord\crest\tools
.\Crest-NewMod.ps1 -Name "MyTweak"

# 3. Edit, build, deploy.
cd C:\dev\bannerlord\MyTweak
# ... edit src\MyTweak\Patches\ExamplePatch.cs ...
.\Build-And-Deploy.ps1

# 4. Launch Bannerlord. Enable "MyTweak" in the launcher under Community.
```

That's it. The scaffold writes a complete csproj with the right reference
paths to CREST's bin folder, a `SubModule.xml` declaring the dependency, an
example Harmony patch, and a one-button build script that does per-runtime
deploys (net472 to Steam, net6 to Game Pass).

---

## What CREST gives you

Your mod automatically has access to these APIs once you scaffold via
`Crest-NewMod.ps1`:

### `CrestDiag` — append-only diagnostic logger

Lives at `Modules/CREST/runtime.log`. Used by every CREST sub-module so the
file is the single place users look when something goes wrong. **Your mod
should write here too** — it makes support requests dramatically easier.

```csharp
using Bannerlord.Harmony;

CrestDiag.Log("MyTweak", "loaded successfully");
CrestDiag.Log("MyTweak.Patches", "applied speed postfix");

try
{
    DoRiskyThing();
}
catch (Exception ex)
{
    CrestDiag.LogCaught("MyTweak", "DoRiskyThing", ex);
    // ... fall back to safe behavior, don't rethrow into a Harmony patch ...
}

// "Tried to look up TaleWorlds.X.Y but it was null" is so common that
// there's a one-line helper for it:
CrestDiag.LogTypeNotFound("MyTweak", "TaleWorlds.CampaignSystem.SomeRenamedType");
```

### `CrestConfig` — read flags from `crest.json`

`Modules/CREST/crest.json` is shared by CREST and any consumer mod that
wants to expose user-toggleable flags without taking a hard dependency on
MCM. The file is mtime-cached and reread automatically when it changes.

```csharp
using Bannerlord.Harmony;

bool   featureOn = CrestConfig.IsEnabled("MyTweak_FeatureName", defaultValue: false);
float  multiplier = CrestConfig.GetFloat("MyTweak_Multiplier", 1.5f);
int    cap        = CrestConfig.GetInt  ("MyTweak_MaxCount", 10);
string scope      = CrestConfig.GetString("MyTweak_Scope", "All");
```

Convention for keys: prefix with your mod ID (`"MyTweak_*"`) so users can
tell at a glance which lines belong to which mod when they hand-edit the
file. Don't use raw names like `"Multiplier"` — they will collide.

### `CrestSafeBind` — crash-tolerant Harmony patching

Wraps `harmony.Patch(...)` with three things consumer mods always have to
write themselves:

1. Tolerant type/method lookup — passing names as strings means a
   missing-target after a game update logs a one-line miss instead of
   crashing your `OnSubModuleLoad`.
2. Catch-and-log around the actual `Patch` call — Harmony's bind step can
   throw on arity mismatches; SafeBind logs and returns `false` so the
   rest of your mod still runs.
3. Crest-Doctor registration — every successfully-bound patch goes into
   a static registry that the diagnostic tool can dump.

```csharp
using Bannerlord.Harmony;
using HarmonyLib;

private static readonly Harmony _harmony = new("MyTweak");

protected override void OnSubModuleLoad()
{
    CrestSafeBind.Patch(_harmony,
        type:    "TaleWorlds.CampaignSystem.Party.MobileParty",
        method:  "CalculateSpeed",
        postfix: nameof(SpeedPostfix),
        owner:   typeof(SubModule),
        label:   "MyTweak.Speed");

    // Multiple kinds at once:
    CrestSafeBind.Patch(_harmony,
        type:    "TaleWorlds.MountAndBlade.Mission",
        method:  "RegisterBlow",
        prefix:  nameof(BlowPrefix),
        postfix: nameof(BlowPostfix),
        owner:   typeof(SubModule),
        label:   "MyTweak.Combat");

    // Conveniences for the common single-handler case:
    CrestSafeBind.PatchSimple(_harmony,
        "TaleWorlds.CampaignSystem.Hero",
        "set_Power",
        nameof(HeroPowerPostfix),
        typeof(SubModule),
        kind: "postfix",
        label: "MyTweak.HeroPower");
}

public static void SpeedPostfix(ref float __result) => __result *= 1.10f;
public static bool BlowPrefix(...)   { /* ... */ return true; }
public static void BlowPostfix(...)  { /* ... */ }
public static void HeroPowerPostfix(ref float __result) => __result += 5f;
```

`CrestSafeBind.Patch` returns `bool` — `true` on success, `false` if
anything failed. Inspect this to gracefully disable a feature when its
target method is missing:

```csharp
var bound = CrestSafeBind.Patch(_harmony, "TaleWorlds.X", "Y", postfix: nameof(P), owner: typeof(SubModule), label: "MyTweak.YHook");
if (!bound)
{
    CrestDiag.Log("MyTweak", "YHook unavailable on this game version; feature disabled");
    return;
}
```

---

## Common patterns

### Gating an entire feature on a config flag

```csharp
public static void MyPostfix(ref bool __result)
{
    if (!CrestConfig.IsEnabled("MyTweak_FeatureX", defaultValue: false)) return;
    __result = true;
}
```

The early return is dirt cheap (one mtime stat + a dictionary lookup,
both cached behind a 500ms throttle) so it's safe even on hot paths
called every frame.

### Adding an MCM toggle for your mod

If you want users to flip your config flags from the in-game Mod Options
menu instead of editing `crest.json` by hand, you can host an MCM page
inside your own DLL (since CREST exposes the MCM v5 API). The simplest
shape:

```csharp
using MCM.Abstractions.Attributes;
using MCM.Abstractions.Attributes.v2;
using MCM.Abstractions.Base.Global;

internal sealed class MyTweakSettings : AttributeGlobalSettings<MyTweakSettings>
{
    public override string Id => "MyTweak_v1";
    public override string DisplayName => "MyTweak";

    [SettingPropertyBool("Enable feature X", Order = 1)]
    [SettingPropertyGroup("My Tweak")]
    public bool EnableFeatureX { get; set; } = false;
}
```

MCM auto-discovers this on first launch.

### Reading runtime data sourced by another CREST mod

`CrestSafeBind.GetRegisteredPatches()` returns every patch any consumer
mod has bound through SafeBind. Useful for a compatibility dashboard:

```csharp
foreach (var p in CrestSafeBind.GetRegisteredPatches())
{
    Console.WriteLine($"{p.OwnerAssembly,-30} {p.Label,-30} {p.PatchKind,-10} {p.TargetType}.{p.TargetMethod}");
}
```

### Dealing with `out` / `ref` parameters in Harmony postfixes

Match the original method's signature parameter-by-parameter, but use
`ref` instead of `out` (Harmony binds them as the same).

```csharp
// Original: bool TryParseFoo(string input, out int parsed)
public static void TryParseFooPostfix(string input, ref int parsed, ref bool __result)
{
    if (!__result) return;
    parsed = Math.Min(parsed, 100);  // clamp
}
```

---

## Troubleshooting

### "X submodule could not be loaded correctly due to a dependency conflict"

Engine catch-all for "DLL didn't initialize cleanly." Check
`Modules/CREST/runtime.log` first — `CrestDiag` and `CrestSafeBind` will
have logged the actual exception if it's anywhere in your patch
binding code. If your mod's patches use SafeBind, a missing target
won't trigger this dialog; only a hard exception in `OnSubModuleLoad`
or in a static initializer will.

### Patches don't fire

1. Verify your handler matches the original method's parameter shape
   (Harmony binds postfix params by name, so `__result` must be the
   right type).
2. Confirm `CrestSafeBind.Patch` returned `true` (look in `runtime.log`
   for your label).
3. Confirm the target method really runs — it's easy to patch a method
   that's overridden by a more-derived class. Patch the override
   instead, or patch the abstract base if Harmony allows.

### Game crashes only on certain map screens

The pattern almost always traces to a patch on a method that has a
non-trivial null-state on that screen. CREST's `CrestPatchSelfTest`
runs at game start and logs every patch CREST itself binds; modders'
patches via SafeBind are also tracked, so the first triage step is
checking whether the crash stack contains a method you've patched. If
yes, defensive guard the postfix (`if (party == null) return;`).

### "Cannot assign method return type System.Single to __result type System.Int32"

Harmony tells you the postfix's `__result` type doesn't match the
original method's return type. In CREST this hit us on a `_desiredTotalCompanionCount`
property that returned float — the fix was changing `ref int __result`
to `ref float __result`. Cecil-decompile the method and confirm the
return type before you write the postfix.

---

## How CREST stays current with game updates

When a Bannerlord patch ships, the workflow:

1. Run `Crest-Doctor` (in `crest\tools\doctor\`) — it scans every patch
   CREST has bound and reports which ones now point at missing types or
   methods.
2. Patch the affected SubModule, rebuild, redeploy.
3. Push a new CREST release.

Your mod inherits this hardening for free as long as it uses
`CrestSafeBind`. Patches that won't bind on the new game version log a
miss instead of crashing — your users keep playing, you ship a fix when
you can.

---

## Reference assemblies & game DLLs

The default `HintPath` in the generated csproj points at the Steam install:

- `C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules\CREST\bin\Win64_Shipping_Client\` for CREST DLLs.
- `C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\bin\Win64_Shipping_Client\` for TaleWorlds DLLs.

If your install is elsewhere, override at build time:

```powershell
dotnet build -p:CrestBin="D:\Games\Bannerlord\Modules\CREST\bin\Win64_Shipping_Client" `
             -p:GameBin="D:\Games\Bannerlord\bin\Win64_Shipping_Client"
```

---

## Status

This API surface is considered stable as of Phase Y.9. The methods
documented here will not be renamed or have their parameter shape
changed in a breaking way without a deprecation cycle.
