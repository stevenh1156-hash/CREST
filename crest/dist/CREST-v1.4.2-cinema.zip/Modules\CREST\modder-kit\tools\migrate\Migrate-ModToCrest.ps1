# Migrate-ModToCrest.ps1 -- Phase Q (DLL rewriter)
#
# Walks a community mod's compiled DLLs and rewrites AssemblyReference rows
# from upstream BUTR names (Bannerlord.Harmony / Bannerlord.ButterLib /
# Bannerlord.UIExtenderEx / MCMv5) to CREST equivalents (Crest.Harmony /
# Crest.ButterLib / Crest.UIExtenderEx / Crest.MCM).
#
# Why bother? CREST currently ships compatibility shim DLLs (Bannerlord.Harmony.dll
# etc.) that TypeForwardedTo into our Crest.X.dll. The shims work, but they're
# extra payload, an extra runtime resolution step, and a maintenance surface
# that has to be regenerated on every CREST build. Mods migrated by this tool
# reference Crest.X.dll directly and don't need the shim layer.
#
# What it does NOT change: type names, namespaces, or method signatures. The
# migrated mod still has `using Bannerlord.Harmony;` in its source (if you
# look at the IL -- the source is gone by the time we see a compiled DLL); the
# type FQNs `Bannerlord.Harmony.SubModule` etc. are unchanged. Only the
# AssemblyRef.Name field changes from `Bannerlord.Harmony` to `Crest.Harmony`.
# This works because our Crest.X.dll's source declares its types under those
# same Bannerlord.* / MCM.* namespaces (post-Phase-H namespace revert).
#
# Usage:
#   .\Migrate-ModToCrest.ps1 -Path C:\Bannerlord\Modules\BloodMod1313
#   .\Migrate-ModToCrest.ps1 -Path .\bin\Release\net472 -DryRun
#   .\Migrate-ModToCrest.ps1 -Path .\path\to\mod -Force -NoBackup
#
# Flags:
#   -DryRun      Show migration plan, write nothing.
#   -Force       Skip the y/N prompt.
#   -NoBackup    Skip writing *.dll.bak files (CI / scripted use).
#   -CecilPath   Override location of Mono.Cecil.dll (default: probes CREST install + crest dev tree).

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$Path,
    [switch]$DryRun,
    [switch]$Force,
    [switch]$NoBackup,
    [string]$CecilPath
)

$ErrorActionPreference = 'Stop'

# Mapping table: upstream AssemblyRef name -> CREST AssemblyRef name.
# Versions are preserved from whatever the consumer mod was compiled against;
# Crest.X.dll is unsigned so the runtime ignores version mismatches at bind time.
$nameMap = @{
    'Bannerlord.Harmony'       = 'Crest.Harmony'
    'Bannerlord.ButterLib'     = 'Crest.ButterLib'
    'Bannerlord.UIExtenderEx'  = 'Crest.UIExtenderEx'
    'MCMv5'                    = 'Crest.MCM'
}

# --- Locate Mono.Cecil ---
if (-not $CecilPath) {
    $candidates = @(
        'C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord\Modules\CREST\bin\Win64_Shipping_Client\Mono.Cecil.dll',
        'C:\dev\bannerlord\Bannerlord.Harmony\src\Crest.Harmony\bin\Release\net472\Mono.Cecil.dll'
    )
    $CecilPath = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $CecilPath -or -not (Test-Path $CecilPath)) {
    Write-Error "Mono.Cecil.dll not found. Pass -CecilPath explicitly. Tried:`n  $($candidates -join "`n  ")"
    exit 1
}
Add-Type -Path $CecilPath
Write-Host "Using Mono.Cecil from $CecilPath" -ForegroundColor DarkGray

# --- Validate target path ---
if (-not (Test-Path $Path)) {
    Write-Error "Path not found: $Path"
    exit 1
}

$item = Get-Item $Path
if ($item.PSIsContainer) {
    $dlls = Get-ChildItem -Recurse -File -Path $Path -Filter '*.dll' |
        Where-Object {
            # Skip our own bundled DLLs if user accidentally points at the CREST
            # module folder. Migrating Crest.* / shim DLLs would be a no-op and
            # could corrupt them by mistake.
            $_.Name -notmatch '^(Crest\.|Bannerlord\.Harmony|Bannerlord\.ButterLib|Bannerlord\.UIExtenderEx|MCMv5|0Harmony|Mono\.Cecil|MonoMod|Newtonsoft|System\.|Microsoft\.|Serilog|BUTR\.|cimgui|glfw|DotNetZip|BetterException)\.dll$'
        }
} elseif ($item.Extension -eq '.dll') {
    $dlls = @($item)
} else {
    Write-Error "Path must be a folder or a .dll file"
    exit 1
}

if (-not $dlls -or $dlls.Count -eq 0) {
    Write-Host "No candidate DLLs found at $Path" -ForegroundColor Yellow
    exit 0
}

# --- Build the migration plan ---
Write-Host ""
Write-Host "==> Scanning $($dlls.Count) DLL(s) for upstream-BUTR references" -ForegroundColor Cyan

$plan = @()
foreach ($dll in $dlls) {
    $asm = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($dll.FullName)
    try {
        $rewrites = @()
        foreach ($r in $asm.MainModule.AssemblyReferences) {
            if ($nameMap.ContainsKey($r.Name)) {
                $rewrites += [pscustomobject]@{
                    OldName = $r.Name
                    NewName = $nameMap[$r.Name]
                    Version = $r.Version
                }
            }
        }
        if ($rewrites.Count -gt 0) {
            $plan += [pscustomobject]@{
                Dll      = $dll
                Rewrites = $rewrites
            }
        }
    } finally { $asm.Dispose() }
}

if ($plan.Count -eq 0) {
    Write-Host "  no references to rewrite -- already migrated, or doesn't depend on the BUTR stack." -ForegroundColor Green
    exit 0
}

Write-Host ""
Write-Host "==> Migration plan" -ForegroundColor Cyan
foreach ($p in $plan) {
    Write-Host ("  {0}" -f $p.Dll.Name) -ForegroundColor White
    foreach ($r in $p.Rewrites) {
        Write-Host ("    {0} v{1}  =>  {2} v{1}" -f $r.OldName, $r.Version, $r.NewName)
    }
}

if ($DryRun) {
    Write-Host ""
    Write-Host "==> Dry run -- no files written." -ForegroundColor Yellow
    exit 0
}

# --- Confirm ---
if (-not $Force) {
    Write-Host ""
    $resp = Read-Host "Apply migration? Originals will be backed up to *.dll.bak unless -NoBackup is set [y/N]"
    if ($resp -notmatch '^(y|yes)$') {
        Write-Host "Aborted." -ForegroundColor Yellow
        exit 0
    }
}

# --- Apply ---
Write-Host ""
Write-Host "==> Applying" -ForegroundColor Cyan
$migrated = 0
foreach ($p in $plan) {
    $dllPath = $p.Dll.FullName

    # Backup original
    if (-not $NoBackup) {
        $backupPath = $dllPath + '.bak'
        if (-not (Test-Path $backupPath)) {
            Copy-Item $dllPath $backupPath -Force
            Write-Host ("  backed up   {0}" -f $p.Dll.Name) -ForegroundColor DarkGray
        } else {
            Write-Host ("  backup exists - skipping backup of {0}" -f $p.Dll.Name) -ForegroundColor DarkGray
        }
    }

    # Read with write-side enabled
    $readerParams = [Mono.Cecil.ReaderParameters]::new()
    $readerParams.ReadWrite = $true
    $readerParams.ReadSymbols = $false

    $asm = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($dllPath, $readerParams)
    try {
        $count = 0
        foreach ($r in $asm.MainModule.AssemblyReferences) {
            if ($nameMap.ContainsKey($r.Name)) {
                $newName = $nameMap[$r.Name]
                # Cecil's AssemblyNameReference.Name is a settable property; set
                # it directly. The Version field is unchanged.
                $r.Name = $newName
                # PublicKeyToken: Crest.X.dll is unsigned so the consumer mod's
                # token (typically null already) shouldn't need changing. If it's
                # non-null we wipe it so binding doesn't demand a strong-name
                # match against an unsigned assembly.
                if ($r.PublicKeyToken -and $r.PublicKeyToken.Length -gt 0) {
                    $r.PublicKeyToken = $null
                }
                $count++
            }
        }
        $asm.Write()
        Write-Host ("  rewrote     {0}  ({1} refs)" -f $p.Dll.Name, $count) -ForegroundColor Green
        $migrated++
    } finally { $asm.Dispose() }
}

Write-Host ""
Write-Host ("==> Migrated {0} DLL(s). To roll back, copy *.dll.bak over *.dll." -f $migrated) -ForegroundColor Green
