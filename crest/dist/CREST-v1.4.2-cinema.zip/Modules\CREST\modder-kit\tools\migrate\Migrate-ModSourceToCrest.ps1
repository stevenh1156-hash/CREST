# Migrate-ModSourceToCrest.ps1 -- Phase Q.2 (source-mode rewriter)
#
# Walks a community mod's SOURCE TREE (csproj + SubModule.xml + optionally
# selected .cs files) and rewrites upstream-BUTR references to point at
# CREST equivalents, so the mod re-compiles against CREST without going
# through the shim DLL layer.
#
# Companion to Migrate-ModToCrest.ps1 (Phase Q), which rewrites already-built
# DLLs. Pick the source rewriter when you have the mod's repo and intend to
# rebuild; pick the DLL rewriter when you only have the compiled output.
#
# What this script changes:
#
#   *.csproj
#     <PackageReference Include="Bannerlord.Harmony"  ...  />   ->   Crest.Harmony
#     <Reference        Include="Bannerlord.Harmony"  ...  />   ->   Crest.Harmony
#     <HintPath>...\Bannerlord.Harmony.dll</HintPath>           ->   Crest.Harmony.dll
#     (and the same for Bannerlord.ButterLib / Bannerlord.UIExtenderEx / MCMv5)
#
#   SubModule.xml  (only when -IncludeSubModuleXml is passed)
#     <DependedModule Id="Bannerlord.Harmony" .../>            ->   <DependedModule Id="CREST" .../>
#     <DependedModule Id="Bannerlord.ButterLib" .../>          ->   removed (folded into CREST)
#     <DependedModule Id="Bannerlord.UIExtenderEx" .../>       ->   removed
#     <DependedModule Id="MCMv5" .../>                          ->   removed
#     (collapses the 4 BUTR module deps into a single CREST dep; safe because
#     CREST loads all four sub-modules in one bundle.)
#
# What this script does NOT change:
#
#   * .cs source files' using directives -- CREST keeps the upstream namespaces
#     (`using Bannerlord.Harmony;`, `using Bannerlord.UIExtenderEx;`, etc. all
#     resolve correctly against Crest.X.dll because Crest.X.dll's types are
#     declared under those same Bannerlord.* / MCM.* namespaces post-Phase-H).
#   * Type names, method signatures, attribute strings -- same reasoning.
#   * Harmony ID strings -- not assembly-qualified.
#
# What this script REPORTS but doesn't auto-rewrite:
#
#   * .cs source files that contain assembly-qualified type strings of the form
#     "Bannerlord.X.SomeType, Bannerlord.X" -- these are typically Type.GetType
#     / Assembly.Load lookups where the assembly hint matters. Auto-rewriting
#     them is risky (false positives in arbitrary string content), so the script
#     surfaces a list and leaves the edit to the user.
#
# Usage:
#   .\Migrate-ModSourceToCrest.ps1 -Path C:\src\BloodMod1313
#   .\Migrate-ModSourceToCrest.ps1 -Path .\src -DryRun
#   .\Migrate-ModSourceToCrest.ps1 -Path .\src -IncludeSubModuleXml -Force -NoBackup
#
# Flags:
#   -DryRun                Show migration plan, write nothing.
#   -Force                 Skip the y/N prompt.
#   -NoBackup              Skip writing *.bak files (CI / scripted use).
#   -IncludeSubModuleXml   Also rewrite SubModule.xml DependedModule entries.

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$Path,
    [switch]$DryRun,
    [switch]$Force,
    [switch]$NoBackup,
    [switch]$IncludeSubModuleXml
)

$ErrorActionPreference = 'Stop'

# Mapping table: upstream package/assembly name -> CREST equivalent.
# Used for both csproj PackageReference / Reference and HintPath rewrites.
$nameMap = [ordered]@{
    'Bannerlord.Harmony'       = 'Crest.Harmony'
    'Bannerlord.ButterLib'     = 'Crest.ButterLib'
    'Bannerlord.UIExtenderEx'  = 'Crest.UIExtenderEx'
    'MCMv5'                    = 'Crest.MCM'
}

# DependedModule rewrite policy. Keys are upstream module IDs; the value is
# either the new ID to substitute, or $null which means "remove this entry"
# (because the dep is folded into the CREST bundle).
$dependedModuleMap = [ordered]@{
    'Bannerlord.Harmony'       = 'CREST'
    'Bannerlord.ButterLib'     = $null
    'Bannerlord.UIExtenderEx'  = $null
    'MCMv5'                    = $null
}

if (-not (Test-Path $Path)) {
    Write-Error "Path not found: $Path"
    exit 1
}

$root = (Get-Item $Path).FullName

# Windows PowerShell 5.1 (the default install on Win10/Win11) targets .NET
# Framework 4.x and therefore lacks [System.IO.Path]::GetRelativePath, which
# was added in .NET Core 2.0. Provide a tiny shim so this script runs on the
# default shell without requiring PowerShell 7+.
function Get-CrestRelativePath {
    param([string]$BasePath, [string]$TargetPath)
    $b = $BasePath.TrimEnd('\','/')
    if ($TargetPath.StartsWith($b, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $TargetPath.Substring($b.Length).TrimStart('\','/')
    }
    return $TargetPath
}

# --- Discover candidate files ---
$csprojs = Get-ChildItem -Recurse -File -Path $root -Filter '*.csproj' -ErrorAction SilentlyContinue
$xmlFiles = if ($IncludeSubModuleXml) {
    Get-ChildItem -Recurse -File -Path $root -Filter 'SubModule.xml' -ErrorAction SilentlyContinue
} else {
    @()
}
$csFiles = Get-ChildItem -Recurse -File -Path $root -Filter '*.cs' -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "==> Scanning source tree at $root" -ForegroundColor Cyan
Write-Host ("    {0} csproj, {1} SubModule.xml{2}, {3} .cs" -f $csprojs.Count, $xmlFiles.Count, $(if (-not $IncludeSubModuleXml) { ' (skipped, pass -IncludeSubModuleXml to rewrite)' } else { '' }), $csFiles.Count)

# --- Build csproj plan ---
$csprojPlan = @()
foreach ($p in $csprojs) {
    $text = Get-Content $p.FullName -Raw
    $hits = @()

    foreach ($oldName in $nameMap.Keys) {
        $newName = $nameMap[$oldName]

        # PackageReference Include="Bannerlord.X" - allow whitespace and quote variants
        $patternPkg = '<PackageReference\s+Include\s*=\s*"' + [regex]::Escape($oldName) + '"'
        if ([regex]::IsMatch($text, $patternPkg)) {
            $hits += [pscustomobject]@{ Kind='PackageReference'; OldName=$oldName; NewName=$newName }
        }

        # Reference Include="Bannerlord.X..." -- including the comma-version variant
        $patternRef = '<Reference\s+Include\s*=\s*"' + [regex]::Escape($oldName) + '(,|")'
        if ([regex]::IsMatch($text, $patternRef)) {
            $hits += [pscustomobject]@{ Kind='Reference'; OldName=$oldName; NewName=$newName }
        }

        # HintPath ending in Bannerlord.X.dll
        $patternHp = '<HintPath>[^<]*' + [regex]::Escape($oldName) + '\.dll</HintPath>'
        if ([regex]::IsMatch($text, $patternHp)) {
            $hits += [pscustomobject]@{ Kind='HintPath'; OldName=$oldName; NewName=$newName }
        }
    }

    if ($hits.Count -gt 0) {
        $csprojPlan += [pscustomobject]@{
            File = $p
            Hits = $hits
        }
    }
}

# --- Build SubModule.xml plan ---
$xmlPlan = @()
foreach ($x in $xmlFiles) {
    $text = Get-Content $x.FullName -Raw
    $hits = @()
    foreach ($oldId in $dependedModuleMap.Keys) {
        $newId = $dependedModuleMap[$oldId]
        $pattern = '<DependedModule\s+Id\s*=\s*"' + [regex]::Escape($oldId) + '"[^/]*/>'
        if ([regex]::IsMatch($text, $pattern)) {
            $hits += [pscustomobject]@{
                OldId = $oldId
                NewId = $newId
                Action = $(if ($null -eq $newId) { 'remove' } else { 'rename' })
            }
        }
    }
    if ($hits.Count -gt 0) {
        $xmlPlan += [pscustomobject]@{
            File = $x
            Hits = $hits
        }
    }
}

# --- Scan .cs files for assembly-qualified type-string concerns (report-only) ---
$csConcerns = @()
foreach ($c in $csFiles) {
    $text = Get-Content $c.FullName -Raw
    foreach ($oldName in $nameMap.Keys) {
        # Pattern: "<typeFQN>, Bannerlord.X" or "<typeFQN>, Bannerlord.X, Version="
        $pattern = '"\s*[A-Za-z_][\w\.]*\s*,\s*' + [regex]::Escape($oldName) + '\s*[,"]'
        if ([regex]::IsMatch($text, $pattern)) {
            $csConcerns += [pscustomobject]@{ File = $c; OldName = $oldName }
        }
        # Pattern: Assembly.Load("Bannerlord.X")
        $pattern2 = 'Assembly\.Load\s*\(\s*"' + [regex]::Escape($oldName) + '"'
        if ([regex]::IsMatch($text, $pattern2)) {
            $csConcerns += [pscustomobject]@{ File = $c; OldName = $oldName }
        }
    }
}

# --- Print plan ---
if ($csprojPlan.Count -eq 0 -and $xmlPlan.Count -eq 0 -and $csConcerns.Count -eq 0) {
    Write-Host ""
    Write-Host "==> No upstream-BUTR references found. Nothing to migrate." -ForegroundColor Green
    exit 0
}

if ($csprojPlan.Count -gt 0) {
    Write-Host ""
    Write-Host "==> csproj rewrites" -ForegroundColor Cyan
    foreach ($p in $csprojPlan) {
        $rel = Get-CrestRelativePath -BasePath $root -TargetPath $p.File.FullName
        Write-Host ("  {0}" -f $rel) -ForegroundColor White
        $p.Hits | Group-Object Kind, OldName, NewName | ForEach-Object {
            $g = $_.Group[0]
            Write-Host ("    {0,-18}  {1,-30} =>  {2}" -f $g.Kind, $g.OldName, $g.NewName)
        }
    }
}

if ($xmlPlan.Count -gt 0) {
    Write-Host ""
    Write-Host "==> SubModule.xml rewrites" -ForegroundColor Cyan
    foreach ($p in $xmlPlan) {
        $rel = Get-CrestRelativePath -BasePath $root -TargetPath $p.File.FullName
        Write-Host ("  {0}" -f $rel) -ForegroundColor White
        foreach ($h in $p.Hits) {
            if ($h.Action -eq 'remove') {
                Write-Host ("    DependedModule       {0,-30} =>  (removed; folded into CREST)" -f $h.OldId)
            } else {
                Write-Host ("    DependedModule       {0,-30} =>  {1}" -f $h.OldId, $h.NewId)
            }
        }
    }
}

if ($csConcerns.Count -gt 0) {
    Write-Host ""
    Write-Host "==> .cs files with assembly-qualified type strings (REPORT ONLY)" -ForegroundColor Yellow
    Write-Host "    These contain string references like \"Type, Bannerlord.X\" or" -ForegroundColor DarkGray
    Write-Host "    Assembly.Load(\"Bannerlord.X\"). Auto-rewriting strings is unsafe;" -ForegroundColor DarkGray
    Write-Host "    review and update by hand if the runtime needs the new assembly name." -ForegroundColor DarkGray
    foreach ($g in $csConcerns | Group-Object { $_.File.FullName }) {
        $rel = Get-CrestRelativePath -BasePath $root -TargetPath $g.Name
        $names = ($g.Group | Select-Object -ExpandProperty OldName -Unique) -join ', '
        Write-Host ("  {0}    [{1}]" -f $rel, $names)
    }
}

if ($DryRun) {
    Write-Host ""
    Write-Host "==> Dry run -- no files written." -ForegroundColor Yellow
    exit 0
}

# --- Confirm ---
if (-not $Force) {
    Write-Host ""
    $resp = Read-Host "Apply migration? Originals will be backed up to *.bak unless -NoBackup is set [y/N]"
    if ($resp -notmatch '^(y|yes)$') {
        Write-Host "Aborted." -ForegroundColor Yellow
        exit 0
    }
}

# --- Helpers ---
function Backup-IfNeeded {
    param([string]$FilePath)
    if ($NoBackup) { return }
    $bak = $FilePath + '.bak'
    if (-not (Test-Path $bak)) { Copy-Item $FilePath $bak -Force }
}

function Rewrite-CsprojText {
    param([string]$Text, [hashtable]$Map)
    $out = $Text
    foreach ($oldName in $Map.Keys) {
        $newName = $Map[$oldName]
        # PackageReference Include="OldName"... -> Include="NewName"
        $out = [regex]::Replace($out,
            '(<PackageReference\s+Include\s*=\s*")' + [regex]::Escape($oldName) + '(")',
            { param($m) $m.Groups[1].Value + $newName + $m.Groups[2].Value })
        # Reference Include="OldName,..." or Include="OldName" -> with NewName
        $out = [regex]::Replace($out,
            '(<Reference\s+Include\s*=\s*")' + [regex]::Escape($oldName) + '(?=,|")',
            { param($m) $m.Groups[1].Value + $newName })
        # HintPath ...OldName.dll -> ...NewName.dll
        $out = [regex]::Replace($out,
            '(<HintPath>[^<]*?)' + [regex]::Escape($oldName) + '(\.dll</HintPath>)',
            { param($m) $m.Groups[1].Value + $newName + $m.Groups[2].Value })
    }
    return $out
}

function Rewrite-SubModuleXmlText {
    param([string]$Text, [hashtable]$Map)
    $out = $Text
    foreach ($oldId in $Map.Keys) {
        $newId = $Map[$oldId]
        $pattern = '\s*<DependedModule\s+Id\s*=\s*"' + [regex]::Escape($oldId) + '"[^/]*/>'
        if ($null -eq $newId) {
            # Remove the entire DependedModule element (and its leading whitespace)
            $out = [regex]::Replace($out, $pattern, '')
        } else {
            $out = [regex]::Replace($out,
                '(<DependedModule\s+Id\s*=\s*")' + [regex]::Escape($oldId) + '(")',
                { param($m) $m.Groups[1].Value + $newId + $m.Groups[2].Value })
        }
    }
    return $out
}

# --- Apply ---
Write-Host ""
Write-Host "==> Applying" -ForegroundColor Cyan
$csprojWritten = 0
foreach ($p in $csprojPlan) {
    $text = Get-Content $p.File.FullName -Raw
    $newText = Rewrite-CsprojText -Text $text -Map $nameMap
    if ($newText -ne $text) {
        Backup-IfNeeded -FilePath $p.File.FullName
        Set-Content -Path $p.File.FullName -Value $newText -NoNewline
        $rel = Get-CrestRelativePath -BasePath $root -TargetPath $p.File.FullName
        Write-Host ("  rewrote     {0}" -f $rel) -ForegroundColor Green
        $csprojWritten++
    }
}

$xmlWritten = 0
foreach ($p in $xmlPlan) {
    $text = Get-Content $p.File.FullName -Raw
    $newText = Rewrite-SubModuleXmlText -Text $text -Map $dependedModuleMap
    if ($newText -ne $text) {
        Backup-IfNeeded -FilePath $p.File.FullName
        Set-Content -Path $p.File.FullName -Value $newText -NoNewline
        $rel = Get-CrestRelativePath -BasePath $root -TargetPath $p.File.FullName
        Write-Host ("  rewrote     {0}" -f $rel) -ForegroundColor Green
        $xmlWritten++
    }
}

Write-Host ""
Write-Host ("==> Migrated {0} csproj, {1} SubModule.xml. Run 'dotnet restore' before rebuilding." -f $csprojWritten, $xmlWritten) -ForegroundColor Green
if ($csConcerns.Count -gt 0) {
    Write-Host ("    {0} .cs file(s) flagged with assembly-qualified type strings -- review manually (see report above)." -f ($csConcerns | Group-Object { $_.File.FullName }).Count) -ForegroundColor Yellow
}
