# Crest-Compat

Auto-fix companion to `Crest-Doctor.ps1`. The doctor's "Compatibility risks" section flags two classes of concern; this tool resolves them where it's safe to do so.

## What it fixes

### 1. Bundled-Harmony / Cecil / MonoMod collisions (SAFE, reversible)

A lot of older community mods ship their own copy of `0Harmony.dll` (and sometimes Mono.Cecil / MonoMod) inside `Modules\<ModName>\bin\Win64_Shipping_Client\`. CREST always ships these at the canonical location, and the CLR loads only one copy per AppDomain regardless of how many times the file appears on disk. The mod's bundled copy is at best dead weight (~2-4 MB per mod) and at worst a source of subtle patch-conflict bugs when its version differs from the one CREST uses.

**Action:** rename the duplicate to `<name>.crest-disabled`. Reversible by hand or via `-Restore`.

### 2. TaleWorlds DLL overrides (RISKY by default; only fixed when hash matches)

A module that ships any `TaleWorlds.*.dll` in its `bin\` is overriding the engine. Two cases:

- **Deliberate override.** Mods like RBM rewrite combat by patching the DLL's IL and shipping the modified result. The DLL contains the mod's actual code. Removing it breaks the mod.
- **Accidental redistribution.** Some mods accidentally include a pristine copy of the engine DLL with no changes. This is harmless if the version matches the user's install — and outright dangerous if it doesn't (causes silent type-identity mismatches across the load).

The tool hash-compares every override against every canonical copy: the game's `bin\Win64_Shipping_Client\`, plus each first-party module's `bin\` (since some `TaleWorlds.MountAndBlade.*` assemblies ship inside `Modules\CustomBattle\`, `Modules\Multiplayer\`, etc., not the game bin).

**Action:** if the hash matches any canonical copy, the override is a redundant identical-content redistribution — rename to `*.crest-disabled`. If it differs from every canonical, it's reported but not touched.

## Usage

```powershell
# Dry-run: scan + report; write nothing
.\Crest-Compat.ps1

# Apply safe fixes (rename duplicates to *.crest-disabled)
.\Crest-Compat.ps1 -Fix

# Limit to one module
.\Crest-Compat.ps1 -Fix -Mod RBM

# Revert: rename every *.crest-disabled in Modules\X\bin\ back to its original
.\Crest-Compat.ps1 -Restore

# Override game root
.\Crest-Compat.ps1 -GameRoot 'D:\Games\Bannerlord'
```

## What "SAFE" vs "RISKY" means in the output

```
---- RBM ----
  [SAFE]   0Harmony.dll  --  duplicate of CREST-shipped DLL (520 KB)
  [SAFE]   0Harmony.pdb  --  duplicate of CREST-shipped DLL (1640 KB)
  [SAFE]   0Harmony.xml  --  duplicate of CREST-shipped DLL (250 KB)
  [RISKY]  TaleWorlds.MountAndBlade.CustomBattle.dll  --  differs from all canonical copies (CustomBattle) -- mod likely depends on this override
  [RISKY]  TaleWorlds.MountAndBlade.Multiplayer.dll  --  differs from all canonical copies (CustomBattle, Multiplayer) -- mod likely depends on this override
```

- **`[SAFE]`** items get auto-renamed to `*.crest-disabled` when you pass `-Fix`. Always reversible via `-Restore`.
- **`[RISKY]`** items are reported only. They're flagged so you know the override exists; you decide whether to leave it (mod needs it) or remove it manually (e.g., a mod ships an outdated pristine copy and you want the engine version to win).

## Restoring after a fix

Every renamed file gets the literal suffix `.crest-disabled`:

```
Modules\RBM\bin\Win64_Shipping_Client\0Harmony.dll
  -> Modules\RBM\bin\Win64_Shipping_Client\0Harmony.dll.crest-disabled
```

`Crest-Compat.ps1 -Restore` walks every module's `bin\` folder, finds all `*.crest-disabled` files, and renames them back. If the original filename has reappeared (e.g., the mod was reinstalled in the meantime), the restore for that file is skipped and reported.

## What it does NOT do

- **Doesn't touch first-party Bannerlord modules.** `Native`, `SandBox`, `SandBoxCore`, `StoryMode`, `CustomBattle`, `Multiplayer`, `BirthAndDeath`, `NavalDLC`, and `FastMode` legitimately ship `TaleWorlds.*.dll` files — those are the canonical engine code, not overrides.
- **Doesn't touch CREST's own bin.** The `Modules\CREST\bin\` folder is excluded from the scan.
- **Doesn't repair version mismatches.** If a mod ships a `TaleWorlds.X.dll` whose hash doesn't match any canonical copy, the tool reports it but won't pick a "winner."
- **Doesn't handle non-Harmony / non-TaleWorlds redistributions.** A mod shipping its own `Newtonsoft.Json.dll` or `BetterExceptionWindow.dll` is out of scope here. Most of those are harmless because the assembly versions match what CREST ships; the rest are an exercise for `Crest-Doctor`'s broader compatibility audit.
