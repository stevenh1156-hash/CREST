# Crest-Doctor.ps1 -- Phase R (modder-facing diagnostic tool)
#
# Single-entry diagnostic for Bannerlord mod authors using CREST. Runs four
# kinds of checks:
#
#   1. -Health     CREST install self-test: BLSE injected, CREST DLLs present,
#                  stubs intact, crest.json valid, version sanity.
#   2. -LoadOrder  Parses every Modules\X\SubModule.xml, builds the dependency
#                  graph, reports missing deps, cycles, and load-order violations
#                  vs LauncherData.
#   3. -Mod <name> Static analysis of a target mod's DLLs: reports TypeRefs to
#                  the BUTR stack, flags any that aren't covered by CREST's
#                  current public API surface.
#   4. -Logs       Reads ModLogs + runtime.log + BLSE_lasterror.log + game
#                  crash logs, presents a unified timeline grouped by source
#                  mod and severity.
#
# Run with no args to do all of the above as a comprehensive "doctor" report.
# Run with -ReportPath <file> to save the result as a Markdown bug-report
# attachment.
#
# Prereqs: Mono.Cecil (auto-detected from the CREST install).

[CmdletBinding()]
param(
    [switch]$Health,
    [switch]$LoadOrder,
    [string]$Mod,
    [switch]$Logs,
    [switch]$Compat,
    [switch]$IncludePatchSnapshot,
    [string]$GameRoot = 'C:\Program Files (x86)\Steam\steamapps\common\Mount & Blade II Bannerlord',
    [string]$DocumentsRoot,
    [string]$ReportPath,
    [string]$CecilPath
)

$ErrorActionPreference = 'Continue'

# Default DocumentsRoot: $HOME\Documents\Mount and Blade II Bannerlord
if (-not $DocumentsRoot) {
    $DocumentsRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Mount and Blade II Bannerlord'
}

# If no specific check requested, run all of them.
$runAll = -not ($Health -or $LoadOrder -or $Mod -or $Logs -or $Compat)
if ($runAll) {
    $Health = $true
    $LoadOrder = $true
    $Logs = $true
    $Compat = $true
}

# Locate Mono.Cecil
if (-not $CecilPath) {
    $candidates = @(
        (Join-Path $GameRoot 'Modules\CREST\bin\Win64_Shipping_Client\Mono.Cecil.dll'),
        'C:\dev\bannerlord\Bannerlord.Harmony\src\Crest.Harmony\bin\Release\net472\Mono.Cecil.dll'
    )
    $CecilPath = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
$cecilLoaded = $false
if ($CecilPath -and (Test-Path $CecilPath)) {
    Add-Type -Path $CecilPath
    $cecilLoaded = $true
}

# Output buffer (flushed to console + optional report file at the end)
$out = New-Object System.Collections.Generic.List[string]
function W { param([string]$s, [string]$color = 'Gray')
    Write-Host $s -ForegroundColor $color
    $out.Add($s) | Out-Null
}
function H1 { param([string]$s) W ""; W ("# " + $s) Cyan; W ("=" * 72) DarkGray }
function H2 { param([string]$s) W ""; W ("## " + $s) White }
function OK { param([string]$s) W ("  [OK]    " + $s) Green }
function WARN { param([string]$s) W ("  [WARN]  " + $s) Yellow }
function ERR { param([string]$s) W ("  [ERR]   " + $s) Red }
function INFO { param([string]$s) W ("  [INFO]  " + $s) Gray }

W ""
W "Crest-Doctor"
W ("Game root: " + $GameRoot)
W ("Docs root: " + $DocumentsRoot)
W ("Generated: " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))

# ============================================================
# Health check
# ============================================================
if ($Health) {
    H1 "Health check"

    H2 "CREST module"
    $crestRoot = Join-Path $GameRoot 'Modules\CREST'
    if (-not (Test-Path $crestRoot)) {
        ERR "Modules\CREST not found at $crestRoot"
    } else {
        $bin = Join-Path $crestRoot 'bin\Win64_Shipping_Client'
        # Core DLLs that should always be present, irrespective of game version.
        $required = @(
            'Crest.Harmony.dll', 'Crest.ButterLib.dll', 'Crest.ButterLib.Implementation.dll',
            'Crest.UIExtenderEx.dll', 'Crest.MCM.dll',
            'Bannerlord.Harmony.dll', 'Bannerlord.ButterLib.dll',
            'Bannerlord.UIExtenderEx.dll', 'MCMv5.dll',
            '0Harmony.dll', 'Mono.Cecil.dll'
        )
        $missing = 0
        foreach ($n in $required) {
            $p = Join-Path $bin $n
            if (Test-Path $p) {
                OK $n
            } else {
                ERR ("missing " + $n)
                $missing++
            }
        }
        # Game-version-dependent: CREST.v<X.Y.Z>.dll. Match by glob so a v1.4.2
        # build doesn't trip a check pinned to v1.4.1, and report whatever's
        # actually deployed.
        $crestUiCandidates = Get-ChildItem -Path $bin -Filter 'CREST.v*.dll' -File -ErrorAction SilentlyContinue
        if ($crestUiCandidates -and $crestUiCandidates.Count -gt 0) {
            foreach ($c in $crestUiCandidates) { OK $c.Name }
        } else {
            ERR "missing CREST.v*.dll (the game-version-suffixed MCM UI DLL)"
            $missing++
        }
        if ($missing -eq 0) {
            INFO ("all " + ($required.Count + 1) + " core DLLs present (CREST UI: " + ($crestUiCandidates | ForEach-Object { $_.Name } | Sort-Object) + ")")
        }
    }

    H2 "BLSE injection"
    $blseExeInGameBin = Join-Path $GameRoot 'bin\Win64_Shipping_Client\Bannerlord.BLSE.dll'
    if (Test-Path $blseExeInGameBin) {
        OK "Bannerlord.BLSE.dll deployed in game bin"
    } else {
        ERR "Bannerlord.BLSE.dll missing from $blseExeInGameBin"
    }
    $launcherCfg = Join-Path $GameRoot 'bin\Win64_Shipping_Client\TaleWorlds.MountAndBlade.Launcher.exe.config'
    if (Test-Path $launcherCfg) {
        $cfgContent = Get-Content $launcherCfg -Raw
        if ($cfgContent -match 'BLSEAppDomainManager') {
            OK "Launcher .config has AppDomainManager redirect"
        } else {
            WARN "Launcher .config exists but lacks AppDomainManager redirect (BLSE won't auto-inject from Steam)"
        }
    } else {
        ERR "TaleWorlds.MountAndBlade.Launcher.exe.config missing"
    }
    $bannerlordCfg = Join-Path $GameRoot 'bin\Win64_Shipping_Client\Bannerlord.exe.config'
    if (Test-Path $bannerlordCfg) {
        OK "Bannerlord.exe.config present (covers direct-game launch path)"
    } else {
        WARN "Bannerlord.exe.config missing -- launching the game directly without going through the launcher won't activate BLSE"
    }

    H2 "Stub modules"
    # Phase N: stubs should be (a) present, (b) DefaultModule=true, (c) auto-enabled
    # in LauncherData.xml. Crest.Harmony's runtime self-heal recreates a missing
    # stub on next launch; CREST's BLSE patch hides them from the launcher UI.
    $stubIds = @('Bannerlord.Harmony','Bannerlord.ButterLib','Bannerlord.UIExtenderEx','Bannerlord.MBOptionScreen')
    $launcherData = Join-Path $DocumentsRoot 'Configs\LauncherData.xml'
    $launcherSelections = @{}
    if (Test-Path $launcherData) {
        try {
            [xml]$ld = Get-Content $launcherData -Raw
            foreach ($n in $ld.SelectNodes('//UserModData')) {
                $id = $n.Id
                if ($id -is [System.Xml.XmlElement]) { $id = $id.value }
                if (-not $id) { $id = $n.SelectSingleNode('Id') | ForEach-Object { $_.InnerText } }
                $sel = $n.SelectSingleNode('IsSelected') | ForEach-Object { $_.InnerText }
                if ($id) { $launcherSelections[$id] = ($sel -eq 'true') }
            }
        } catch { }
    }
    foreach ($s in $stubIds) {
        $sm = Join-Path $GameRoot ('Modules\' + $s + '\SubModule.xml')
        if (-not (Test-Path $sm)) {
            ERR ($s + " stub missing -- runtime self-heal will recreate on next launch")
            continue
        }
        $size = (Get-Item $sm).Length
        $xmlText = Get-Content $sm -Raw
        $isDefault = $xmlText -match '<DefaultModule\s+value="true"'
        $sel = $launcherSelections[$s]
        $bits = @()
        $bits += ($size.ToString() + 'B')
        $bits += $(if ($isDefault) { 'DefaultModule=true' } else { 'DefaultModule=false (will not auto-enable on first launch)' })
        $bits += $(switch ($sel) {
            $true  { 'enabled in LauncherData' }
            $false { 'DISABLED in LauncherData (self-heal will re-enable on next launch)' }
            default { 'not yet in LauncherData (will appear after first launch)' }
        })
        $msg = $s + " stub: " + ($bits -join '; ')
        if (-not $isDefault -or $sel -eq $false) {
            WARN $msg
        } else {
            OK $msg
        }
    }

    H2 "crest.json"
    $cj = Join-Path $crestRoot 'crest.json'
    if (Test-Path $cj) {
        $cjContent = Get-Content $cj -Raw
        if ($cjContent -match '"enabled"') {
            OK "crest.json present + parses"
            # Extract enabled flags
            $matches = [regex]::Matches($cjContent, '"([A-Za-z_][A-Za-z0-9_]*)"\s*:\s*(true|false)')
            $flags = @{}
            foreach ($m in $matches) {
                if ($m.Groups[1].Value -ne '_comment') {
                    $flags[$m.Groups[1].Value] = $m.Groups[2].Value
                }
            }
            foreach ($k in ($flags.Keys | Sort-Object)) {
                INFO ("  " + $k + " = " + $flags[$k])
            }
        } else {
            WARN "crest.json is malformed (missing 'enabled' block)"
        }
    } else {
        WARN "crest.json missing (will be auto-created on first launch with all flags = true)"
    }

    H2 "Game version sanity"
    if ($cecilLoaded) {
        $tw = Join-Path $GameRoot 'bin\Win64_Shipping_Client\TaleWorlds.MountAndBlade.dll'
        if (Test-Path $tw) {
            $asm = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($tw)
            try {
                $v = $asm.Name.Version
                INFO ("TaleWorlds.MountAndBlade.dll v" + $v)
                # CREST.v<X.Y.Z>.dll names encode the game version they were
                # built against. Pull the version out of the deployed file
                # rather than hardcoding -- so a v1.4.2 rebuild detects
                # automatically without a doctor edit.
                $crestUi = Get-ChildItem -Path $bin -Filter 'CREST.v*.dll' -File -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($crestUi) {
                    if ($crestUi.Name -match '^CREST\.(v[\d\.]+)\.dll$') {
                        $crestBuiltFor = $matches[1]
                        INFO ("CREST built for game " + $crestBuiltFor)
                        # Cross-check: if the deployed game's TW version major.minor
                        # doesn't match the CREST UI build target, that's
                        # almost always why MCM UI / mods misbehave.
                        $twMajMin = "v$($v.Major).$($v.Minor)"
                        $crestMajMin = ($crestBuiltFor -replace '^v','' -split '\.' | Select-Object -First 2) -join '.'
                        $crestMajMin = "v$crestMajMin"
                        if ($twMajMin -ne $crestMajMin) {
                            $msg = 'CREST UI built for {0} but game runs {1} -- rebuild Crest.MCM.UI with -p:OverrideGameVersion={1} to silence this warning.' -f $crestBuiltFor, $twMajMin
                            WARN $msg
                        }
                    }
                }
            } finally { $asm.Dispose() }
        }
    }
}

# ============================================================
# Load-order analysis
# ============================================================
if ($LoadOrder) {
    H1 "Load-order analysis"

    $modulesDir = Join-Path $GameRoot 'Modules'
    if (-not (Test-Path $modulesDir)) {
        ERR ("Modules\ not found at " + $modulesDir)
    } else {
        # Parse all SubModule.xml
        $modules = @{}
        foreach ($d in Get-ChildItem $modulesDir -Directory) {
            $sm = Join-Path $d.FullName 'SubModule.xml'
            if (-not (Test-Path $sm)) { continue }
            try {
                [xml]$x = Get-Content $sm
                $id = $x.Module.Id.value
                if (-not $id) { continue }
                $deps = @()
                if ($x.Module.DependedModules -and $x.Module.DependedModules.DependedModule) {
                    foreach ($dep in $x.Module.DependedModules.DependedModule) {
                        if ($dep.Id) { $deps += $dep.Id }
                    }
                }
                $modules[$id] = [pscustomobject]@{
                    Folder = $d.Name
                    Id = $id
                    Version = $x.Module.Version.value
                    Deps = $deps
                }
            } catch {
                WARN ("could not parse " + $sm)
            }
        }
        INFO ("found " + $modules.Count + " modules with valid SubModule.xml")

        H2 "Missing dependencies"
        $any = $false
        foreach ($id in ($modules.Keys | Sort-Object)) {
            $m = $modules[$id]
            foreach ($dep in $m.Deps) {
                if (-not $modules.ContainsKey($dep)) {
                    ERR ($id + " depends on " + $dep + " -- not installed")
                    $any = $true
                }
            }
        }
        if (-not $any) { OK "all <DependedModule> Ids resolve to installed modules" }

        H2 "Dependency cycles"
        # Tarjan-style cycle detect. Quick + dirty for typical Bannerlord mod sets.
        $seen = @{}
        $stack = @{}
        $cycleFound = $false
        function Walk($id, $path) {
            if ($script:stack.ContainsKey($id)) {
                $cyclePath = ($path + $id) -join ' -> '
                ERR ("cycle: " + $cyclePath)
                $script:cycleFound = $true
                return
            }
            if ($script:seen.ContainsKey($id)) { return }
            $script:stack[$id] = $true
            if ($script:modules.ContainsKey($id)) {
                foreach ($d in $script:modules[$id].Deps) {
                    Walk $d ($path + $id)
                }
            }
            $script:stack.Remove($id) | Out-Null
            $script:seen[$id] = $true
        }
        $script:seen = $seen
        $script:stack = $stack
        $script:modules = $modules
        $script:cycleFound = $cycleFound
        foreach ($id in $modules.Keys) { Walk $id @() }
        if (-not $script:cycleFound) { OK "no dependency cycles" }

        H2 "Launcher load-order vs declared dependencies"
        $launcherData = Join-Path $DocumentsRoot 'Configs\LauncherData.xml'
        if (Test-Path $launcherData) {
            [xml]$ld = Get-Content $launcherData
            $userData = $ld.UserData.SingleplayerData.ModDatas.UserModData
            if ($userData) {
                # NB: do NOT use $mod as the loop variable -- PowerShell variable
                # names are case-insensitive, so $mod aliases the script-level
                # $Mod parameter and clobbers it. Using $userMod here.
                $orderById = @{}
                $i = 0
                foreach ($userMod in $userData) {
                    if ($userMod.IsSelected -ne 'true') { continue }
                    $i++
                    $orderById[$userMod.Id] = $i
                }
                $violations = 0
                foreach ($id in $orderById.Keys) {
                    if (-not $modules.ContainsKey($id)) { continue }
                    foreach ($dep in $modules[$id].Deps) {
                        if (-not $orderById.ContainsKey($dep)) { continue }
                        if ($orderById[$dep] -gt $orderById[$id]) {
                            ERR ($id + " (pos " + $orderById[$id] + ") depends on " + $dep + " (pos " + $orderById[$dep] + ") -- dep loads AFTER, will fail")
                            $violations++
                        }
                    }
                }
                if ($violations -eq 0) { OK "every dep loads before its consumer in LauncherData" }
            }
        } else {
            WARN ("LauncherData.xml not found at " + $launcherData + " -- skip order validation")
        }
    }
}

# ============================================================
# Mod static analysis
# ============================================================
if ($Mod) {
    H1 "Mod static analysis: $Mod"

    $modPath = Join-Path $GameRoot ('Modules\' + $Mod)
    if (-not (Test-Path $modPath)) {
        ERR ("module not found: " + $modPath)
    } elseif (-not $cecilLoaded) {
        ERR "Mono.Cecil not loaded -- can't read DLLs"
    } else {
        $modDlls = Get-ChildItem -Recurse -File -Path $modPath -Filter '*.dll' -ErrorAction SilentlyContinue
        INFO ("found " + $modDlls.Count + " DLLs")

        # Build CREST public-type set
        $crestBin = Join-Path $GameRoot 'Modules\CREST\bin\Win64_Shipping_Client'
        $crestPublicTypes = @{}
        # Phase Y.16: MCM.UI is now stable Crest.MCM.UI.dll (was CREST.v<gameversion>.dll).
        # Keep both names for back-compat with anyone running an older deployed bundle.
        foreach ($crestDll in @('Crest.Harmony.dll','Crest.ButterLib.dll','Crest.ButterLib.Implementation.dll','Crest.UIExtenderEx.dll','Crest.MCM.dll','Crest.MCM.UI.dll','CREST.v1.4.1.dll')) {
            $p = Join-Path $crestBin $crestDll
            if (-not (Test-Path $p)) { continue }
            $a = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($p)
            try {
                foreach ($t in $a.MainModule.Types) {
                    if (-not $t.IsPublic) { continue }
                    if ($t.IsNested) { continue }
                    $fqn = if ($t.Namespace) { $t.Namespace + '.' + $t.Name } else { $t.Name }
                    $crestPublicTypes[$fqn] = $crestDll
                }
            } finally { $a.Dispose() }
        }
        INFO ("CREST exposes " + $crestPublicTypes.Count + " public types across forks")

        H2 "BUTR-stack type references"
        $atRiskFqns = @()
        foreach ($dll in $modDlls) {
            try {
                $a = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($dll.FullName)
                try {
                    $hits = @{}
                    foreach ($tref in $a.MainModule.GetTypeReferences()) {
                        $fqn = if ($tref.Namespace) { $tref.Namespace + '.' + $tref.Name } else { $tref.Name }
                        # Only flag references that look like BUTR-stack types
                        if ($fqn -match '^(Bannerlord\.Harmony|Bannerlord\.ButterLib|Bannerlord\.UIExtenderEx|MCM)\.') {
                            $hits[$fqn] = $true
                        }
                    }
                    if ($hits.Count -gt 0) {
                        W ""
                        W ("  " + $dll.Name)
                        foreach ($f in ($hits.Keys | Sort-Object)) {
                            if ($crestPublicTypes.ContainsKey($f)) {
                                OK ("    " + $f + "  (in " + $crestPublicTypes[$f] + ")")
                            } else {
                                WARN ("    " + $f + "  -- NOT IN CREST's public surface (may break)")
                                $atRiskFqns += $f
                            }
                        }
                    }
                } finally { $a.Dispose() }
            } catch {
                WARN ("could not read " + $dll.Name + ": " + $_.Exception.Message)
            }
        }
        H2 "Summary"
        if ($atRiskFqns.Count -eq 0) {
            OK "every BUTR-stack reference resolves to a public type in current CREST"
        } else {
            WARN ($atRiskFqns.Count.ToString() + " at-risk type reference(s) found -- listed above")
        }
    }
}

# ============================================================
# Compatibility risks
# ============================================================
if ($Compat) {
    H1 "Compatibility risks"

    $modulesDir = Join-Path $GameRoot 'Modules'
    if (-not (Test-Path $modulesDir)) {
        ERR ("Modules\ not found at " + $modulesDir)
    } else {
        # ----- 1. Bundled Harmony / Cecil / MonoMod collisions -----
        H2 "Bundled-Harmony collisions"
        # When two modules each ship their own 0Harmony.dll, the CLR loads
        # whichever comes first in load order and ignores the others. The
        # ignored ones are dead weight. Worse, if the versions differ enough
        # that a mod expects API surface only present in its own bundled copy
        # but a different copy actually loaded, patches fail subtly. CREST
        # ships its own Harmony in Modules\CREST\bin\, so any *other* module's
        # bundled Harmony is at best wasteful.
        $harmonyHits = @()
        $cecilHits = @()
        $monoModHits = @()
        foreach ($d in Get-ChildItem $modulesDir -Directory) {
            if ($d.Name -eq 'CREST') { continue }
            $bin = Join-Path $d.FullName 'bin\Win64_Shipping_Client'
            if (-not (Test-Path $bin)) { continue }
            foreach ($name in @('0Harmony.dll')) {
                $p = Join-Path $bin $name
                if (Test-Path $p) {
                    $f = Get-Item $p
                    $harmonyHits += [pscustomobject]@{ Module=$d.Name; Path=$p; Size=$f.Length }
                }
            }
            foreach ($name in @('Mono.Cecil.dll','Mono.Cecil.Mdb.dll','Mono.Cecil.Pdb.dll','Mono.Cecil.Rocks.dll')) {
                $p = Join-Path $bin $name
                if (Test-Path $p) {
                    $f = Get-Item $p
                    $cecilHits += [pscustomobject]@{ Module=$d.Name; Path=$p; Size=$f.Length; Name=$name }
                }
            }
            foreach ($name in @('MonoMod.Core.dll','MonoMod.Utils.dll','MonoMod.Backports.dll','MonoMod.Iced.dll','MonoMod.ILHelpers.dll','MonoMod.RuntimeDetour.dll')) {
                $p = Join-Path $bin $name
                if (Test-Path $p) {
                    $f = Get-Item $p
                    $monoModHits += [pscustomobject]@{ Module=$d.Name; Path=$p; Size=$f.Length; Name=$name }
                }
            }
        }
        if ($harmonyHits.Count -eq 0 -and $cecilHits.Count -eq 0 -and $monoModHits.Count -eq 0) {
            OK "no other module bundles 0Harmony / Mono.Cecil / MonoMod"
        } else {
            foreach ($h in $harmonyHits) {
                $kb = [math]::Round($h.Size / 1KB)
                WARN ($h.Module + " bundles 0Harmony.dll (" + $kb + " KB) -- collides with CREST's; can be safely disabled by Crest-Compat")
            }
            foreach ($h in $cecilHits) {
                $kb = [math]::Round($h.Size / 1KB)
                WARN ($h.Module + " bundles " + $h.Name + " (" + $kb + " KB)")
            }
            foreach ($h in $monoModHits) {
                $kb = [math]::Round($h.Size / 1KB)
                WARN ($h.Module + " bundles " + $h.Name + " (" + $kb + " KB)")
            }
        }

        # ----- 2. TaleWorlds DLL overrides -----
        H2 "TaleWorlds DLL overrides"
        # Modules that ship TaleWorlds.*.dll in their own bin folder are
        # overriding the engine's own assemblies. Some of these are perfectly
        # normal: Bannerlord ships its own gameplay code split across
        # first-party modules (Native, SandBox, CustomBattle, Multiplayer,
        # BirthAndDeath, NavalDLC, FastMode, StoryMode, SandBoxCore) -- each
        # of those has TaleWorlds.*.dll in its own bin\ as the canonical
        # location for its types. We skip those.
        # Anything else shipping TaleWorlds.*.dll IS a community-mod-side
        # override -- sometimes deliberate (RBM rewrites combat by replacing
        # CustomBattle.dll), sometimes accidental (mod authors zip up their
        # bin\ including game DLLs they didn't mean to redistribute).
        $firstPartyModules = @(
            'Native', 'SandBox', 'SandBoxCore', 'StoryMode',
            'CustomBattle', 'Multiplayer', 'BirthAndDeath', 'NavalDLC', 'FastMode'
        )
        # Hash-compare each override against every canonical copy: the game
        # bin, plus each first-party module's bin (some TaleWorlds.MountAndBlade.*
        # assemblies live only in Modules\CustomBattle\, Modules\Multiplayer\,
        # etc., not in the game bin). SAFE = identical to ANY canonical;
        # RISKY = differs from all of them (mod likely depends on the override).
        # Mirrors Crest-Compat.ps1's logic so the doctor's verdict and the
        # compat tool's verdict always agree.
        $tw = @()
        $gameTwBin = Join-Path $GameRoot 'bin\Win64_Shipping_Client'
        foreach ($d in Get-ChildItem $modulesDir -Directory) {
            if ($firstPartyModules -contains $d.Name) { continue }
            $bin = Join-Path $d.FullName 'bin\Win64_Shipping_Client'
            if (-not (Test-Path $bin)) { continue }
            $twDlls = Get-ChildItem $bin -Filter 'TaleWorlds.*.dll' -ErrorAction SilentlyContinue
            foreach ($f in $twDlls) {
                $candidatePaths = @()
                $cand = Join-Path $gameTwBin $f.Name
                if (Test-Path $cand) { $candidatePaths += $cand }
                foreach ($fp in $firstPartyModules) {
                    $cand = Join-Path $modulesDir ($fp + '\bin\Win64_Shipping_Client\' + $f.Name)
                    if (Test-Path $cand) { $candidatePaths += $cand }
                }
                $verdict = 'unknown'
                $matchedOwner = $null
                if ($candidatePaths.Count -gt 0) {
                    try {
                        $modHash = (Get-FileHash $f.FullName -Algorithm SHA256).Hash
                        foreach ($cp in $candidatePaths) {
                            $cHash = (Get-FileHash $cp -Algorithm SHA256).Hash
                            if ($cHash -eq $modHash) {
                                if ($cp -eq (Join-Path $gameTwBin $f.Name)) {
                                    $matchedOwner = 'game bin'
                                } else {
                                    # Path layout: <module>\bin\Win64_Shipping_Client\<dll> -- 3 parents up = module name
                                    $matchedOwner = Split-Path (Split-Path (Split-Path $cp -Parent) -Parent) -Parent | Split-Path -Leaf
                                }
                                break
                            }
                        }
                        $verdict = if ($matchedOwner) { 'matches' } else { 'differs' }
                    } catch {
                        $verdict = 'hash-error'
                    }
                } else {
                    $verdict = 'no-canonical'
                }
                $tw += [pscustomobject]@{
                    Module = $d.Name
                    Name = $f.Name
                    Verdict = $verdict
                    MatchedOwner = $matchedOwner
                    Path = $f.FullName
                }
            }
        }
        if ($tw.Count -eq 0) {
            OK "no community module overrides TaleWorlds.*.dll"
        } else {
            INFO "community modules shipping TaleWorlds.*.dll (engine override pattern):"
            foreach ($o in $tw) {
                $tag = switch ($o.Verdict) {
                    'matches' { "identical to $($o.MatchedOwner) -- safe to remove" }
                    'differs' { "differs from all canonical copies -- mod likely depends on it" }
                    'no-canonical' { "no canonical copy on disk -- unusual" }
                    'hash-error' { "hash compare failed" }
                    default { $o.Verdict }
                }
                WARN ($o.Module + " ships " + $o.Name + " (" + $tag + ")")
            }
            INFO "  Run Crest-Compat -Fix to auto-remove identical-content overrides; differing ones require manual review."
        }
    }
}

# ============================================================
# Logs aggregator
# ============================================================
if ($Logs) {
    H1 "Logs aggregator"

    $entries = New-Object System.Collections.Generic.List[object]

    # ModLogs (latest)
    $modLogsDir = Join-Path $DocumentsRoot 'Configs\ModLogs'
    if (Test-Path $modLogsDir) {
        $latest = Get-ChildItem $modLogsDir -Filter 'default*.log' -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($latest) {
            INFO ("reading " + $latest.Name)
            foreach ($line in (Get-Content $latest.FullName)) {
                # Lines look like: [2026-05-05T22:42:43.4112235-05:00] [Source] [LEVEL]: message
                $m = [regex]::Match($line, '^\[([^\]]+)\]\s*\[([^\]]+)\]\s*\[([^\]]+)\]:\s*(.*)$')
                if ($m.Success) {
                    $entries.Add([pscustomobject]@{
                        When = $m.Groups[1].Value
                        Source = $m.Groups[2].Value
                        Level = $m.Groups[3].Value
                        Message = $m.Groups[4].Value
                        Origin = 'ModLogs'
                    }) | Out-Null
                }
            }
        }
    }

    # runtime.log (CrestDiag)
    $runtimeLog = Join-Path $GameRoot 'Modules\CREST\runtime.log'
    if (Test-Path $runtimeLog) {
        INFO "reading runtime.log"
        foreach ($line in (Get-Content $runtimeLog)) {
            # Format: [yyyy-MM-dd HH:mm:ss.fff] [Source] message
            $m = [regex]::Match($line, '^\[([^\]]+)\]\s*\[([^\]]+)\]\s*(.*)$')
            if ($m.Success) {
                $entries.Add([pscustomobject]@{
                    When = $m.Groups[1].Value
                    Source = $m.Groups[2].Value
                    Level = 'INFO'
                    Message = $m.Groups[3].Value
                    Origin = 'runtime.log'
                }) | Out-Null
            }
        }
    }

    # BLSE_lasterror.log
    $blseErr = Join-Path $GameRoot 'bin\Win64_Shipping_Client\BLSE_lasterror.log'
    if (Test-Path $blseErr) {
        INFO "reading BLSE_lasterror.log"
        $content = Get-Content $blseErr -Raw
        $flat = $content -replace "`r?`n", ' / '
        $when = (Get-Item $blseErr).LastWriteTime.ToString('yyyy-MM-ddTHH:mm:ss.fff')
        $entries.Add([pscustomobject]@{
            When = $when
            Source = 'BLSE'
            Level = 'ERR'
            Message = $flat
            Origin = 'BLSE_lasterror.log'
        }) | Out-Null
    }

    H2 "Errors and warnings (most recent first)"
    $errorsWarnings = $entries | Where-Object { $_.Level -in 'ERR','WRN','ERROR','WARNING' } |
        Sort-Object When -Descending | Select-Object -First 30
    if ($errorsWarnings.Count -eq 0) {
        OK "no errors or warnings in logs"
    } else {
        foreach ($e in $errorsWarnings) {
            $tag = "[" + $e.Level + "]"
            $line = "  " + $e.When + " " + $tag.PadRight(8) + " [" + $e.Source + "] " + $e.Message
            if ($line.Length -gt 200) { $line = $line.Substring(0, 197) + '...' }
            $color = if ($e.Level -in 'ERR','ERROR') { 'Red' } else { 'Yellow' }
            W $line $color
        }
    }

    H2 "Errors grouped by source"
    $bySource = $entries | Where-Object { $_.Level -in 'ERR','ERROR' } |
        Group-Object Source | Sort-Object Count -Descending
    if ($bySource.Count -eq 0) {
        OK "no error-level entries to group"
    } else {
        foreach ($g in $bySource) {
            INFO ("  " + $g.Count.ToString().PadLeft(4) + " ERR  " + $g.Name)
        }
    }
}

# ============================================================
# Patch snapshot (Phase R.2)
# ============================================================
# Bundles the most recent patches-snapshot-*.log written by
# CrestPatchSnapshot (Bannerlord.Harmony Ctrl+Alt+P hotkey or DebugUI's
# Export Snapshot button) into this report. Off by default because the
# snapshot file can be 100+ KB and would dominate the report; opt in
# explicitly with -IncludePatchSnapshot when filing a bug report involving
# Harmony patch interactions. If no snapshot exists, prints instructions
# for capturing one.
if ($IncludePatchSnapshot) {
    H1 "Patch snapshot"
    $crestRoot = Join-Path $GameRoot 'Modules\CREST'
    if (-not (Test-Path $crestRoot)) {
        ERR "Modules\CREST not found at $crestRoot"
    } else {
        $snapshots = Get-ChildItem -Path $crestRoot -Filter 'patches-snapshot-*.log' -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        if (-not $snapshots -or $snapshots.Count -eq 0) {
            WARN "no patch snapshot found in $crestRoot"
            INFO "to capture one: launch the game with the mod stack you want to inspect,"
            INFO "  press Ctrl+Alt+P in-game, then re-run Crest-Doctor -IncludePatchSnapshot."
        } else {
            $latest = $snapshots[0]
            INFO ("using " + $latest.Name + " (" + ('{0:N0}' -f $latest.Length) + " bytes, " + $latest.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss') + ")")
            if ($snapshots.Count -gt 1) {
                INFO ("(" + ($snapshots.Count - 1) + " older snapshot(s) on disk; deleting them is safe)")
            }
            W ""
            W "----- begin snapshot -----"
            Get-Content -Path $latest.FullName | ForEach-Object { W $_ }
            W "-----  end snapshot  -----"
        }
    }
}

# ============================================================
# Write report
# ============================================================
if ($ReportPath) {
    $out | Set-Content -Path $ReportPath -Encoding UTF8
    Write-Host ""
    Write-Host ("==> Report written to " + $ReportPath) -ForegroundColor Green
}
