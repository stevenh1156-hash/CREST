# CREST Migration Tool

Auto-migrates a Bannerlord mod from upstream BUTR (`Bannerlord.Harmony`, `Bannerlord.ButterLib`, `Bannerlord.UIExtenderEx`, `MCMv5`) to CREST (`Crest.Harmony`, `Crest.ButterLib`, `Crest.UIExtenderEx`, `Crest.MCM`).

## Why migrate?

CREST currently ships **compatibility shim DLLs** alongside its real implementations. The shims are tiny TypeForwardedTo stubs that let mods compiled against upstream BUTR continue working without recompile. They're an extra layer of indirection — every type lookup goes:

```
[consumer mod] -> Bannerlord.Harmony.dll (shim) -> Crest.Harmony.dll (real)
```

If your mod migrates, that becomes:

```
[consumer mod] -> Crest.Harmony.dll (real)
```

Once enough mods migrate, CREST can drop the shim layer entirely — smaller distribution, fewer moving parts on each game version.

## What the tool does

Runs Mono.Cecil over a mod's compiled DLLs and rewrites the `AssemblyReference` table. **Does not change type names, namespaces, or method signatures** — those still match the upstream BUTR API surface (CREST keeps the same FQNs after the Phase H namespace revert). Only the assembly reference *name* changes.

`PublicKeyToken` on the rewritten reference is wiped, because CREST's DLLs are unsigned. Without this, the runtime would demand a strong-name match against our unsigned assembly and fail to bind.

## Usage

```powershell
# Dry-run on a mod folder (no files written)
.\Migrate-ModToCrest.ps1 -Path 'C:\Path\To\YourModFolder' -DryRun

# Apply the migration interactively (prompts y/N before writing)
.\Migrate-ModToCrest.ps1 -Path 'C:\Path\To\YourModFolder'

# Apply non-interactively (e.g., from a CI build script)
.\Migrate-ModToCrest.ps1 -Path 'C:\Path\To\YourModFolder' -Force

# Skip the .dll.bak backup (CI-friendly)
.\Migrate-ModToCrest.ps1 -Path 'C:\Path\To\YourModFolder' -Force -NoBackup

# Migrate a single DLL file directly
.\Migrate-ModToCrest.ps1 -Path 'bin\Release\net472\YourMod.dll'
```

## Output sample

```
==> Scanning 1 DLL(s) for upstream-BUTR references

==> Migration plan
  YourMod.dll
    MCMv5 v5.11.3.0  =>  Crest.MCM v5.11.3.0
    Bannerlord.ButterLib v2.10.4.0  =>  Crest.ButterLib v2.10.4.0

Apply migration? Originals will be backed up to *.dll.bak unless -NoBackup is set [y/N]: y

==> Applying
  backed up   YourMod.dll
  rewrote     YourMod.dll  (2 refs)

==> Migrated 1 DLL(s). To roll back, copy *.dll.bak over *.dll.
```

## Safety

- **Backups are on by default.** Each DLL is copied to `*.dll.bak` before rewrite. To roll back, copy the backup over the modified file.
- **Dry-run shows the full plan without touching anything.** Always run with `-DryRun` first.
- **The tool refuses to migrate CREST-bundled DLLs.** It auto-skips files matching `Crest.*`, `Bannerlord.Harmony`, `Bannerlord.ButterLib`, `Bannerlord.UIExtenderEx`, `MCMv5`, system DLLs, etc. — so pointing it at a CREST install accidentally won't corrupt the bundle.
- **Idempotent.** Running on an already-migrated DLL is a no-op (the upstream references are gone).

## Limitations / scope

This tool is a **DLL rewriter only**. It doesn't:

- Touch your mod's `*.csproj` (use the source-mode rewriter when it ships in Phase Q.2).
- Modify your `*.cs` source files. Your `using Bannerlord.Harmony;` lines stay as-is — they bind to the same FQNs because CREST's source declares its types in those same namespaces.
- Generate a new NuGet package. If you publish your mod via NuGet, you'll want to update your `<PackageReference>` entries manually for now.

## Requirements

- Windows PowerShell 5.x or PowerShell 7+
- A CREST install (the tool finds Mono.Cecil in `Modules\CREST\bin\Win64_Shipping_Client\` automatically; pass `-CecilPath` to override).

## Compatibility & reverting

If a migrated DLL behaves badly, copy the `.dll.bak` over it. The mod will then go back through the shim layer (assuming you have CREST's shim DLLs deployed — they ship with v1.3+).

## Reporting bugs

If migration produces a broken DLL, please attach the *original* file (or `.dll.bak`) and the migration log to the bug report. The tool is intended to be format-stable across CREST versions but Mono.Cecil quirks on certain compiler flags (mostly mods built with very old MSBuild + obfuscation) can produce edge cases.
