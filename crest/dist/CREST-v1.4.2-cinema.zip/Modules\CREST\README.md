# CREST — Calradian Runtime Extensions & Standard Toolkit

Unified runtime, toolkit, and standard library for Mount & Blade II: Bannerlord (v1.4.2).

This file ships inside the release zip. For the full feature breakdown, roadmap, and FAQ, see `NEXUS_DESCRIPTION.md` in the same folder, or the Nexus mod page.

---

## Install (60 seconds)

1. Extract this zip so the `CREST` folder lands inside `Mount & Blade II Bannerlord\Modules\`. Final path should be `Modules\CREST\SubModule.xml`.
2. **Remove standalone Harmony, ButterLib, MCMv5, and UIExtenderEx** if you have them. CREST replaces them.
3. Launch the official launcher.
4. Tick **CREST**. Drag it to the top of the load order (or as close to the top as your launcher allows).
5. Launch the game.
6. From the main menu: **Options → Mod Configuration Menu → CREST**. Pick a preset (Default / Cinema / Vanilla). Save.

That's the whole install.

If Windows flagged any DLLs in this zip as "blocked," run `Unblock-CrestInstall.ps1` from the CREST folder (right‑click → Run with PowerShell). It unblocks every DLL recursively.

---

## What You Get

- **Drop‑in shim layer**: Harmony, ButterLib, MCMv5, UIExtenderEx — all version‑pinned and pre‑wired. Stop chasing dependency drift.
- **Battle Convergence**: nearby AI lord parties rally to the player's battle. Staggered arrivals over 5+ minutes. Tactics‑by‑skill behavior. Asymmetric ally/enemy radius (3× for allies — they rally to you from the kingdom).
- **Cinema Preset**: one‑click MCM preset that turns the stack into recording mode. Player invincibility, fast convergence cadence, plausible lord reinforcements, achievements still armed.
- **Player Invincibility** (toggle): main agent health pegs at HealthLimit each tick. Animations and hits still play; you don't die. Camera‑safe.
- **Achievement Protection**: keeps `EnableAchievementsWithMods = true` armed across preset switches.
- **Profiled hot path**: smooth at 64× campaign speed on the v1.4.2 base game. We treat regressions on this axis as bugs.
- **One log file**: `Modules\CREST\runtime.log` is the single diagnostic source of truth. Send this with any bug report.

---

## Presets at a Glance

| Preset | Convergence | Invincibility | Achievements | Use For |
|---|---|---|---|---|
| **Default** | On (conservative) | Off | Armed | Normal campaigns. |
| **Cinema** | On (aggressive: 5 s start, 3 s cadence, 20 cap, 3× ally radius) | On | Armed | Recording, screenshots, content creation. |
| **Vanilla** | Off | Off | Armed | "Just give me the shim layer, nothing else." |

Switching presets is instantaneous and persists across saves. You can override individual fields after picking a preset; your overrides stick until you re‑pick.

---

## Bug Reports

Attach `Modules\CREST\runtime.log` to your report. That file alone covers what used to take five separate logs.

If you've never opened it, it's a plain text file you can read in Notepad. Each line is `[timestamp] [source] message`.

Optional but helpful:
- Your save file (or a step‑by‑step repro on a new save).
- Your launcher load order (screenshot is fine).
- Did the issue exist before installing CREST? (i.e. is this a CREST regression or a pre‑existing mod conflict.)

---

## Modder Quick Start

You depend on `Bannerlord.Harmony.dll`. Public APIs you can call from day one:

```csharp
using Bannerlord.Harmony;

// Append a timestamped diagnostic line to Modules\CREST\runtime.log
CrestDiag.Log("MyModSource", "something interesting happened");

// Compact "I caught and swallowed this" record
try { /* ... */ }
catch (Exception ex) { CrestDiag.LogCaught("MyModSource", "OnTick", ex); }

// Compact "AccessTools returned null" record
CrestDiag.LogTypeNotFound("MyModSource", "TaleWorlds.X.Y");

// mtime-cached config read, safe for hot paths
if (CrestConfig.IsEnabled("MyMod_FeatureFlag", defaultValue: false))
{
    // ...
}
```

Full API surface is documented in `NEXUS_DESCRIPTION.md`.

---

## Support

Patreon: https://patreon.com/Trashpanda1?utm_medium=unknown&utm_source=join_link&utm_campaign=creatorshare_creator&utm_content=copyLink

Patreon support funds the runtime work that makes things like **hot‑reload DLLs** possible. That stretch goal lights up when the community shows up.

---

## License

Source‑available. Redistribution of the bundled shim layer follows each shim's upstream license (Harmony, ButterLib, MCMv5, UIExtenderEx). CREST‑original code is licensed per the repository's `LICENSE` file.
