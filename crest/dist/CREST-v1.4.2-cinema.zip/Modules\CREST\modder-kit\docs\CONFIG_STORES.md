# CREST configuration storage — two locations, one source of truth

> Phase P.1 (M8): documentation of CREST's config flow so future maintenance doesn't accidentally introduce a third store, and end users know which file to edit.

CREST keeps the same set of runtime gates in two on-disk locations. The duplication is deliberate — each location serves a different reader at a different point in the launch lifecycle — but the locations stay synchronized in both directions so editing either has the same effect.

## The two locations

### 1. `Modules/CREST/crest.json` — startup-time source of truth

* Read by `Bannerlord.Harmony.CrestConfig.IsEnabled(...)` during `OnSubModuleLoad` for every Crest.* sub-module (Harmony, ButterLib, MCM core, MCM UI, etc.).
* Format: hand-editable JSON with a single `"enabled"` block of bool flags.
* Written: created with all-true defaults if missing; updated by MCM on save (see below); editable directly in a text editor.
* This is what the gate code consults *before MCM has loaded* — that's why it has to be a separate file.

Schema (current keys):

```json
{
  "_comment": "CREST runtime configuration. Edit and relaunch the game to apply, or toggle the same checkboxes in MCM.",
  "enabled": {
    "ButterLib": true,
    "MCM": true,
    "MCMBasicImplementation": true,
    "MCMUI": true,
    "SkipIntroVideo": true,
    "MainMenuMonotone": true,
    "SuppressMainMenuMessages": true,
    "AutoUnblock": true,
    "RuntimeSelfTest": true
  }
}
```

The `RuntimeSelfTest` flag (Phase P.2) gates `CrestPatchSelfTest.Run()` — a one-shot walk of `Harmony.GetAllPatchedMethods()` at game start that verifies the top-N most version-fragile Harmony patches inherited from upstream BUTR (WidgetPrefab.LoadFrom transpiler, ButterLib's Module transpilers, BEW finalizers, GauntletMovie conditional-prefix, WidgetFactoryManager's six TryPatches) actually bound on the current TaleWorlds version. A miss is logged to `Modules\CREST\runtime.log`; if any "hard" miss is detected, a single orange InformationManager warning is surfaced at launch. Power users on bleeding-edge game versions sometimes want to disable this if they're tracking a specific patch failure manually.

### 2. `Configs/ModSettings/Global/MCM/CREST_v1.json` — MCM-managed mirror

* Read by MCM's settings provider when the user opens **Mod Options → CREST**.
* Format: MCM's own JSON (`json2`) — populated from the in-memory `CrestSettings` view-model, which mirrors `crest.json`'s flags as `[SettingPropertyBool]` properties.
* Written: by MCM whenever the user toggles a checkbox and clicks **Save** in the Mod Options screen.

## How the two stay in sync

Implementation lives in `Bannerlord.MBOptionScreen/src-ui/Crest.MCM.UI/CrestSettings.cs`:

* On **MCM's `LOADING_COMPLETE`** event (right after the settings file finishes deserializing), `CrestSettings.OnPropertyChanged` calls `ReadFromCrestJson()` — re-loads `crest.json` and overwrites whatever MCM just deserialized. **`crest.json` wins on read** so manual edits to that file (or values written by another session) propagate forward.
* On **MCM's `SAVE_TRIGGERED` event** (when the user clicks Save in Mod Options), `OnPropertyChanged` calls `WriteToCrestJson()` — serializes the view-model's current property values back to `crest.json`. **The user's MCM toggle wins on write** so the next launch's startup gate sees the new value.

Net effect: edit either file, and the other catches up. No conflict-resolution UI is needed because every flag has a single canonical form (a bool) and the load/save events are non-overlapping.

## When does each file get touched?

| Event | `crest.json` | `CREST_v1.json` |
|---|---|---|
| Game launches, no `crest.json` yet | created with all-true defaults | (no MCM file yet either; created on first MCM Save) |
| User edits `crest.json` in Notepad, then launches | **read**, gates apply | overwritten on next MCM Save |
| User toggles a checkbox in Mod Options + Save | overwritten by `WriteToCrestJson` | written normally by MCM |
| User opens Mod Options without changing anything | (untouched until Save) | re-read, then overlaid by `ReadFromCrestJson` so checkboxes match `crest.json` |
| `Crest-Compat -Restore` or other dev tooling | (untouched) | (untouched) |

## Why not collapse to one file?

Considered and rejected. The startup gates fire during `OnSubModuleLoad`, which runs **before** MCM's settings provider has finished deserializing its store. If we tried to read `CREST_v1.json` directly from `CrestConfig.IsEnabled`, we'd:

* hit a `FileNotFoundException` on a fresh install (MCM creates the file on first save, not on first load),
* take a hard dependency on MCM's exact storage format (currently `json2`; MCM has changed format in past versions),
* break the "MCMUI off" code path: if `MCMUI=false` was the gate we needed to read, we'd ironically need MCM UI to load to read it.

Keeping `crest.json` as a thin, self-contained format for early-startup reads — and treating it as the single source of truth on read — sidesteps all three.

## What if I want to add a new flag?

1. Add the field to `Modules/CREST/crest.json`'s default JSON template in `Bannerlord.Harmony/src/Crest.Harmony/CrestConfig.cs:WriteDefault()`.
2. Add the matching `[SettingPropertyBool]` property in `Bannerlord.MBOptionScreen/src-ui/Crest.MCM.UI/CrestSettings.cs`, including the `case` in `ReadFromCrestJson` and the `AppendFormat` line in `WriteToCrestJson`.
3. Read the flag in your CREST sub-module via `CrestConfig.IsEnabled("YourFlagName")`.

The `crest.json`'s tiny custom JSON parser (regex-based) tolerates extra keys, so adding a flag is forward-compatible — old CREST builds that don't know about the new flag won't crash on the new key.
