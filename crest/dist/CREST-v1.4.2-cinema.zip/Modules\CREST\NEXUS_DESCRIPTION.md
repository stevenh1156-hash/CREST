# CREST — Calradian Runtime Extensions & Standard Toolkit

**Are you a modder? Then stop what you are doing right now.**

CREST is the unified runtime, toolkit, and standard library for Mount & Blade II: Bannerlord that the modding community has been waiting four years for. One install. One version. One log file. One settings menu. Every shim your mod list needs, all of the diagnostics you wish you had, and the runtime hooks to do things the base game never let you do.

If you make mods, this is your new foundation. If you play with mods, this is the one mod you install before any other.

---

## TL;DR

- **Drop‑in replacement** for Harmony, ButterLib, MCMv5, and UIExtenderEx — installed, version‑matched, and pre‑wired.
- **Runtime extensions** the base game doesn't ship: battle convergence, player invincibility, achievement protection, tactics‑by‑skill, cinematic preset, mid‑mission config reload, structured diagnostics.
- **Modder toolkit**: a public diagnostic logger (`CrestDiag`), a config layer (`CrestConfig`) with hot mtime‑refresh, an MCM preset system, and a release‑grade build/packager pipeline.
- **Smooth at 64× campaign speed** on the v1.4.2 base game — the entire stack was profiled and optimized to take the time slider all the way to the right without falling over.
- **No more "which version of ButterLib do I need" threads.** Pin one mod. CREST.

---

## Why Players Should Install It

You're tired of the dependency hell. You're tired of mod authors saying "requires Harmony 2.3.0.0 (Bannerlord) and ButterLib 2.10.x and MCMv5 5.10 and UIExtenderEx 2.13" — and then one of them is out of date and the load order coughs up six exceptions before you reach the main menu.

CREST collapses all of that into a single mod. You install one thing. The companion shims load first, in the right order, at the right versions, every time. Your mod list gets shorter, your launcher gets quieter, your saves get more stable.

On top of the shim layer, CREST ships **runtime features** that meaningfully change how the game plays:

- **Battle Convergence** — nearby AI lord parties actually rally to the player's battle. Heavy‑outnumbered fights that used to be flat lose conditions become real, dynamic engagements with reinforcements pouring in over five‑plus minutes of staggered arrivals. There's a Cinema preset that turns this all the way up.
- **Player Invincibility** (toggle) — for cinematic playthroughs, content creators, screenshot runs, or just the times you don't want a stray javelin to end your hour.
- **Tactics‑by‑Skill** — AI lord performance scales with their actual Tactics skill, the way the tooltips have always implied.
- **Achievement Protection** — your achievements are not silently disabled by mods on by default; CREST keeps them armed across preset changes.
- **Cinema Preset** — one click in MCM and the whole stack is tuned for cinematic battles: filters off, fast convergence cadence, long radius, invincibility on. Drop in, record, drop out. (Full breakdown below.)

And the part you don't see: it's *fast*. The base game (no mods, no script extenders) was already solid at high time‑compression, but historically mod stacks made 16×, 32×, and 64× speeds painful. CREST is profiled hot‑path‑first. Buffered logging. Cached config reads. Mode‑gated tick handlers. **The result is that the base‑game smoothness is preserved all the way up to 64× world map speed.** This is the headline metric for the build: if something you install on top of CREST tanks your time compression, that something is the regression — not CREST.

---

---

## Cinema Mode — The Headline Preset

Cinema Mode is the reason a lot of people will install CREST in the first place. It is a one‑click MCM preset that retunes the entire CREST runtime for **cinematic, recording‑grade, content‑creator‑friendly battles** — the kind of fights that look like the trailer footage you saw before launch and never quite got in the actual game.

**How to enable**: launcher → Mount & Blade II: Bannerlord → in‑game ESC → Mod Configuration Menu → CREST → Preset dropdown → **Cinema** → Done.

**What Cinema Mode actually changes** (under the hood, all surfaced in MCM so you can fine‑tune from the preset):

| Setting | Cinema Value | Why |
|---|---|---|
| `EnableBattleConvergence` | **ON** | Nearby AI lord parties will rally to the fight. |
| `BattleConvergenceDisableFilters` | OFF | Default lord‑filtering rules are kept; we want *plausible* reinforcements, not chaos. |
| `BattleConvergenceMaxJoinersPerSide` | **20** | Up to 20 distinct lord parties can join per side. Plenty of named banners on screen. |
| `BattleConvergenceMaxActiveJoiners` | **20** | Active simultaneous reinforcement waves capped at 20. |
| `BattleConvergenceInitialDelaySec` | **5** | First wave arrives 5 s after battle start. No empty intro. |
| `BattleConvergenceCadenceSec` | **3** | New waves stagger in every 3 s after that. Constant pressure. |
| `BattleConvergenceClanTierScaling` | OFF | Equal weight to all valid joiners — small clans show up too. |
| `BattleConvergenceRadius` | **100** | 100‑unit base detection radius around the engagement. |
| Ally‑side radius multiplier | **3.0×** | Allies get a 300‑unit reach because they "rally to" the player from kingdom territory; enemies use the base radius. This is the asymmetric fix that makes deep‑territory battles feel right. |
| `EnablePlayerInvincible` | **ON** | Player main agent health pegs at HealthLimit each tick. You still flinch, get hit, take animations — you just don't die. Perfect for camera work. |
| Achievement Protection | **ON** | Cinema mode does **not** disable achievements. Record and earn at the same time. |

**The lord‑formation system**: Each arriving lord brings their party into a single dedicated formation slot (collapsed from an earlier 3‑bucket experiment that overflowed engine formation tables). Tactics behavior is keyed off the lord's actual `DefaultSkills.Tactics` value — Novice / Trained / Veteran tiers get different stances. So your reinforcement lords don't all behave identically; the high‑tactics ones flank, the low‑tactics ones brawl.

**Staggered arrival**: candidates are sorted by distance, deadlines are assigned at `t0 + 5 + (i × 3)` seconds, and each party crests the spawn ridge on its own beat. The result is a five‑plus minute escalation curve — one banner, then two, then suddenly the field is full — instead of an instant single dump.

**Why content creators should care**:

- **Player Invincibility** lets you frame and re‑frame shots without dying. You still take hits visually, so the *combat* still looks real on camera.
- **Filters kept on** means your reinforcement lords are plausible characters from the campaign, not random arena cameos. Screenshots come out narratively coherent.
- **The 3 s cadence + 100/300 radii** means there's always something happening in the background of your shot. You don't get the dead air that vanilla outnumbered fights leave you with.
- **Achievements stay armed**, so a Cinema run is a *real* run.
- **Mid‑mission config reload** means you can edit `crest.json` while paused, alt‑tab back, and your tweaked values are live for the next tick. No restart‑to‑test cycle for camera setup.

**Recording workflow** (recommended):

1. Apply Cinema preset in MCM, save.
2. Roll into a battle the player would normally lose 1v3 against.
3. Pause / hit your favorite tactical pause hotkey, frame the shot.
4. Unpause, let the convergence stagger play out.
5. The whole engagement runs 5–8 minutes of escalating reinforcements. Plenty of footage.

**Cinema vs Default vs Vanilla** (the three shipped presets):

- **Cinema** — everything described above. Recording mode.
- **Default** — convergence on with conservative caps (~5 joiners, longer cadence). Playable mode for normal campaigns. Player invincibility off.
- **Vanilla** — every CREST runtime feature off. Pure shim layer. Use this when you want the *exact* base‑game battle behavior and only want CREST as a load‑order consolidator.

Switching presets is instantaneous and does not require a restart. Settings hot‑swap on the next config tick.

---

## Why Modders Should Use It

Because you should not be writing the same five plumbing files in every mod you ship.

CREST gives you, on day one:

- **`CrestDiag`** — a public, reentrant, append‑only diagnostic logger anchored at `Modules\CREST\runtime.log`. Works **before** ButterLib's logger initializes. Buffered with a 1 Hz flush, AppDomain‑unload sweep, lazy timer init, and a 4096‑line backpressure ceiling. Drop‑in API: `CrestDiag.Log(source, msg)`, `CrestDiag.LogCaught(source, ctx, ex)`, `CrestDiag.LogTypeNotFound(source, type)`. Users send *one* file when they report a bug. You read *one* file when you debug it.
- **`CrestConfig`** — a JSON config layer with mtime‑throttled hot‑refresh. Edit `crest.json` while the game is running and your toggles are picked up on the next tick window. No restart‑to‑test loop.
- **MCM preset system** — register your mod's settings as a `MemorySettingsPreset` and inherit Cinema/Default/Vanilla support for free.
- **Standardized hooks** — `MissionBehaviorType`, mission‑mode‑gated tick paths, agent‑state guards, and the patterns that took the rest of us a year of crash logs to figure out, distilled into copy‑pasteable starting points.
- **Build & release pipeline** — `Crest-ReleaseBuild.ps1` builds every dependent repo, stages to `dist\staging`, validates required DLLs, strips forbidden artifacts (PDBs, .bak, runtime.log), and emits a clean shippable zip. `Crest-FreshInstallTest.ps1` snapshots your install, wipes, extracts, and verifies a clean fresh‑install boot. **You ship faster and you ship cleaner.**

The opinionated take: every modder eventually rebuilds these pieces, badly. CREST is the version that everyone agrees on.

---

## Modding Tools (Public API)

Available to any mod that takes a dependency on `Bannerlord.Harmony` (Crest core):

| API | Purpose |
|---|---|
| `CrestDiag.Log(source, message)` | Append a timestamped line to the shared runtime log. |
| `CrestDiag.LogCaught(source, context, exception)` | Compact "I caught and swallowed this" record. |
| `CrestDiag.LogTypeNotFound(source, typeName)` | Compact "AccessTools returned null" record. |
| `CrestDiag.Flush()` | Force the buffer to disk (use before reading the log live). |
| `CrestConfig.IsEnabled(key, defaultValue)` | mtime‑cached config bool read, safe for hot paths. |
| `CrestConfig.GetInt(key, default)` / `GetFloat(key, default)` / `GetString(key, default)` | Typed reads with hot‑refresh. |
| `MemorySettingsPreset` (MCM) | Define presets that swap entire bundles of your settings in one click. |

The Crest‑Doctor diagnostic tool reads from the same `runtime.log`, so anything you log via `CrestDiag` is visible to community support tooling without further integration.

---

## Roadmap

**Y series — feature absorption and runtime extensions** (in flight):

- **Y.4** — Absorb RTSCamera + CommandSystem (full absorption, not redistribution).
- **Y.6** — Troop equipment / class changer in‑mission.
- **Y.8** — In‑game troop spawner.
- **Y.13** — Absorb BetterTroopHUD.
- **Y.24** — **Live Battles**: opt‑in multiplayer hot‑swap — a real player drops into the place of a lord NPC for the duration of one battle.
- **Y.25** — **Live Arena**: PvP tournament matchmaking against another human in the place of an arena AI.
- **Y.26** — **Live Tavern**: persistent social hub layered on top of the singleplayer tavern.

**Z series — release engineering, performance, polish**:

- Z.5 — release packager + fresh‑install harness ✅
- Z.6 — perf wins (batched logs, cached config reads, mission‑mode gating, debug‑gated verbose logs) ✅
- Z.7+ — continuous profiling, allocation auditing, GC pressure reduction.

**Stretch goal — Hot‑Reload DLLs**: with enough community support and Patreon backing, CREST gains the ability to **hot‑reload consumer mod DLLs while the game is running**. No more relaunch cycles. Edit, build, alt‑tab, and your patch is live. This is the holy grail of Bannerlord modding velocity, and it is on the table — fund the work and it ships.

---

## What CREST Replaces (Stop Installing These Separately)

CREST ships an internal, version‑pinned, pre‑wired copy of:

- **Harmony** (Bannerlord build)
- **ButterLib**
- **Mod Configuration Menu v5 (MCMv5)**
- **UIExtenderEx**

Uninstall the standalone copies. CREST loads first and presents these to the rest of the load order at the exact versions they were tested against.

Phase Y will additionally absorb (subject to author cooperation / license review):

- **RTSCamera** (Y.4)
- **CommandSystem** (Y.4)
- **BetterTroopHUD** (Y.13)

Until Y.4/Y.13 land, those mods continue to be installed alongside CREST as normal.

---

## What CREST Works With

Short answer: **anything Harmony‑based** that doesn't try to bring its own conflicting copy of one of the four shims above. Most of the popular mod list works untouched.

Long answer: CREST is the runtime everyone else expected to be there. If your mod ran on top of vanilla Harmony + ButterLib + MCMv5 + UIExtenderEx, it runs on top of CREST. If it bundled its own ancient Harmony 2.2.x, drop the bundle and let CREST provide it.

If you find a specific mod that conflicts, post the `Modules\CREST\runtime.log` file in the issues tracker and we will look at it. That single log file replaces about six places you used to dig through.

---

## The Plan to Stop Using the Shims

This is important and the community deserves to hear it stated plainly.

CREST currently **wraps and redistributes** Harmony, ButterLib, MCMv5, and UIExtenderEx. That is a *transition state*, not the destination.

The end state is **native CREST primitives** — patching, logging, settings, UI extension — written for v1.4.2's actual surface area, with the shims removed entirely. The path:

1. **Now → Y.13**: ship the shim‑bundle so that mod authors and players get a single coherent install today. Build trust. Build adoption. Build the API.
2. **Y.14 → Y.20**: introduce native CREST equivalents alongside the shims. Mark shim APIs `[Obsolete]` with migration guides. Provide a 1:1 source‑level porting tool where feasible.
3. **Y.21+**: shims become opt‑in legacy‑mode. Default install ships native primitives only. Mod authors who have migrated get a smaller, faster, lower‑allocation runtime; mod authors who haven't keep working via the legacy package.
4. **Z.10**: shim removal milestone. Anything that hasn't migrated by then runs in a `CREST‑Legacy` companion that we maintain at lower priority but do not deprecate while there are still active dependents.

We are not in the business of breaking your mod. We are in the business of making sure that in two years, a Bannerlord modder's first decision isn't *"which six shim mods do I install."*

---

## FAQ

**Q: Is this safe to install on an existing save?**
A: Yes. CREST is additive at the engine level. Disable any toggles you don't want (Battle Convergence, Player Invincibility, etc.) in MCM and the mod is functionally inert beyond the shim layer.

**Q: Will it break achievements?**
A: No — the opposite. CREST ships an Achievement Protection layer that defends `EnableAchievementsWithMods = true` across preset switches.

**Q: I already have Harmony / ButterLib / MCMv5 / UIExtenderEx installed. What do I do?**
A: Remove them. CREST provides them. Keeping a second copy is the #1 source of "it crashes on launch" reports.

**Q: Does it work with [insert mod]?**
A: If that mod ran on top of vanilla Harmony + ButterLib + MCMv5 + UIExtenderEx, yes. If you find a conflict, send the `runtime.log`.

**Q: What's the Cinema preset?**
A: One‑click MCM preset that turns the stack into recording mode: convergence on with fast cadence (3 s) and long radius (100 base, 3× ally multiplier), filters kept on for plausible lord reinforcements, player invincibility on, achievements still armed. See the dedicated *Cinema Mode* section above for the full settings table and the recording workflow.

**Q: Does Cinema mode disable achievements?**
A: No. Achievement Protection stays armed in Cinema, so a Cinema run is a real run. This is intentional — Vanilla is the only preset that touches achievement behavior, and even that is now defensive only.

**Q: Can I tweak Cinema's individual values without leaving the preset?**
A: Yes. Pick Cinema, then change any single field in MCM. The preset is a starting point, not a lock — your overrides persist until you re‑pick a preset.

**Q: Why does it say "smooth at 64× speed"?**
A: Because we profiled the hot path and the answer is that with CREST installed, the base game's world‑map time compression remains usable all the way to the maximum slider. We treat regressions on this axis as bugs.

**Q: Multiplayer? Live Battles?**
A: Roadmap, not shipped. Y.24/Y.25/Y.26. Opt‑in. Real players drop into the place of lord/arena/tavern NPCs in your singleplayer game. The framework is being designed first; the netcode lights up after.

**Q: Hot‑reload DLLs — is that real?**
A: It is a **stretch goal** with a clear path to implementation. With enough Patreon support and community interest, it ships. This is the single biggest velocity unlock available to Bannerlord modding.

**Q: Where do I report bugs?**
A: Send `Modules\CREST\runtime.log` along with your save. That file alone covers what used to be five different log paths.

**Q: License?**
A: Source available, see repository. Redistribution of the shim layer follows each shim's upstream license.

---

## Support the Project

**Patreon: https://patreon.com/Trashpanda1?utm_medium=unknown&utm_source=join_link&utm_campaign=creatorshare_creator&utm_content=copyLink**

If you want hot‑reload DLLs to be the next thing this stack ships, this is how you make it happen. Patreon support is what funds the runtime work that no single mod author can justify spending three months of weekends on.

---

## Logo Prompt for Gemini

Paste this into Gemini (or any text‑to‑image model) to generate the CREST logo:

> A heraldic shield crest in the style of medieval Mount & Blade Calradian heraldry, centered composition, dark steel gray and burnished gold color palette, deep navy backdrop, the letters "CREST" integrated into the lower band of the shield in a chiseled serif weathered‑metal typeface, the upper band displays a stylized circuit‑etched motif that reads as runic from a distance and as engineered traces up close — symbolizing a runtime built into a medieval crest. Subtle wear, hammered‑metal texture, high contrast, no humans, no faces, no animals, vector‑clean silhouette suitable for a 256×256 mod thumbnail and also for a 1920×1080 banner. Square 1:1 framing. Professional game‑mod logo aesthetic, evocative of foundational toolkits, conveying authority and permanence.

Variants worth running:

- Same prompt, but replace "dark steel gray and burnished gold" with **"oxidized copper and ivory"** for a warmer alt.
- Same prompt, but **"minimalist line‑art version, single weight stroke, white on transparent"** for a small‑icon variant.
- Same prompt, but **"banner aspect 21:9, the shield offset to the left third, the right two thirds reserved for the wordmark CALRADIAN RUNTIME EXTENSIONS & STANDARD TOOLKIT in two stacked lines of small caps"** for a header card.

---

## Screenshots You Should Take

For the Nexus / mod page gallery, in this order. The first three carry the thumbnail; everything after is supporting.

1. **MCM Settings page — Cinema preset selected.** Show the preset dropdown open with Default / Cinema / Vanilla visible. Foreground is the CREST settings panel; background is faintly the main menu.
2. **Mid‑battle convergence in action.** Wide angle, player team in the foreground, two or three reinforcement banners visibly cresting a hill in the distance. Best taken with Cinema preset, ~90 seconds into a battle, with the player‑invincibility safety on so you can take the shot leisurely.
3. **The single `runtime.log` open in a text editor**, showing the timestamped, source‑prefixed lines from CrestDiag. This sells the diagnostics story to modders at a glance.
4. **Campaign world map at 64× speed** — capture both the speed indicator and the smooth motion (a clean shot, no stutter artifacts visible). Caption it "64× and steady."
5. **The MCM preset comparison** — three side‑by‑side captures of the same Battle Convergence options screen with Default, Cinema, and Vanilla loaded, demonstrating the one‑click swap.
6. **Load order screen** showing only CREST + your test mods — emphasizing that Harmony / ButterLib / MCMv5 / UIExtenderEx are gone from the list because CREST replaced them.
7. **Hotkey bind page** for the convergence companion key (Z by default), proving the user‑facing surface area is friendly.
8. **A "before / after" diptych** of a normally hopeless outnumbered fight: before CREST, you fight 1v3; after CREST with convergence, friendly lord parties are arriving to even the field.
9. **The achievement‑protected toast** appearing after a session with mods installed, confirming Steam achievements are still firing.
10. **(Optional, modder‑facing)** A Visual Studio split view: `CrestDiag.cs` source on the left, the live `runtime.log` updating on the right. This is the shot that sells the toolkit to other mod authors.

If you have to pick three, pick **2**, **4**, and **3** — convergence in a battle, the 64× speed claim proven on screen, and the one‑file diagnostic log.

---

## Install

1. Subscribe / download the zip.
2. Extract to `Modules\CREST` in your Bannerlord install.
3. Remove standalone Harmony, ButterLib, MCMv5, UIExtenderEx if present.
4. Enable **CREST** in the launcher. Place it at or near the top of the load order.
5. Launch. Open MCM → CREST. Pick a preset. Play.

If anything is wrong, attach `Modules\CREST\runtime.log` to your bug report. That's the whole story in one file.

---

**This is the foundation. Everything else builds on top of it.**

— The CREST Team
