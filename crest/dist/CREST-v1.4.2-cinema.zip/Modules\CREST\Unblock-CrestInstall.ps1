# Unblock-CrestInstall.ps1
#
# Run this ONCE after extracting the CREST zip into your Bannerlord game folder.
# Removes the Windows "Mark of the Web" (Zone.Identifier alternate data stream)
# from every CREST + BLSE DLL/EXE so the .NET CLR will load them. Without this,
# extracted-from-zip files are blocked by Windows and the game silently fails
# to load the mod.
#
# Right-click each file -> Properties -> tick Unblock would do the same thing,
# but for hundreds of files. This script is the bulk version.
#
# Usage from PowerShell, with the working directory set to your Bannerlord
# game root (the folder that has Bannerlord.exe and a Modules\ subfolder):
#
#   .\Modules\CREST\Unblock-CrestInstall.ps1
#
# Or with an explicit path:
#
#   .\Modules\CREST\Unblock-CrestInstall.ps1 -GameRoot 'C:\Path\To\Bannerlord'
#
# Re-running is safe (idempotent). After running once, CREST's runtime
# CrestUnblock pass handles the rest on each game launch.

[CmdletBinding()]
param(
    [string]$GameRoot
)

$ErrorActionPreference = 'Continue'

# Resolve game root: explicit param wins; otherwise infer from the script's
# location (Modules\CREST\Unblock-CrestInstall.ps1 -> game root is two parents up).
if (-not $GameRoot) {
    try {
        $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
        $crestRoot = $scriptDir
        $modulesRoot = Split-Path -Parent $crestRoot
        $GameRoot = Split-Path -Parent $modulesRoot
    } catch {
        Write-Error "Could not infer game root. Pass -GameRoot 'C:\Path\To\Bannerlord' explicitly."
        exit 1
    }
}

if (-not (Test-Path $GameRoot)) {
    Write-Error "Game root not found: $GameRoot"
    exit 1
}

Write-Host "Unblock-CrestInstall" -ForegroundColor Cyan
Write-Host ("  game root: " + $GameRoot)

# Folders to walk. CREST module + the four stub modules + the game's bin folder
# (BLSE binaries live there).
$targets = @(
    (Join-Path $GameRoot 'Modules\CREST'),
    (Join-Path $GameRoot 'Modules\Bannerlord.Harmony'),
    (Join-Path $GameRoot 'Modules\Bannerlord.ButterLib'),
    (Join-Path $GameRoot 'Modules\Bannerlord.UIExtenderEx'),
    (Join-Path $GameRoot 'Modules\Bannerlord.MBOptionScreen'),
    (Join-Path $GameRoot 'bin\Win64_Shipping_Client')
)

$total = 0
foreach ($t in $targets) {
    if (-not (Test-Path $t)) {
        Write-Host ("  skip:  " + $t + " (not found)") -ForegroundColor DarkGray
        continue
    }
    $files = Get-ChildItem -Recurse -File -Path $t -Include '*.dll','*.exe','*.config' -ErrorAction SilentlyContinue
    if (-not $files) { continue }

    # Unblock-File is built into PowerShell 3.0+; it strips the Zone.Identifier
    # ADS. -ErrorAction SilentlyContinue skips files that don't have it (most
    # of them, post first run).
    $files | Unblock-File -ErrorAction SilentlyContinue

    Write-Host ("  unblocked " + $files.Count + " files in " + $t)
    $total += $files.Count
}

Write-Host ""
Write-Host ("Done. Processed " + $total + " files. Launch Bannerlord normally.") -ForegroundColor Green
