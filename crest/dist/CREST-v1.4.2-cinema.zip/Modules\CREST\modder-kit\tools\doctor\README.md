# Crest-Doctor

Single-entry diagnostic tool for Bannerlord mod authors using CREST. Runs four kinds of checks. Use it to debug a misbehaving install, validate a development setup, or grab a structured Markdown attachment for a bug report.

## Usage

```powershell
# Run every check, console output
.\Crest-Doctor.ps1

# Run every check, also write a Markdown report
.\Crest-Doctor.ps1 -ReportPath 'crest-doctor.md'

# Single check focus
.\Crest-Doctor.ps1 -Health
.\Crest-Doctor.ps1 -LoadOrder
.\Crest-Doctor.ps1 -Logs
.\Crest-Doctor.ps1 -Mod BloodMod1313

# Bundle the most recent in-game patch snapshot into the report. Capture
# the snapshot first by pressing Ctrl+Alt+P in-game (Phase R.2 hotkey).
.\Crest-Doctor.ps1 -IncludePatchSnapshot -ReportPath 'crest-doctor.md'

# Override game / docs paths
.\Crest-Doctor.ps1 -GameRoot 'D:\Games\Bannerlord' -DocumentsRoot 'D:\Saves\TaleWorlds\Bannerlord'
```

## What each check does

### `-Health`

Verifies your CREST install is structurally sane:

- All 12 core DLLs present in `Modules\CREST\bin\Win64_Shipping_Client\` (the four Crest forks, the four shims, plus 0Harmony / Mono.Cecil / `Crest.MCM.UI.dll` / `Crest.MCM.UI.Adapter.MCMv5.dll`). Pre-Y.16 builds shipped this as `CREST.v<gameversion>.dll` (e.g. `CREST.v1.4.1.dll`); old install layouts may still have that filename, Doctor accepts either.
- BLSE deployed: `Bannerlord.BLSE.dll` is in the game's bin folder; `TaleWorlds.MountAndBlade.Launcher.exe.config` has the AppDomainManager redirect; `Bannerlord.exe.config` is present (covers Steam-direct launch).
- All four stub modules (`Bannerlord.Harmony`, `Bannerlord.ButterLib`, `Bannerlord.UIExtenderEx`, `Bannerlord.MBOptionScreen`) exist with their `SubModule.xml`.
- `crest.json` parses; lists all enabled flags.
- `TaleWorlds.MountAndBlade.dll` version detected; CREST's intended game version reported.

### `-LoadOrder`

Parses every `Modules\X\SubModule.xml`, builds the dependency graph:

- **Missing dependencies:** any `<DependedModule Id="X">` referencing a module that isn't installed.
- **Dependency cycles:** any A → B → ... → A loop.
- **Launcher order violations:** for the currently selected mod set in `LauncherData.xml`, any case where a module loads BEFORE its declared dependency.

### `-Mod <name>`

Static analysis of a target mod's compiled DLLs:

- Reads `TypeReferences` table of every `.dll` in the mod's folder.
- Filters to BUTR-stack references (`Bannerlord.Harmony.*`, `Bannerlord.ButterLib.*`, `Bannerlord.UIExtenderEx.*`, `MCM.*`).
- For each reference, reports whether it resolves to a current CREST public type. References that don't are flagged — those are the ones likely to break if the player runs your mod.

### `-IncludePatchSnapshot`

Off by default. When set, looks for the most recent `patches-snapshot-*.log` in `Modules\CREST\` and inlines its contents into the doctor report. The snapshot is produced in-game by either:

- pressing **Ctrl+Alt+P** at any time (writes a fresh `patches-snapshot-yyyyMMdd-HHmmss.log` and shows a confirmation chat message), or
- opening the imgui DebugUI panel (**Ctrl+Alt+H**) and clicking **Export Snapshot**.

The snapshot lists every method any Harmony instance has patched, grouped by declaring type, with full per-patch metadata (owner harmony id, prefix/postfix/transpiler/finalizer, priority, before/after constraints). Use this when filing a bug report involving "patch ordering" or "my patch isn't running" issues — the snapshot is the ground-truth view of the patch table at the moment you captured it. If no snapshot exists, the doctor prints capture instructions instead.

### `-Logs`

Aggregates the four log sources:

- `Documents\Mount and Blade II Bannerlord\Configs\ModLogs\default*.log` (latest)
- `Modules\CREST\runtime.log` (CREST's `CrestDiag` entries)
- `bin\Win64_Shipping_Client\BLSE_lasterror.log`
- (Future) game crash logs

Output: latest 30 errors and warnings interleaved by timestamp, then a per-source ERR count summary so you can spot which component is the loudest offender.

## Output sample (real run)

```
# Health check
========================================================================

## CREST module
  [OK]    Crest.Harmony.dll
  ...
  [INFO]  all 12 core DLLs present

## BLSE injection
  [OK]    Bannerlord.BLSE.dll deployed in game bin
  [OK]    Launcher .config has AppDomainManager redirect
  [OK]    Bannerlord.exe.config present (covers direct-game launch path)

# Load-order analysis
========================================================================
  [INFO]  found 43 modules with valid SubModule.xml

## Missing dependencies
  [ERR]   FasterTime depends on WarSails -- not installed

## Dependency cycles
  [OK]    no dependency cycles

# Logs aggregator
========================================================================

## Errors grouped by source
  [INFO]     162 ERR  System.Diagnostics.Logger.LoggerTraceListener
  [INFO]      32 ERR  Bannerlord.ButterLib.Implementation.MBSubModuleBaseExtended.Patches.ModulePatch
  [INFO]      13 ERR  Crest.ButterLib.Implementation.MBSubModuleBaseExtended.Patches.ModulePatch
  ...
```

## When to run it

- **After installing CREST for the first time** — confirms the install is whole.
- **After a Bannerlord patch** — checks BLSE injection still works and the stubs survived the update.
- **When a mod misbehaves** — `-Mod <name>` tells you whether your DLL references something CREST no longer provides.
- **Before filing a bug report** — `-ReportPath out.md` produces a single attachment that includes the relevant signal.
- **As part of CI** — exit codes follow PowerShell convention. The tool is non-fatal by design (warns rather than errors), but you can wrap it and inspect the markdown for `[ERR]` lines.

## What it does NOT do

- **Live patch inspection.** Doesn't tell you which TaleWorlds methods Harmony actually patched in the running game. That's Phase R.2 — an in-game console command (`crest.patches <ModId>`) that requires bundling another DLL into CREST.
- **Repair.** Reports problems; doesn't fix them.
- **Network checks.** Doesn't try to compare your CREST against the latest release. Use `Compare-CrestVersions.ps1` (in `tools\diff\`) for that.
