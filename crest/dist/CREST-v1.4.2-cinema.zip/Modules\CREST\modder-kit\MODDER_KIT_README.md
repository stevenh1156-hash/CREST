# CREST Modder Kit

You're a Bannerlord mod author. This folder ships inside the CREST release zip and is the entry point for everything you need to build, migrate, diagnose, and ship mods on top of CREST.

If you're a player, you can ignore this folder — it's tooling, not runtime.

---

## TL;DR (60 seconds)

1. **You probably don't have to do anything.** If your mod compiles against upstream Harmony / ButterLib / UIExtenderEx / MCMv5, it runs unchanged on CREST. The shim layer forwards your existing references. Read `MODDER_GUIDE.md` for the longer version.

2. **To start a new mod from scratch**, run `tools\Crest-NewMod.ps1 -Name "MyTweak"` from PowerShell. It scaffolds a complete buildable project (csproj, SubModule.cs, example Harmony patch, deploy script) wired up to CREST's bin folder.

3. **To migrate an existing mod off the upstream BUTR shims** onto CREST‑native references (a leaner runtime path), run `tools\migrate\Migrate-ModToCrest.ps1` for a compiled DLL, or `tools\migrate\Migrate-ModSourceToCrest.ps1` for a source tree.

4. **When something breaks**, run `tools\doctor\Crest-Doctor.ps1` for a diagnostic dump (active patches, load order, config state, compat shims). For a UI, run `tools\Crest-GUI.bat`.

---

## What's In Here

```
modder-kit\
├── MODDER_KIT_README.md            <- this file
├── MODDER_GUIDE.md                  <- detailed migration guide
├── docs\
│   ├── MODDING.md                  <- end-to-end modder workflow
│   └── CONFIG_STORES.md            <- CrestConfig usage + examples
├── templates\
│   └── SubModule.xml.template      <- starting point for a CREST-dependent SubModule.xml
└── tools\
    ├── Crest-NewMod.ps1            <- scaffold a new mod (csproj + boilerplate)
    ├── Crest-GUI.ps1 / .bat        <- one-click GUI: Doctor / Compat / Migrate
    ├── Crest-PatchValidator.ps1    <- self-test for fragile Harmony patches
    ├── Crest.Dev.psm1              <- PowerShell module: Build/Deploy helpers
    ├── doctor\
    │   ├── Crest-Doctor.ps1        <- diagnostic dump (patches, load order, config)
    │   └── README.md
    ├── compat\
    │   ├── Crest-Compat.ps1        <- automatic mod-list compat fixes
    │   └── README.md
    └── migrate\
        ├── Migrate-ModToCrest.ps1        <- DLL-mode migration (compiled mod)
        ├── Migrate-ModSourceToCrest.ps1  <- source-mode migration (csproj + .cs)
        ├── Test-MigrateModSource.ps1     <- migration self-test
        └── README.md
```

---

## Public API (consumable from your mod)

Add a reference to `Crest.Harmony.dll` (it's at `Modules\CREST\bin\Win64_Shipping_Client\Crest.Harmony.dll` on a CREST install). The `Crest-NewMod.ps1` scaffolder wires this up automatically.

```csharp
using Bannerlord.Harmony;

// Append a timestamped diagnostic line to Modules\CREST\runtime.log.
// Works BEFORE ButterLib initializes, so safe to call from your earliest
// SubModule lifecycle hooks.
CrestDiag.Log("MyMod", "lifecycle: OnSubModuleLoad fired");

// Compact "I caught and swallowed this" record. Source + context + exception.
try { /* ... */ }
catch (Exception ex) { CrestDiag.LogCaught("MyMod", "OnTick", ex); }

// Compact "AccessTools returned null" record.
CrestDiag.LogTypeNotFound("MyMod", "TaleWorlds.X.Y");

// Force-flush the buffer. Useful before reading the log live.
CrestDiag.Flush();

// mtime-cached config bool read. Safe in hot paths (OnTick, etc).
// Picks up edits to crest.json on the next tick window without a relaunch.
if (CrestConfig.IsEnabled("MyMod_FeatureFlag", defaultValue: false))
{
    // ...
}

// Typed reads (also mtime-cached).
int   maxN  = CrestConfig.GetInt    ("MyMod_MaxN",  default: 16);
float speed = CrestConfig.GetFloat  ("MyMod_Speed", default: 1.0f);
string tag  = CrestConfig.GetString ("MyMod_Tag",   default: "");
```

The full API surface is in `docs\MODDING.md`.

---

## When To Use Each Tool

| You want to... | Use |
|---|---|
| Start a new mod from scratch | `tools\Crest-NewMod.ps1` |
| Migrate a compiled `.dll` to use CREST‑native refs | `tools\migrate\Migrate-ModToCrest.ps1` |
| Migrate a source tree (csproj + `.cs`) | `tools\migrate\Migrate-ModSourceToCrest.ps1` |
| Verify your migration didn't break anything | `tools\migrate\Test-MigrateModSource.ps1` |
| Diagnose what's loaded / what's patched at runtime | `tools\doctor\Crest-Doctor.ps1` |
| Auto‑fix common compat issues in someone's mod list | `tools\compat\Crest-Compat.ps1` |
| Self‑test fragile Harmony patches before shipping | `tools\Crest-PatchValidator.ps1` |
| Avoid the command line | `tools\Crest-GUI.bat` (Windows) |
| Use the PowerShell helpers from your own scripts | `Import-Module tools\Crest.Dev.psm1` |

---

## Reporting Issues

When filing a bug against CREST or asking for help in a community Discord, attach:

1. `Modules\CREST\runtime.log` (the only diagnostic file you need to send).
2. The output of `tools\doctor\Crest-Doctor.ps1 -OutputFile doctor.txt`.

Those two files together cover everything we'd ask you for.

---

## Stretch Goal: Hot‑Reload DLLs

The roadmap (Phase Y.6/Y.8‑stretch in the main `CHANGELOG.md`) includes the ability to **hot‑reload your mod's DLL while the game is running** — edit, build, alt‑tab, see your patch live, no relaunch. This is the single largest velocity unlock available to Bannerlord modding and it's funded by Patreon backing:

> https://patreon.com/Trashpanda1

If hot‑reload would change how you build mods, that's the lever to pull.
